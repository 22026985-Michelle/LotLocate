import '/flutter_flow/flutter_flow_util.dart';
import 'o_t_p_page_widget.dart' show OTPPageWidget;
import 'package:flutter/material.dart';

class OTPPageModel extends FlutterFlowModel<OTPPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for emailTextField widget.
  FocusNode? emailTextFieldFocusNode;
  TextEditingController? emailTextFieldTextController;
  String? Function(BuildContext, String?)?
      emailTextFieldTextControllerValidator;
  // State field(s) for passTextField widget.
  FocusNode? passTextFieldFocusNode1;
  TextEditingController? passTextFieldTextController1;
  late bool passTextFieldVisibility1;
  String? Function(BuildContext, String?)?
      passTextFieldTextController1Validator;
  // Stores action output result for [Custom Action - checkAuth] action in Button widget.
  bool? isSignedInCopy;
  // State field(s) for phTextField widget.
  FocusNode? phTextFieldFocusNode;
  TextEditingController? phTextFieldTextController;
  String? Function(BuildContext, String?)? phTextFieldTextControllerValidator;
  // State field(s) for passTextField widget.
  FocusNode? passTextFieldFocusNode2;
  TextEditingController? passTextFieldTextController2;
  late bool passTextFieldVisibility2;
  String? Function(BuildContext, String?)?
      passTextFieldTextController2Validator;
  // Stores action output result for [Custom Action - checkAuth] action in Button widget.
  bool? isSignedIn;

  @override
  void initState(BuildContext context) {
    passTextFieldVisibility1 = false;
    passTextFieldVisibility2 = false;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    tabBarController?.dispose();
    emailTextFieldFocusNode?.dispose();
    emailTextFieldTextController?.dispose();

    passTextFieldFocusNode1?.dispose();
    passTextFieldTextController1?.dispose();

    phTextFieldFocusNode?.dispose();
    phTextFieldTextController?.dispose();

    passTextFieldFocusNode2?.dispose();
    passTextFieldTextController2?.dispose();
  }
}
