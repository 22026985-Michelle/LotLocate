import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'create_acc_page_widget.dart' show CreateAccPageWidget;
import 'package:flutter/material.dart';

class CreateAccPageModel extends FlutterFlowModel<CreateAccPageWidget> {
  ///  Local state fields for this page.

  bool? passwordMatch = true;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey1 = GlobalKey<FormState>();
  final formKey2 = GlobalKey<FormState>();
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for NameTextField widget.
  FocusNode? nameTextFieldFocusNode;
  TextEditingController? nameTextFieldTextController;
  String? Function(BuildContext, String?)? nameTextFieldTextControllerValidator;
  String? _nameTextFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'qzeja4gf' /* Please enter first name */,
      );
    }

    return null;
  }

  // State field(s) for emailTextField widget.
  FocusNode? emailTextFieldFocusNode;
  TextEditingController? emailTextFieldTextController;
  String? Function(BuildContext, String?)?
      emailTextFieldTextControllerValidator;
  String? _emailTextFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '693aonj7' /* Please enter email address */,
      );
    }

    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return FFLocalizations.of(context).getText(
        'd1sxovii' /* Invalid email */,
      );
    }
    return null;
  }

  // State field(s) for passwordTextField widget.
  FocusNode? passwordTextFieldFocusNode;
  TextEditingController? passwordTextFieldTextController;
  late bool passwordTextFieldVisibility;
  String? Function(BuildContext, String?)?
      passwordTextFieldTextControllerValidator;
  String? _passwordTextFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'mivbhhtf' /* Please enter password */,
      );
    }

    if (val.length < 8) {
      return FFLocalizations.of(context).getText(
        'i97stf61' /* At least 8 characters required */,
      );
    }
    if (val.length > 128) {
      return FFLocalizations.of(context).getText(
        'd8psz8l5' /* Email should not exceed 120 ch... */,
      );
    }
    if (!RegExp('^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[\\W_])[\\w\\W_]+\$')
        .hasMatch(val)) {
      return FFLocalizations.of(context).getText(
        'ajsakbum' /* Password must contain at least... */,
      );
    }
    return null;
  }

  // State field(s) for ConfirmPasswordTextField widget.
  FocusNode? confirmPasswordTextFieldFocusNode;
  TextEditingController? confirmPasswordTextFieldTextController;
  late bool confirmPasswordTextFieldVisibility;
  String? Function(BuildContext, String?)?
      confirmPasswordTextFieldTextControllerValidator;
  String? _confirmPasswordTextFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '2scz9lyz' /* Please enter confirmation pass... */,
      );
    }

    if (val.length < 8) {
      return FFLocalizations.of(context).getText(
        'sh8t69vu' /* At least 8 characters required */,
      );
    }
    if (val.length > 128) {
      return FFLocalizations.of(context).getText(
        'bw3d2tkc' /* Email should not exceed 120 ch... */,
      );
    }
    if (!RegExp('^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[\\W_])[\\w\\W_]+\$')
        .hasMatch(val)) {
      return FFLocalizations.of(context).getText(
        '0o2g3ewc' /* Password must contain at least... */,
      );
    }
    return null;
  }

  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  UserInfoRow? isSuccessful;
  // State field(s) for passwordTextField11111 widget.
  FocusNode? passwordTextField11111FocusNode;
  TextEditingController? passwordTextField11111TextController;
  late bool passwordTextField11111Visibility;
  String? Function(BuildContext, String?)?
      passwordTextField11111TextControllerValidator;
  String? _passwordTextField11111TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'ed1cuwtd' /* Please enter password */,
      );
    }

    if (val.length < 8) {
      return FFLocalizations.of(context).getText(
        'ieywqmb6' /* At least 8 characters required */,
      );
    }
    if (val.length > 128) {
      return FFLocalizations.of(context).getText(
        'dugtvkl5' /* Email should not exceed 120 ch... */,
      );
    }
    if (!RegExp('^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[\\W_])[\\w\\W_]+\$')
        .hasMatch(val)) {
      return FFLocalizations.of(context).getText(
        'jmo21xxw' /* Password must contain at least... */,
      );
    }
    return null;
  }

  // State field(s) for ConfirmPasswordTextField111111 widget.
  FocusNode? confirmPasswordTextField111111FocusNode;
  TextEditingController? confirmPasswordTextField111111TextController;
  late bool confirmPasswordTextField111111Visibility;
  String? Function(BuildContext, String?)?
      confirmPasswordTextField111111TextControllerValidator;
  String? _confirmPasswordTextField111111TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'yi385fzi' /* Please enter confirmation pass... */,
      );
    }

    if (val.length < 8) {
      return FFLocalizations.of(context).getText(
        'b88008yu' /* At least 8 characters required */,
      );
    }
    if (val.length > 128) {
      return FFLocalizations.of(context).getText(
        'gx0b04wn' /* Email should not exceed 120 ch... */,
      );
    }
    if (!RegExp('^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[\\W_])[\\w\\W_]+\$')
        .hasMatch(val)) {
      return FFLocalizations.of(context).getText(
        'samho2oo' /* Password must contain at least... */,
      );
    }
    return null;
  }

  // Stores action output result for [Custom Action - signUpWithPhone] action in Button widget.
  String? error;
  // Stores action output result for [Custom Action - checkAuth] action in Button widget.
  bool? isSignedIn;

  @override
  void initState(BuildContext context) {
    nameTextFieldTextControllerValidator =
        _nameTextFieldTextControllerValidator;
    emailTextFieldTextControllerValidator =
        _emailTextFieldTextControllerValidator;
    passwordTextFieldVisibility = false;
    passwordTextFieldTextControllerValidator =
        _passwordTextFieldTextControllerValidator;
    confirmPasswordTextFieldVisibility = false;
    confirmPasswordTextFieldTextControllerValidator =
        _confirmPasswordTextFieldTextControllerValidator;
    passwordTextField11111Visibility = false;
    passwordTextField11111TextControllerValidator =
        _passwordTextField11111TextControllerValidator;
    confirmPasswordTextField111111Visibility = false;
    confirmPasswordTextField111111TextControllerValidator =
        _confirmPasswordTextField111111TextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    tabBarController?.dispose();
    nameTextFieldFocusNode?.dispose();
    nameTextFieldTextController?.dispose();

    emailTextFieldFocusNode?.dispose();
    emailTextFieldTextController?.dispose();

    passwordTextFieldFocusNode?.dispose();
    passwordTextFieldTextController?.dispose();

    confirmPasswordTextFieldFocusNode?.dispose();
    confirmPasswordTextFieldTextController?.dispose();

    passwordTextField11111FocusNode?.dispose();
    passwordTextField11111TextController?.dispose();

    confirmPasswordTextField111111FocusNode?.dispose();
    confirmPasswordTextField111111TextController?.dispose();
  }
}
