import '/flutter_flow/flutter_flow_util.dart';
import 'phone_o_t_p_component_widget.dart' show PhoneOTPComponentWidget;
import 'package:flutter/material.dart';

class PhoneOTPComponentModel extends FlutterFlowModel<PhoneOTPComponentWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for PinCode widget.
  TextEditingController? pinCodeController;
  String? Function(BuildContext, String?)? pinCodeControllerValidator;
  // Stores action output result for [Custom Action - confirmOtpPhone] action in Button widget.
  bool? isSuccessful;
  // Stores action output result for [Custom Action - checkUserData] action in Button widget.
  bool? hasUserData;

  @override
  void initState(BuildContext context) {
    pinCodeController = TextEditingController();
  }

  @override
  void dispose() {
    pinCodeController?.dispose();
  }
}
