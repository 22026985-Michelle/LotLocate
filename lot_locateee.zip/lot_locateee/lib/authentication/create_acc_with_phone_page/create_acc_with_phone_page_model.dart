import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'create_acc_with_phone_page_widget.dart'
    show CreateAccWithPhonePageWidget;
import 'package:flutter/material.dart';

class CreateAccWithPhonePageModel
    extends FlutterFlowModel<CreateAccWithPhonePageWidget> {
  ///  Local state fields for this page.

  bool? passwordMatch = true;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UserInfoRow>? gj;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
