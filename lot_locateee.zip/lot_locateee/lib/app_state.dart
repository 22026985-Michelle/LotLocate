import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = const FlutterSecureStorage();
    await _safeInitAsync(() async {
      _navOpen = await secureStorage.getBool('ff_navOpen') ?? _navOpen;
    });
    await _safeInitAsync(() async {
      _navTestOpen =
          await secureStorage.getBool('ff_navTestOpen') ?? _navTestOpen;
    });
    await _safeInitAsync(() async {
      _apiKey = await secureStorage.getString('ff_apiKey') ?? _apiKey;
    });
    await _safeInitAsync(() async {
      _assistantId =
          await secureStorage.getString('ff_assistantId') ?? _assistantId;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  bool _navOpen = false;
  bool get navOpen => _navOpen;
  set navOpen(bool value) {
    _navOpen = value;
    secureStorage.setBool('ff_navOpen', value);
  }

  void deleteNavOpen() {
    secureStorage.delete(key: 'ff_navOpen');
  }

  bool _navTestOpen = false;
  bool get navTestOpen => _navTestOpen;
  set navTestOpen(bool value) {
    _navTestOpen = value;
    secureStorage.setBool('ff_navTestOpen', value);
  }

  void deleteNavTestOpen() {
    secureStorage.delete(key: 'ff_navTestOpen');
  }

  String _apiKey = 'sk-proj-P40ATtHH3v2ZNF8vcTEOT3BlbkFJQjctehygB6kTrgGtIHPM';
  String get apiKey => _apiKey;
  set apiKey(String value) {
    _apiKey = value;
    secureStorage.setString('ff_apiKey', value);
  }

  void deleteApiKey() {
    secureStorage.delete(key: 'ff_apiKey');
  }

  String _assistantId = 'asst_aAUuKoNTXSHyuezZSNAZEjTy';
  String get assistantId => _assistantId;
  set assistantId(String value) {
    _assistantId = value;
    secureStorage.setString('ff_assistantId', value);
  }

  void deleteAssistantId() {
    secureStorage.delete(key: 'ff_assistantId');
  }

  String _phoneNumber = '';
  String get phoneNumber => _phoneNumber;
  set phoneNumber(String value) {
    _phoneNumber = value;
  }

  bool _bottomSheet = true;
  bool get bottomSheet => _bottomSheet;
  set bottomSheet(bool value) {
    _bottomSheet = value;
  }

  String _selectedMarkerName = '';
  String get selectedMarkerName => _selectedMarkerName;
  set selectedMarkerName(String value) {
    _selectedMarkerName = value;
  }

  String _selectedMarkerVicinity = '';
  String get selectedMarkerVicinity => _selectedMarkerVicinity;
  set selectedMarkerVicinity(String value) {
    _selectedMarkerVicinity = value;
  }

  int _selectedMarkerAvail = 0;
  int get selectedMarkerAvail => _selectedMarkerAvail;
  set selectedMarkerAvail(int value) {
    _selectedMarkerAvail = value;
  }

  String _streetViewImageUrl = '';
  String get streetViewImageUrl => _streetViewImageUrl;
  set streetViewImageUrl(String value) {
    _streetViewImageUrl = value;
  }

  String _destination = '';
  String get destination => _destination;
  set destination(String value) {
    _destination = value;
  }

  String _origin = '';
  String get origin => _origin;
  set origin(String value) {
    _origin = value;
  }

  String _speechToTextResponse = '';
  String get speechToTextResponse => _speechToTextResponse;
  set speechToTextResponse(String value) {
    _speechToTextResponse = value;
  }

  int _timerValue = 0;
  int get timerValue => _timerValue;
  set timerValue(int value) {
    _timerValue = value;
  }

  String _selectedMarkerWeekdayRate = '';
  String get selectedMarkerWeekdayRate => _selectedMarkerWeekdayRate;
  set selectedMarkerWeekdayRate(String value) {
    _selectedMarkerWeekdayRate = value;
  }

  String _selectedMarkerWeekdayRateTiming = '';
  String get selectedMarkerWeekdayRateTiming =>
      _selectedMarkerWeekdayRateTiming;
  set selectedMarkerWeekdayRateTiming(String value) {
    _selectedMarkerWeekdayRateTiming = value;
  }

  String _selectedMarkerSaturdayRate = '';
  String get selectedMarkerSaturdayRate => _selectedMarkerSaturdayRate;
  set selectedMarkerSaturdayRate(String value) {
    _selectedMarkerSaturdayRate = value;
  }

  String _selectedMarkerSatRateTiming = '';
  String get selectedMarkerSatRateTiming => _selectedMarkerSatRateTiming;
  set selectedMarkerSatRateTiming(String value) {
    _selectedMarkerSatRateTiming = value;
  }

  String _selectedMarkerSundayRate = '';
  String get selectedMarkerSundayRate => _selectedMarkerSundayRate;
  set selectedMarkerSundayRate(String value) {
    _selectedMarkerSundayRate = value;
  }

  String _selectedMarkerSunRateTiming = '';
  String get selectedMarkerSunRateTiming => _selectedMarkerSunRateTiming;
  set selectedMarkerSunRateTiming(String value) {
    _selectedMarkerSunRateTiming = value;
  }

  String _dayToday = '';
  String get dayToday => _dayToday;
  set dayToday(String value) {
    _dayToday = value;
  }

  String _assistantRequest = '';
  String get assistantRequest => _assistantRequest;
  set assistantRequest(String value) {
    _assistantRequest = value;
  }

  String _selectedMarkerReviewName = '';
  String get selectedMarkerReviewName => _selectedMarkerReviewName;
  set selectedMarkerReviewName(String value) {
    _selectedMarkerReviewName = value;
  }

  String _selectedMarkerPhotoRef = '';
  String get selectedMarkerPhotoRef => _selectedMarkerPhotoRef;
  set selectedMarkerPhotoRef(String value) {
    _selectedMarkerPhotoRef = value;
  }

  String _selectedMarkerRating = '';
  String get selectedMarkerRating => _selectedMarkerRating;
  set selectedMarkerRating(String value) {
    _selectedMarkerRating = value;
  }

  String _carparkDestination = '';
  String get carparkDestination => _carparkDestination;
  set carparkDestination(String value) {
    _carparkDestination = value;
  }

  String _carparkOrigin = '';
  String get carparkOrigin => _carparkOrigin;
  set carparkOrigin(String value) {
    _carparkOrigin = value;
  }

  String _carparkMode = '';
  String get carparkMode => _carparkMode;
  set carparkMode(String value) {
    _carparkMode = value;
  }

  bool _filterSheet = false;
  bool get filterSheet => _filterSheet;
  set filterSheet(bool value) {
    _filterSheet = value;
  }

  List<LatLng> _markers = [];
  List<LatLng> get markers => _markers;
  set markers(List<LatLng> value) {
    _markers = value;
  }

  void addToMarkers(LatLng value) {
    markers.add(value);
  }

  void removeFromMarkers(LatLng value) {
    markers.remove(value);
  }

  void removeAtIndexFromMarkers(int index) {
    markers.removeAt(index);
  }

  void updateMarkersAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    markers[index] = updateFn(_markers[index]);
  }

  void insertAtIndexInMarkers(int index, LatLng value) {
    markers.insert(index, value);
  }

  List<LatLng> _initialMarkers = [];
  List<LatLng> get initialMarkers => _initialMarkers;
  set initialMarkers(List<LatLng> value) {
    _initialMarkers = value;
  }

  void addToInitialMarkers(LatLng value) {
    initialMarkers.add(value);
  }

  void removeFromInitialMarkers(LatLng value) {
    initialMarkers.remove(value);
  }

  void removeAtIndexFromInitialMarkers(int index) {
    initialMarkers.removeAt(index);
  }

  void updateInitialMarkersAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    initialMarkers[index] = updateFn(_initialMarkers[index]);
  }

  void insertAtIndexInInitialMarkers(int index, LatLng value) {
    initialMarkers.insert(index, value);
  }

  List<String> _addresses = [];
  List<String> get addresses => _addresses;
  set addresses(List<String> value) {
    _addresses = value;
  }

  void addToAddresses(String value) {
    addresses.add(value);
  }

  void removeFromAddresses(String value) {
    addresses.remove(value);
  }

  void removeAtIndexFromAddresses(int index) {
    addresses.removeAt(index);
  }

  void updateAddressesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    addresses[index] = updateFn(_addresses[index]);
  }

  void insertAtIndexInAddresses(int index, String value) {
    addresses.insert(index, value);
  }

  List<String> _placeids = [];
  List<String> get placeids => _placeids;
  set placeids(List<String> value) {
    _placeids = value;
  }

  void addToPlaceids(String value) {
    placeids.add(value);
  }

  void removeFromPlaceids(String value) {
    placeids.remove(value);
  }

  void removeAtIndexFromPlaceids(int index) {
    placeids.removeAt(index);
  }

  void updatePlaceidsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    placeids[index] = updateFn(_placeids[index]);
  }

  void insertAtIndexInPlaceids(int index, String value) {
    placeids.insert(index, value);
  }

  LatLng? _location = const LatLng(1.352083, 103.819836);
  LatLng? get location => _location;
  set location(LatLng? value) {
    _location = value;
  }

  bool _previewSheet = true;
  bool get previewSheet => _previewSheet;
  set previewSheet(bool value) {
    _previewSheet = value;
  }

  bool _instructionsSheet = true;
  bool get instructionsSheet => _instructionsSheet;
  set instructionsSheet(bool value) {
    _instructionsSheet = value;
  }

  String _travelDuration = '';
  String get travelDuration => _travelDuration;
  set travelDuration(String value) {
    _travelDuration = value;
  }

  String _directions = '';
  String get directions => _directions;
  set directions(String value) {
    _directions = value;
  }

  bool _travelRow = true;
  bool get travelRow => _travelRow;
  set travelRow(bool value) {
    _travelRow = value;
  }

  bool _activityStarted = false;
  bool get activityStarted => _activityStarted;
  set activityStarted(bool value) {
    _activityStarted = value;
  }

  List<MessageTypeStruct> _messages = [];
  List<MessageTypeStruct> get messages => _messages;
  set messages(List<MessageTypeStruct> value) {
    _messages = value;
  }

  void addToMessages(MessageTypeStruct value) {
    messages.add(value);
  }

  void removeFromMessages(MessageTypeStruct value) {
    messages.remove(value);
  }

  void removeAtIndexFromMessages(int index) {
    messages.removeAt(index);
  }

  void updateMessagesAtIndex(
    int index,
    MessageTypeStruct Function(MessageTypeStruct) updateFn,
  ) {
    messages[index] = updateFn(_messages[index]);
  }

  void insertAtIndexInMessages(int index, MessageTypeStruct value) {
    messages.insert(index, value);
  }

  bool _pointClicked = true;
  bool get pointClicked => _pointClicked;
  set pointClicked(bool value) {
    _pointClicked = value;
  }

  List<LatLng> _places = [];
  List<LatLng> get places => _places;
  set places(List<LatLng> value) {
    _places = value;
  }

  void addToPlaces(LatLng value) {
    places.add(value);
  }

  void removeFromPlaces(LatLng value) {
    places.remove(value);
  }

  void removeAtIndexFromPlaces(int index) {
    places.removeAt(index);
  }

  void updatePlacesAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    places[index] = updateFn(_places[index]);
  }

  void insertAtIndexInPlaces(int index, LatLng value) {
    places.insert(index, value);
  }

  List<String> _routeDirections = [];
  List<String> get routeDirections => _routeDirections;
  set routeDirections(List<String> value) {
    _routeDirections = value;
  }

  void addToRouteDirections(String value) {
    routeDirections.add(value);
  }

  void removeFromRouteDirections(String value) {
    routeDirections.remove(value);
  }

  void removeAtIndexFromRouteDirections(int index) {
    routeDirections.removeAt(index);
  }

  void updateRouteDirectionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    routeDirections[index] = updateFn(_routeDirections[index]);
  }

  void insertAtIndexInRouteDirections(int index, String value) {
    routeDirections.insert(index, value);
  }

  List<LatLng> _routeCoordinates = [];
  List<LatLng> get routeCoordinates => _routeCoordinates;
  set routeCoordinates(List<LatLng> value) {
    _routeCoordinates = value;
  }

  void addToRouteCoordinates(LatLng value) {
    routeCoordinates.add(value);
  }

  void removeFromRouteCoordinates(LatLng value) {
    routeCoordinates.remove(value);
  }

  void removeAtIndexFromRouteCoordinates(int index) {
    routeCoordinates.removeAt(index);
  }

  void updateRouteCoordinatesAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    routeCoordinates[index] = updateFn(_routeCoordinates[index]);
  }

  void insertAtIndexInRouteCoordinates(int index, LatLng value) {
    routeCoordinates.insert(index, value);
  }

  LatLng? _startingPoint = const LatLng(1.352083, 103.819836);
  LatLng? get startingPoint => _startingPoint;
  set startingPoint(LatLng? value) {
    _startingPoint = value;
  }

  bool _displayClickedPlace = false;
  bool get displayClickedPlace => _displayClickedPlace;
  set displayClickedPlace(bool value) {
    _displayClickedPlace = value;
  }

  String _username = '';
  String get username => _username;
  set username(String value) {
    _username = value;
  }

  String _useremail = '';
  String get useremail => _useremail;
  set useremail(String value) {
    _useremail = value;
  }

  String _pfp = '';
  String get pfp => _pfp;
  set pfp(String value) {
    _pfp = value;
  }

  String _nullAppState = '';
  String get nullAppState => _nullAppState;
  set nullAppState(String value) {
    _nullAppState = value;
  }

  bool _isEnglish = true;
  bool get isEnglish => _isEnglish;
  set isEnglish(bool value) {
    _isEnglish = value;
  }

  bool _isFrench = false;
  bool get isFrench => _isFrench;
  set isFrench(bool value) {
    _isFrench = value;
  }

  bool _isChinese = false;
  bool get isChinese => _isChinese;
  set isChinese(bool value) {
    _isChinese = value;
  }

  bool _isMalay = false;
  bool get isMalay => _isMalay;
  set isMalay(bool value) {
    _isMalay = value;
  }

  String _pass = '';
  String get pass => _pass;
  set pass(String value) {
    _pass = value;
  }

  LatLng? _initialLocation;
  LatLng? get initialLocation => _initialLocation;
  set initialLocation(LatLng? value) {
    _initialLocation = value;
  }

  String _startLocationString = '';
  String get startLocationString => _startLocationString;
  set startLocationString(String value) {
    _startLocationString = value;
  }

  List<String> _startLocationList = [];
  List<String> get startLocationList => _startLocationList;
  set startLocationList(List<String> value) {
    _startLocationList = value;
  }

  void addToStartLocationList(String value) {
    startLocationList.add(value);
  }

  void removeFromStartLocationList(String value) {
    startLocationList.remove(value);
  }

  void removeAtIndexFromStartLocationList(int index) {
    startLocationList.removeAt(index);
  }

  void updateStartLocationListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    startLocationList[index] = updateFn(_startLocationList[index]);
  }

  void insertAtIndexInStartLocationList(int index, String value) {
    startLocationList.insert(index, value);
  }

  bool _yourLocationSet = false;
  bool get yourLocationSet => _yourLocationSet;
  set yourLocationSet(bool value) {
    _yourLocationSet = value;
  }

  String _namePlace = '';
  String get namePlace => _namePlace;
  set namePlace(String value) {
    _namePlace = value;
  }

  LatLng? _endLocation;
  LatLng? get endLocation => _endLocation;
  set endLocation(LatLng? value) {
    _endLocation = value;
  }

  LatLng? _startLocation;
  LatLng? get startLocation => _startLocation;
  set startLocation(LatLng? value) {
    _startLocation = value;
  }

  String _travelType = 'driving';
  String get travelType => _travelType;
  set travelType(String value) {
    _travelType = value;
  }

  bool _drivingBool = true;
  bool get drivingBool => _drivingBool;
  set drivingBool(bool value) {
    _drivingBool = value;
  }

  bool _transitBool = false;
  bool get transitBool => _transitBool;
  set transitBool(bool value) {
    _transitBool = value;
  }

  bool _bicyclingBool = false;
  bool get bicyclingBool => _bicyclingBool;
  set bicyclingBool(bool value) {
    _bicyclingBool = value;
  }

  bool _walkingBool = false;
  bool get walkingBool => _walkingBool;
  set walkingBool(bool value) {
    _walkingBool = value;
  }

  bool _camera = false;
  bool get camera => _camera;
  set camera(bool value) {
    _camera = value;
  }

  bool _locationPermission = false;
  bool get locationPermission => _locationPermission;
  set locationPermission(bool value) {
    _locationPermission = value;
  }

  bool _photoLibPermission = false;
  bool get photoLibPermission => _photoLibPermission;
  set photoLibPermission(bool value) {
    _photoLibPermission = value;
  }

  String _engStringLocation = '';
  String get engStringLocation => _engStringLocation;
  set engStringLocation(String value) {
    _engStringLocation = value;
  }

  bool _isFindingRide = false;
  bool get isFindingRide => _isFindingRide;
  set isFindingRide(bool value) {
    _isFindingRide = value;
  }

  String _routeDistance = '';
  String get routeDistance => _routeDistance;
  set routeDistance(String value) {
    _routeDistance = value;
  }

  String _routeDuration = '';
  String get routeDuration => _routeDuration;
  set routeDuration(String value) {
    _routeDuration = value;
  }

  bool _startPressed = false;
  bool get startPressed => _startPressed;
  set startPressed(bool value) {
    _startPressed = value;
  }

  int _noOfStartPlaces = 0;
  int get noOfStartPlaces => _noOfStartPlaces;
  set noOfStartPlaces(int value) {
    _noOfStartPlaces = value;
  }

  int _noOfEndPlaces = 0;
  int get noOfEndPlaces => _noOfEndPlaces;
  set noOfEndPlaces(int value) {
    _noOfEndPlaces = value;
  }

  String _startPlace = '';
  String get startPlace => _startPlace;
  set startPlace(String value) {
    _startPlace = value;
  }

  String _endPlace = '';
  String get endPlace => _endPlace;
  set endPlace(String value) {
    _endPlace = value;
  }

  LatLng? _startPlaceLatLng;
  LatLng? get startPlaceLatLng => _startPlaceLatLng;
  set startPlaceLatLng(LatLng? value) {
    _startPlaceLatLng = value;
  }

  LatLng? _endPlaceLatLng;
  LatLng? get endPlaceLatLng => _endPlaceLatLng;
  set endPlaceLatLng(LatLng? value) {
    _endPlaceLatLng = value;
  }

  LatLng? _endLocationNearby;
  LatLng? get endLocationNearby => _endLocationNearby;
  set endLocationNearby(LatLng? value) {
    _endLocationNearby = value;
  }

  LatLng? _STARTMARKER;
  LatLng? get STARTMARKER => _STARTMARKER;
  set STARTMARKER(LatLng? value) {
    _STARTMARKER = value;
  }

  LatLng? _ENDMARKER = const LatLng(1.352083, 103.819836);
  LatLng? get ENDMARKER => _ENDMARKER;
  set ENDMARKER(LatLng? value) {
    _ENDMARKER = value;
  }

  String _phone = '';
  String get phone => _phone;
  set phone(String value) {
    _phone = value;
  }

  List<LatLng> _userRoute = [];
  List<LatLng> get userRoute => _userRoute;
  set userRoute(List<LatLng> value) {
    _userRoute = value;
  }

  void addToUserRoute(LatLng value) {
    userRoute.add(value);
  }

  void removeFromUserRoute(LatLng value) {
    userRoute.remove(value);
  }

  void removeAtIndexFromUserRoute(int index) {
    userRoute.removeAt(index);
  }

  void updateUserRouteAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    userRoute[index] = updateFn(_userRoute[index]);
  }

  void insertAtIndexInUserRoute(int index, LatLng value) {
    userRoute.insert(index, value);
  }

  bool _clearRoute = false;
  bool get clearRoute => _clearRoute;
  set clearRoute(bool value) {
    _clearRoute = value;
  }

  String _stt = 'Speak...';
  String get stt => _stt;
  set stt(String value) {
    _stt = value;
  }

  String _btnTalk = 'Talk';
  String get btnTalk => _btnTalk;
  set btnTalk(String value) {
    _btnTalk = value;
  }

  String _sstSendText = '';
  String get sstSendText => _sstSendText;
  set sstSendText(String value) {
    _sstSendText = value;
  }

  dynamic _chatgptRes;
  dynamic get chatgptRes => _chatgptRes;
  set chatgptRes(dynamic value) {
    _chatgptRes = value;
  }

  String _tts = '';
  String get tts => _tts;
  set tts(String value) {
    _tts = value;
  }

  int _FYPCarPark = 0;
  int get FYPCarPark => _FYPCarPark;
  set FYPCarPark(int value) {
    _FYPCarPark = value;
  }

  LatLng? _FYPCarParkLatLng = const LatLng(1.3010737, 103.8837393);
  LatLng? get FYPCarParkLatLng => _FYPCarParkLatLng;
  set FYPCarParkLatLng(LatLng? value) {
    _FYPCarParkLatLng = value;
  }

  String _FYPCarParkName = '5 Kampong Arang Road, Singapore';
  String get FYPCarParkName => _FYPCarParkName;
  set FYPCarParkName(String value) {
    _FYPCarParkName = value;
  }

  String _placeID = '';
  String get placeID => _placeID;
  set placeID(String value) {
    _placeID = value;
  }

  List<String> _openhours = [];
  List<String> get openhours => _openhours;
  set openhours(List<String> value) {
    _openhours = value;
  }

  void addToOpenhours(String value) {
    openhours.add(value);
  }

  void removeFromOpenhours(String value) {
    openhours.remove(value);
  }

  void removeAtIndexFromOpenhours(int index) {
    openhours.removeAt(index);
  }

  void updateOpenhoursAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    openhours[index] = updateFn(_openhours[index]);
  }

  void insertAtIndexInOpenhours(int index, String value) {
    openhours.insert(index, value);
  }

  double _selectedMarkerRatingDouble = 0.0;
  double get selectedMarkerRatingDouble => _selectedMarkerRatingDouble;
  set selectedMarkerRatingDouble(double value) {
    _selectedMarkerRatingDouble = value;
  }

  bool _favouriteBool = false;
  bool get favouriteBool => _favouriteBool;
  set favouriteBool(bool value) {
    _favouriteBool = value;
  }

  List<String> _favourites = [];
  List<String> get favourites => _favourites;
  set favourites(List<String> value) {
    _favourites = value;
  }

  void addToFavourites(String value) {
    favourites.add(value);
  }

  void removeFromFavourites(String value) {
    favourites.remove(value);
  }

  void removeAtIndexFromFavourites(int index) {
    favourites.removeAt(index);
  }

  void updateFavouritesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    favourites[index] = updateFn(_favourites[index]);
  }

  void insertAtIndexInFavourites(int index, String value) {
    favourites.insert(index, value);
  }

  String _urlOfProfile = '';
  String get urlOfProfile => _urlOfProfile;
  set urlOfProfile(String value) {
    _urlOfProfile = value;
  }

  List<String> _favAdd = [];
  List<String> get favAdd => _favAdd;
  set favAdd(List<String> value) {
    _favAdd = value;
  }

  void addToFavAdd(String value) {
    favAdd.add(value);
  }

  void removeFromFavAdd(String value) {
    favAdd.remove(value);
  }

  void removeAtIndexFromFavAdd(int index) {
    favAdd.removeAt(index);
  }

  void updateFavAddAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    favAdd[index] = updateFn(_favAdd[index]);
  }

  void insertAtIndexInFavAdd(int index, String value) {
    favAdd.insert(index, value);
  }

  List<int> _favoriteCounts = [];
  List<int> get favoriteCounts => _favoriteCounts;
  set favoriteCounts(List<int> value) {
    _favoriteCounts = value;
  }

  void addToFavoriteCounts(int value) {
    favoriteCounts.add(value);
  }

  void removeFromFavoriteCounts(int value) {
    favoriteCounts.remove(value);
  }

  void removeAtIndexFromFavoriteCounts(int index) {
    favoriteCounts.removeAt(index);
  }

  void updateFavoriteCountsAtIndex(
    int index,
    int Function(int) updateFn,
  ) {
    favoriteCounts[index] = updateFn(_favoriteCounts[index]);
  }

  void insertAtIndexInFavoriteCounts(int index, int value) {
    favoriteCounts.insert(index, value);
  }

  List<String> _placeNames = [];
  List<String> get placeNames => _placeNames;
  set placeNames(List<String> value) {
    _placeNames = value;
  }

  void addToPlaceNames(String value) {
    placeNames.add(value);
  }

  void removeFromPlaceNames(String value) {
    placeNames.remove(value);
  }

  void removeAtIndexFromPlaceNames(int index) {
    placeNames.removeAt(index);
  }

  void updatePlaceNamesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    placeNames[index] = updateFn(_placeNames[index]);
  }

  void insertAtIndexInPlaceNames(int index, String value) {
    placeNames.insert(index, value);
  }

  DateTime? _dateTime;
  DateTime? get dateTime => _dateTime;
  set dateTime(DateTime? value) {
    _dateTime = value;
  }

  List<DateTime> _dateTimeList = [];
  List<DateTime> get dateTimeList => _dateTimeList;
  set dateTimeList(List<DateTime> value) {
    _dateTimeList = value;
  }

  void addToDateTimeList(DateTime value) {
    dateTimeList.add(value);
  }

  void removeFromDateTimeList(DateTime value) {
    dateTimeList.remove(value);
  }

  void removeAtIndexFromDateTimeList(int index) {
    dateTimeList.removeAt(index);
  }

  void updateDateTimeListAtIndex(
    int index,
    DateTime Function(DateTime) updateFn,
  ) {
    dateTimeList[index] = updateFn(_dateTimeList[index]);
  }

  void insertAtIndexInDateTimeList(int index, DateTime value) {
    dateTimeList.insert(index, value);
  }

  int _incomingCars = 0;
  int get incomingCars => _incomingCars;
  set incomingCars(int value) {
    _incomingCars = value;
  }

  int _OutgoingCars = 0;
  int get OutgoingCars => _OutgoingCars;
  set OutgoingCars(int value) {
    _OutgoingCars = value;
  }

  double _distanceFilter = 0.0;
  double get distanceFilter => _distanceFilter;
  set distanceFilter(double value) {
    _distanceFilter = value;
  }

  int _ratingFilter = 0;
  int get ratingFilter => _ratingFilter;
  set ratingFilter(int value) {
    _ratingFilter = value;
  }

  bool _rating1 = false;
  bool get rating1 => _rating1;
  set rating1(bool value) {
    _rating1 = value;
  }

  bool _rating2 = false;
  bool get rating2 => _rating2;
  set rating2(bool value) {
    _rating2 = value;
  }

  bool _rating3 = false;
  bool get rating3 => _rating3;
  set rating3(bool value) {
    _rating3 = value;
  }

  bool _rating4 = false;
  bool get rating4 => _rating4;
  set rating4(bool value) {
    _rating4 = value;
  }

  bool _rating5 = true;
  bool get rating5 => _rating5;
  set rating5(bool value) {
    _rating5 = value;
  }

  double _priceFilter = 0.0;
  double get priceFilter => _priceFilter;
  set priceFilter(double value) {
    _priceFilter = value;
  }

  String _phoneNum = '';
  String get phoneNum => _phoneNum;
  set phoneNum(String value) {
    _phoneNum = value;
  }

  List<String> _feedbackList = [];
  List<String> get feedbackList => _feedbackList;
  set feedbackList(List<String> value) {
    _feedbackList = value;
  }

  void addToFeedbackList(String value) {
    feedbackList.add(value);
  }

  void removeFromFeedbackList(String value) {
    feedbackList.remove(value);
  }

  void removeAtIndexFromFeedbackList(int index) {
    feedbackList.removeAt(index);
  }

  void updateFeedbackListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    feedbackList[index] = updateFn(_feedbackList[index]);
  }

  void insertAtIndexInFeedbackList(int index, String value) {
    feedbackList.insert(index, value);
  }

  bool _booleeee = false;
  bool get booleeee => _booleeee;
  set booleeee(bool value) {
    _booleeee = value;
  }

  bool _booler = false;
  bool get booler => _booler;
  set booler(bool value) {
    _booler = value;
  }

  int _FYPTotalAvail = 0;
  int get FYPTotalAvail => _FYPTotalAvail;
  set FYPTotalAvail(int value) {
    _FYPTotalAvail = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return const CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: const ListToCsvConverter().convert([value]));
}
