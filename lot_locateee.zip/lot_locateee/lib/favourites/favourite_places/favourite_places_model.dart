import '/flutter_flow/flutter_flow_util.dart';
import 'favourite_places_widget.dart' show FavouritePlacesWidget;
import 'package:flutter/material.dart';

class FavouritePlacesModel extends FlutterFlowModel<FavouritePlacesWidget> {
  ///  Local state fields for this page.

  String? pageUpdate;

  bool isShowFullList = true;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Custom Action - getFavourites] action in FavouritePlaces widget.
  List<dynamic>? gaeg;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  List<String> simpleSearchResults = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
