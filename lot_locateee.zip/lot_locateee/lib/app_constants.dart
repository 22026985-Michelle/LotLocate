
abstract class FFAppConstants {
  static const double spaceSmall = 8.0;
  static const double spaceMedium = 12.0;
  static const String emptyImgPath =
      'https://www.google.com/url?sa=i&url=https%3A%2F%2Fin.pinterest.com%2Fpin%2Fwhite-user-member-guest-icon-png-image--88735055149026870%2F&psig=AOvVaw3zxrOwiEPfNs5455TiW-nN&ust=1717323906549000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCNiF452YuoYDFQAAAAAdAAAAABBE';
}
