import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyCz4rxaVOQxd72McBpmHpWy1JaD4CNkwYA",
            authDomain: "lot-locate-5xfc5m.firebaseapp.com",
            projectId: "lot-locate-5xfc5m",
            storageBucket: "lot-locate-5xfc5m.appspot.com",
            messagingSenderId: "416780616679",
            appId: "1:416780616679:web:9b15556c7906924d55f342",
            measurementId: "G-HQGGG9R901"));
  } else {
    await Firebase.initializeApp();
  }
}
