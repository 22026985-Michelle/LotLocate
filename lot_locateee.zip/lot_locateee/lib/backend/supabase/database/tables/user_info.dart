import '../database.dart';

class UserInfoTable extends SupabaseTable<UserInfoRow> {
  @override
  String get tableName => 'user_info';

  @override
  UserInfoRow createRow(Map<String, dynamic> data) => UserInfoRow(data);
}

class UserInfoRow extends SupabaseDataRow {
  UserInfoRow(super.data);

  @override
  SupabaseTable get table => UserInfoTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String get name => getField<String>('name')!;
  set name(String value) => setField<String>('name', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  String? get pfp => getField<String>('pfp');
  set pfp(String? value) => setField<String>('pfp', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get role => getField<String>('role');
  set role(String? value) => setField<String>('role', value);

  List<String> get favourites => getListField<String>('favourites');
  set favourites(List<String>? value) =>
      setListField<String>('favourites', value);

  List<DateTime> get period => getListField<DateTime>('period');
  set period(List<DateTime>? value) => setListField<DateTime>('period', value);

  List<String> get feedback => getListField<String>('feedback');
  set feedback(List<String>? value) => setListField<String>('feedback', value);
}
