import '../database.dart';

class StatsTable extends SupabaseTable<StatsRow> {
  @override
  String get tableName => 'stats';

  @override
  StatsRow createRow(Map<String, dynamic> data) => StatsRow(data);
}

class StatsRow extends SupabaseDataRow {
  StatsRow(super.data);

  @override
  SupabaseTable get table => StatsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  DateTime? get period => getField<DateTime>('period');
  set period(DateTime? value) => setField<DateTime>('period', value);

  int? get places => getField<int>('places');
  set places(int? value) => setField<int>('places', value);
}
