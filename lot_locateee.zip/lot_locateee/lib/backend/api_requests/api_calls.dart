import 'dart:convert';
import '../cloud_functions/cloud_functions.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start OpenAI ChatGPT Group Code

class OpenAIChatGPTGroup {
  static ThreadsCall threadsCall = ThreadsCall();
  static MessageCall messageCall = MessageCall();
  static RunCall runCall = RunCall();
  static RetrieverunCall retrieverunCall = RetrieverunCall();
  static MessagesCall messagesCall = MessagesCall();
}

class ThreadsCall {
  Future<ApiCallResponse> call({
    String? token = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'ThreadsCall',
        'variables': {
          'token': token,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  String? threadid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.id''',
      ));
}

class MessageCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? content = '',
    String? token = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'MessageCall',
        'variables': {
          'threadId': threadId,
          'content': content,
          'token': token,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }
}

class RunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? assistantId = '',
    String? token = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'RunCall',
        'variables': {
          'threadId': threadId,
          'assistantId': assistantId,
          'token': token,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  String? runId(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.id''',
      ));
}

class RetrieverunCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? runId = '',
    String? token = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'RetrieverunCall',
        'variables': {
          'threadId': threadId,
          'runId': runId,
          'token': token,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class MessagesCall {
  Future<ApiCallResponse> call({
    String? threadId = '',
    String? token = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'MessagesCall',
        'variables': {
          'threadId': threadId,
          'token': token,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  dynamic data(dynamic response) => getJsonField(
        response,
        r'''$.data[0].content[0]''',
      );
}

/// End OpenAI ChatGPT Group Code

class NearbyPlacesCall {
  static Future<ApiCallResponse> call({
    String? latlng = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'NearbyPlacesCall',
        'variables': {
          'latlng': latlng,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<double>? lat(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].geometry.location.lat''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<double>(x))
          .withoutNulls
          .toList();
  static List<double>? lng(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].geometry.location.lng''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<double>(x))
          .withoutNulls
          .toList();
  static List<String>? name(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].name''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? photoref(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].photos[:].photo_reference''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? totaluserratings(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].user_ratings_total''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<String>? vicinity(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].vicinity''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<double>? rating(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].rating''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<double>(x))
          .withoutNulls
          .toList();
  static List<String>? icon(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].icon''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? iconmaskbaseuri(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].icon_mask_base_uri''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? referencee(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].reference''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List? photo(dynamic response) => getJsonField(
        response,
        r'''$.results[:].photos''',
        true,
      ) as List?;
  static List<String>? placeid(dynamic response) => (getJsonField(
        response,
        r'''$.results[:].place_id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class URACarParkDetailsCall {
  static Future<ApiCallResponse> call() async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'URACarParkDetailsCall',
        'variables': {},
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<String>? sunPHRate(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].sunPHRate''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? satdayMin(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].satdayMin''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? satdayRate(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].satdayRate''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? vehicleType(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].vehCat''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? endTime(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].endTime''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? startTime(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].startTime''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? sunPHMin(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].sunPHMin''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? parkingSystem(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].parkingSystem''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? weekdayRate(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].weekdayRate''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? weekdayMinTime(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].weekdayMin''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? parkingCapacity(dynamic response) => (getJsonField(
        response,
        r'''$.Result[:].parkCapacity''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
}

class DataMallCall {
  static Future<ApiCallResponse> call() async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'DataMallCall',
        'variables': {},
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<String>? carParkId(dynamic response) => (getJsonField(
        response,
        r'''$.value[:].CarParkID''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? area(dynamic response) => (getJsonField(
        response,
        r'''$.value[:].Area''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? development(dynamic response) => (getJsonField(
        response,
        r'''$.value[:].Development''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? locationLatLng(dynamic response) => (getJsonField(
        response,
        r'''$.value[:].Location''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? availLots(dynamic response) => (getJsonField(
        response,
        r'''$.value[:].AvailableLots''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
}

class DataGovSGCarParkRatesCall {
  static Future<ApiCallResponse> call() async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'DataGovSGCarParkRatesCall',
        'variables': {},
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<String>? location(dynamic response) => (getJsonField(
        response,
        r'''$.result.records[:].carpark''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? weekday1(dynamic response) => (getJsonField(
        response,
        r'''$.result.records[:].weekdays_rate_1''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? weekday2(dynamic response) => (getJsonField(
        response,
        r'''$.result.records[:].weekdays_rate_2''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? sat(dynamic response) => (getJsonField(
        response,
        r'''$.result.records[:].saturday_rate''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? sunORPH(dynamic response) => (getJsonField(
        response,
        r'''$.result.records[:].sunday_publicholiday_rate''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class GetPlacePhotoCall {
  static Future<ApiCallResponse> call({
    String? photoReference = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GetPlacePhotoCall',
        'variables': {
          'photoReference': photoReference,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }
}

class DistanceMatrixCall {
  static Future<ApiCallResponse> call({
    String? destinations = '',
    String? origins = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'DistanceMatrixCall',
        'variables': {
          'destinations': destinations,
          'origins': origins,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? distance(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.rows[:].elements[:].distance.text''',
      ));
  static String? duration(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.rows[:].elements[:].duration.text''',
      ));
}

class GetResponseCall {
  static Future<ApiCallResponse> call({
    String? apiKeyAuth = '',
    String? prompt = '',
    String? language = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GetResponseCall',
        'variables': {
          'apiKeyAuth': apiKeyAuth,
          'prompt': prompt,
          'language': language,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? message(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class ChatGPTCall {
  static Future<ApiCallResponse> call({
    String? messages = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'ChatGPTCall',
        'variables': {
          'messages': messages,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? response(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class GetTokenURACarParkDetailsCall {
  static Future<ApiCallResponse> call() async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GetTokenURACarParkDetailsCall',
        'variables': {},
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? token(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.Result''',
      ));
}

class GetDirectionsCall {
  static Future<ApiCallResponse> call({
    String? destination = '',
    String? origin = '',
    String? key = 'AIzaSyAW9T9QCLc62imUZ0gmJh7Eo3WMOgiI718',
    bool? alternatives = true,
    int? arrivalTime,
    String? mode = '',
    String? avoid = '',
    String? departureTime = '',
    String? transitMode = '',
    String? transitRoutingPreference = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GetDirectionsCall',
        'variables': {
          'destination': destination,
          'origin': origin,
          'key': key,
          'alternatives': alternatives,
          'arrivalTime': arrivalTime,
          'mode': mode,
          'avoid': avoid,
          'departureTime': departureTime,
          'transitMode': transitMode,
          'transitRoutingPreference': transitRoutingPreference,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<String>? instructions(dynamic response) => (getJsonField(
        response,
        r'''$.routes[:].legs[:].steps[:].html_instructions''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? stepsDuration(dynamic response) => (getJsonField(
        response,
        r'''$.routes[:].legs[:].steps[:].duration.text''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? stepsDistance(dynamic response) => (getJsonField(
        response,
        r'''$.routes[:].legs[:].steps[:].distance.text''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? walkingDuration(dynamic response) => (getJsonField(
        response,
        r'''$.routes[:].legs[:].duration.text''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? stepsTravelMode(dynamic response) => (getJsonField(
        response,
        r'''$.routes[:].legs[:].steps[:].travel_mode''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static int? durationTravel(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.routes[0].legs[0].duration.value''',
      ));
}

class GetAddressCall {
  static Future<ApiCallResponse> call({
    String? input = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GetAddressCall',
        'variables': {
          'input': input,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<String>? addresses(dynamic response) => (getJsonField(
        response,
        r'''$.predictions[:].description''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? placeid(dynamic response) => (getJsonField(
        response,
        r'''$.predictions[:].place_id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class GetReferenceCall {
  static Future<ApiCallResponse> call({
    String? input = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GetReferenceCall',
        'variables': {
          'input': input,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static double? lat(dynamic response) => castToType<double>(getJsonField(
        response,
        r'''$.result.geometry.location.lat''',
      ));
  static double? lng(dynamic response) => castToType<double>(getJsonField(
        response,
        r'''$.result.geometry.location.lng''',
      ));
}

class ClaudeAPICall {
  static Future<ApiCallResponse> call({
    String? messages = '',
    String? system =
        'You are the AI assistant for LotLocate, a car park navigation app for Singapore. Your primary functions are to help users find nearby car parks, provide information about car parks, and offer navigation assistance. Respond only to queries related to these functions. Do not engage with topics unrelated to navigation or car parks in Singapore.Key features:1. Nearby car parks: Users can input a location in Singapore to find nearby car parks within a certain radius. Provide information about these car parks when asked.2. Car park information: Offer details about specific car parks, including availability, rates, and any special features.3. Favorites: Users can mark car parks as favorites. Remember and recall user\'s favorite car parks when mentioned in the conversation.4. Navigation: Assist with directions to car parks or locations. Users can choose their travel type (walking, cycling, transit, or driving). Provide appropriate route information and directions based on the chosen travel type.5. Location memory: Remember locations mentioned by the user during the conversation for easy reference.When responding to queries:- Only provide information about Singapore locations and car parks.- Offer clear, concise directions and car park information.- If asked about favorites or previously mentioned locations, refer to them in your responses.- For navigation queries, always clarify the travel type if not specified.- Do not engage with queries unrelated to navigation or car parks in Singapore.Maintain a helpful and informative tone, focusing solely on assisting users with their navigation and car parking needs in Singapore.',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'ClaudeAPICall',
        'variables': {
          'messages': messages,
          'system': system,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? response(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.content[:].text''',
      ));
}

class RowenaCallCall {
  static Future<ApiCallResponse> call() async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'RowenaCallCall',
        'variables': {},
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static int? incomingcar(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.items.IncomingCar''',
      ));
  static int? outgoingcar(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.items.OutgoingCar''',
      ));
  static String? totalslot(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.items.TotalSlots''',
      ));
  static int? totalavail(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.items.Totalavailable''',
      ));
}

class ChatGPTforVoiceAssistantCall {
  static Future<ApiCallResponse> call({
    dynamic messagesJson,
  }) async {
    final messages = _serializeJson(messagesJson);
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'ChatGPTforVoiceAssistantCall',
        'variables': {
          'messages': messages,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class ClaudeAPIVoiceAssistantCall {
  static Future<ApiCallResponse> call({
    String? messages = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'ClaudeAPIVoiceAssistantCall',
        'variables': {
          'messages': messages,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static String? response(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.content[-1:].text''',
      ));
}

class GoogleReviewsCall {
  static Future<ApiCallResponse> call({
    String? placeId = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'GoogleReviewsCall',
        'variables': {
          'placeId': placeId,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }

  static List<String>? authorname(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].author_name''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? profilepicofuser(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].profile_photo_url''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? ratingfromuser(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].rating''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<String>? reviewwritten(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].relative_time_description''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? authorurl(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].author_url''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? reviewtext(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].text''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? time(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].time''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<bool>? translatedbool(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].translated''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<bool>(x))
          .withoutNulls
          .toList();
  static List<String>? oglanguage(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].original_language''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? language(dynamic response) => (getJsonField(
        response,
        r'''$.result.reviews[:].language''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static int? totaluserratings(dynamic response) =>
      castToType<int>(getJsonField(
        response,
        r'''$.result.user_ratings_total''',
      ));
  static bool? wheelchairaccessible(dynamic response) =>
      castToType<bool>(getJsonField(
        response,
        r'''$.result.wheelchair_accessible_entrance''',
      ));
  static String? addressofplace(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.result.formatted_address''',
      ));
  static bool? opennowbool(dynamic response) => castToType<bool>(getJsonField(
        response,
        r'''$.result.current_opening_hours.open_now''',
      ));
  static List<String>? closedate(dynamic response) => (getJsonField(
        response,
        r'''$.result.current_opening_hours.periods[:].close.date''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? closeperiodday(dynamic response) => (getJsonField(
        response,
        r'''$.result.current_opening_hours.periods[:].close.day''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<String>? closetime(dynamic response) => (getJsonField(
        response,
        r'''$.result.current_opening_hours.periods[:].close.time''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? opendate(dynamic response) => (getJsonField(
        response,
        r'''$.result.current_opening_hours.periods[:].open.date''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? openperiodday(dynamic response) => (getJsonField(
        response,
        r'''$.result.current_opening_hours.periods[:].open.day''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<String>? opentime(dynamic response) => (getJsonField(
        response,
        r'''$.result.current_opening_hours.periods[:].open.time''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? availabilityperiodputpls(dynamic response) =>
      (getJsonField(
        response,
        r'''$.result.current_opening_hours.weekday_text''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List? reviewarray(dynamic response) => getJsonField(
        response,
        r'''$.result.reviews''',
        true,
      ) as List?;
  static List<String>? photoref(dynamic response) => (getJsonField(
        response,
        r'''$.result.photos[:].photo_reference''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List? photosarray(dynamic response) => getJsonField(
        response,
        r'''$.result.photos''',
        true,
      ) as List?;
  static dynamic currentopnhoursarray(dynamic response) => getJsonField(
        response,
        r'''$.result.current_opening_hours''',
      );
  static dynamic resultarray(dynamic response) => getJsonField(
        response,
        r'''$.result''',
      );
}

class ChatGPTAssistantforVoiceAssistantCall {
  static Future<ApiCallResponse> call({
    String? threadId = '',
    String? content = '',
  }) async {
    final ffApiRequestBody = '''
{
  "role": "user",
  "content": "$content"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'ChatGPTAssistantforVoiceAssistant',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
