import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SupplementsRecord extends FirestoreRecord {
  SupplementsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "quantity" field.
  int? _quantity;
  int get quantity => _quantity ?? 0;
  bool hasQuantity() => _quantity != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  void _initializeFields() {
    _status = snapshotData['status'] as String?;
    _quantity = castToType<int>(snapshotData['quantity']);
    _name = snapshotData['name'] as String?;
    _price = castToType<double>(snapshotData['price']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('supplements');

  static Stream<SupplementsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SupplementsRecord.fromSnapshot(s));

  static Future<SupplementsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SupplementsRecord.fromSnapshot(s));

  static SupplementsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SupplementsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SupplementsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SupplementsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SupplementsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SupplementsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSupplementsRecordData({
  String? status,
  int? quantity,
  String? name,
  double? price,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'status': status,
      'quantity': quantity,
      'name': name,
      'price': price,
    }.withoutNulls,
  );

  return firestoreData;
}

class SupplementsRecordDocumentEquality implements Equality<SupplementsRecord> {
  const SupplementsRecordDocumentEquality();

  @override
  bool equals(SupplementsRecord? e1, SupplementsRecord? e2) {
    return e1?.status == e2?.status &&
        e1?.quantity == e2?.quantity &&
        e1?.name == e2?.name &&
        e1?.price == e2?.price;
  }

  @override
  int hash(SupplementsRecord? e) =>
      const ListEquality().hash([e?.status, e?.quantity, e?.name, e?.price]);

  @override
  bool isValidKey(Object? o) => o is SupplementsRecord;
}
