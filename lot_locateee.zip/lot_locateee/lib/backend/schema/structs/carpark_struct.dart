// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CarparkStruct extends FFFirebaseStruct {
  CarparkStruct({
    List<String>? carparkName,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _carparkName = carparkName,
        super(firestoreUtilData);

  // "carpark_name" field.
  List<String>? _carparkName;
  List<String> get carparkName => _carparkName ?? const [];
  set carparkName(List<String>? val) => _carparkName = val;

  void updateCarparkName(Function(List<String>) updateFn) {
    updateFn(_carparkName ??= []);
  }

  bool hasCarparkName() => _carparkName != null;

  static CarparkStruct fromMap(Map<String, dynamic> data) => CarparkStruct(
        carparkName: getDataList(data['carpark_name']),
      );

  static CarparkStruct? maybeFromMap(dynamic data) =>
      data is Map ? CarparkStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'carpark_name': _carparkName,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'carpark_name': serializeParam(
          _carparkName,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static CarparkStruct fromSerializableMap(Map<String, dynamic> data) =>
      CarparkStruct(
        carparkName: deserializeParam<String>(
          data['carpark_name'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'CarparkStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is CarparkStruct &&
        listEquality.equals(carparkName, other.carparkName);
  }

  @override
  int get hashCode => const ListEquality().hash([carparkName]);
}

CarparkStruct createCarparkStruct({
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    CarparkStruct(
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

CarparkStruct? updateCarparkStruct(
  CarparkStruct? carpark, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    carpark
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addCarparkStructData(
  Map<String, dynamic> firestoreData,
  CarparkStruct? carpark,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (carpark == null) {
    return;
  }
  if (carpark.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && carpark.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final carparkData = getCarparkFirestoreData(carpark, forFieldValue);
  final nestedData = carparkData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = carpark.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getCarparkFirestoreData(
  CarparkStruct? carpark, [
  bool forFieldValue = false,
]) {
  if (carpark == null) {
    return {};
  }
  final firestoreData = mapToFirestore(carpark.toMap());

  // Add any Firestore field values
  carpark.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getCarparkListFirestoreData(
  List<CarparkStruct>? carparks,
) =>
    carparks?.map((e) => getCarparkFirestoreData(e, true)).toList() ?? [];
