import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'claude_chat_bot_widget.dart' show ClaudeChatBotWidget;
import 'package:flutter/material.dart';

class ClaudeChatBotModel extends FlutterFlowModel<ClaudeChatBotWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // State field(s) for inputMessage widget.
  FocusNode? inputMessageFocusNode;
  TextEditingController? inputMessageTextController;
  String? Function(BuildContext, String?)? inputMessageTextControllerValidator;
  // Stores action output result for [Backend Call - API (ClaudeAPI)] action in Button widget.
  ApiCallResponse? apiResult6yp;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    inputMessageFocusNode?.dispose();
    inputMessageTextController?.dispose();
  }
}
