import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'lot_locate_claude_widget.dart' show LotLocateClaudeWidget;
import 'package:flutter/material.dart';

class LotLocateClaudeModel extends FlutterFlowModel<LotLocateClaudeWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - API (ClaudeAPIVoiceAssistant)] action in Button widget.
  ApiCallResponse? chatResponse;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
