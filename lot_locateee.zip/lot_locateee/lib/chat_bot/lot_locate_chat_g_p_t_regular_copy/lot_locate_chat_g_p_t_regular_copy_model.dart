import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'lot_locate_chat_g_p_t_regular_copy_widget.dart'
    show LotLocateChatGPTRegularCopyWidget;
import 'package:flutter/material.dart';

class LotLocateChatGPTRegularCopyModel
    extends FlutterFlowModel<LotLocateChatGPTRegularCopyWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - API (ChatGPTforVoiceAssistant)] action in Button widget.
  ApiCallResponse? chatResponse;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
