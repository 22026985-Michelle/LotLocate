import '/backend/api_requests/api_calls.dart';
import '/components/user_info_top_bar/user_info_top_bar_widget.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'map_page_widget.dart' show MapPageWidget;
import 'package:flutter/material.dart';

class MapPageModel extends FlutterFlowModel<MapPageWidget> {
  ///  Local state fields for this page.

  String nameLocation = 'nameOfPlace';

  String? name;

  String? vicinity;

  bool? isWeekday;

  bool? isSaturday;

  bool? isSunday;

  ///  State fields for stateful widgets in this page.

  // Model for user_Info_topBar component.
  late UserInfoTopBarModel userInfoTopBarModel;
  // State field(s) for PlacePicker widget.
  FFPlace placePickerValue = const FFPlace();
  // Stores action output result for [Backend Call - API (NearbyPlaces)] action in IconButton widget.
  ApiCallResponse? nearbyPlacesResults;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // State field(s) for Slider widget.
  double? sliderValue1;
  // State field(s) for Slider widget.
  double? sliderValue2;

  @override
  void initState(BuildContext context) {
    userInfoTopBarModel = createModel(context, () => UserInfoTopBarModel());
  }

  @override
  void dispose() {
    userInfoTopBarModel.dispose();
  }
}
