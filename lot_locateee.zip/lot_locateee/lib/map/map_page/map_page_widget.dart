import '/backend/api_requests/api_calls.dart';
import '/components/user_info_top_bar/user_info_top_bar_widget.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_place_picker.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'map_page_model.dart';
export 'map_page_model.dart';

class MapPageWidget extends StatefulWidget {
  const MapPageWidget({super.key});

  @override
  State<MapPageWidget> createState() => _MapPageWidgetState();
}

class _MapPageWidgetState extends State<MapPageWidget> {
  late MapPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  LatLng? currentUserLocationValue;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MapPageModel());

    logFirebaseEvent('screen_view', parameters: {'screen_name': 'MapPage'});
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('MAP_PAGE_PAGE_MapPage_ON_INIT_STATE');
      logFirebaseEvent('MapPage_update_app_state');
      FFAppState().bottomSheet = false;
      setState(() {});
    });

    getCurrentUserLocation(defaultLocation: const LatLng(0.0, 0.0), cached: true)
        .then((loc) => setState(() => currentUserLocationValue = loc));
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();
    if (currentUserLocationValue == null) {
      return Container(
        color: FlutterFlowTheme.of(context).primaryBackground,
        child: Center(
          child: SizedBox(
            width: 50.0,
            height: 50.0,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(
                FlutterFlowTheme.of(context).primary,
              ),
            ),
          ),
        ),
      );
    }

    return FutureBuilder<ApiCallResponse>(
      future: DataMallCall.call(),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        final mapPageDataMallResponse = snapshot.data!;

        return Scaffold(
          key: scaffoldKey,
          resizeToAvoidBottomInset: false,
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          body: FutureBuilder<ApiCallResponse>(
            future: URACarParkDetailsCall.call(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 50.0,
                    height: 50.0,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        FlutterFlowTheme.of(context).primary,
                      ),
                    ),
                  ),
                );
              }
              final columnURACarParkDetailsResponse = snapshot.data!;

              return Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding:
                        const EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 15.0, 0.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: wrapWithModel(
                            model: _model.userInfoTopBarModel,
                            updateCallback: () => setState(() {}),
                            child: const UserInfoTopBarWidget(),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Material(
                        color: Colors.transparent,
                        elevation: 3.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(7.0),
                        ),
                        child: Container(
                          width: 290.0,
                          height: 40.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 4.0,
                                color: Color(0x33000000),
                                offset: Offset(
                                  0.0,
                                  2.0,
                                ),
                              )
                            ],
                            borderRadius: BorderRadius.circular(7.0),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    40.0, 0.0, 5.0, 0.0),
                                child: FlutterFlowPlacePicker(
                                  iOSGoogleMapsApiKey:
                                      'AIzaSyB2tocpr6oNEmieYxw4EeBMhMclATrXTis',
                                  androidGoogleMapsApiKey:
                                      'AIzaSyAOM8EdsBIzHmXScBtspW7Rlj7cxumMeio',
                                  webGoogleMapsApiKey:
                                      'AIzaSyAuSzNiZj7-uRfNm-pPjc5F0G5qeC6OVSU',
                                  onSelect: (place) async {
                                    setState(
                                        () => _model.placePickerValue = place);
                                  },
                                  defaultText:
                                      FFLocalizations.of(context).getText(
                                    'ev4ac407' /* Search */,
                                  ),
                                  buttonOptions: FFButtonOptions(
                                    width: 200.0,
                                    height: 40.0,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    textAlign: TextAlign.start,
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          fontFamily: 'Plus Jakarta Sans',
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          letterSpacing: 0.0,
                                        ),
                                    elevation: 0.0,
                                    borderSide: const BorderSide(
                                      color: Colors.transparent,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ),
                              FlutterFlowIconButton(
                                borderRadius: 20.0,
                                borderWidth: 1.0,
                                buttonSize: 40.0,
                                fillColor: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                                icon: Icon(
                                  Icons.search,
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  size: 24.0,
                                ),
                                onPressed: () async {
                                  logFirebaseEvent(
                                      'MAP_PAGE_PAGE_search_ICN_ON_TAP');
                                  logFirebaseEvent('IconButton_backend_call');
                                  _model.nearbyPlacesResults =
                                      await NearbyPlacesCall.call(
                                    latlng: valueOrDefault<String>(
                                      functions.latLngToString(
                                          _model.placePickerValue.latLng),
                                      '0',
                                    ),
                                  );

                                  logFirebaseEvent('IconButton_google_map');
                                  await _model.googleMapsController.future.then(
                                    (c) => c.animateCamera(
                                      CameraUpdate.newLatLng(_model
                                          .placePickerValue.latLng
                                          .toGoogleMaps()),
                                    ),
                                  );
                                  logFirebaseEvent(
                                      'IconButton_update_app_state');
                                  FFAppState().endLocationNearby =
                                      _model.placePickerValue.latLng;
                                  setState(() {});

                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  Flexible(
                    child: FutureBuilder<ApiCallResponse>(
                      future: DistanceMatrixCall.call(
                        destinations: FFAppState().destination,
                        origins: FFAppState().origin,
                      ),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).primary,
                                ),
                              ),
                            ),
                          );
                        }
                        final stackDistanceMatrixResponse = snapshot.data!;

                        return Stack(
                          children: [
                            FutureBuilder<ApiCallResponse>(
                              future: GetPlacePhotoCall.call(),
                              builder: (context, snapshot) {
                                // Customize what your widget looks like when it's loading.
                                if (!snapshot.hasData) {
                                  return Center(
                                    child: SizedBox(
                                      width: 50.0,
                                      height: 50.0,
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                          FlutterFlowTheme.of(context).primary,
                                        ),
                                      ),
                                    ),
                                  );
                                }
                                final containerGetPlacePhotoResponse =
                                    snapshot.data!;

                                return Container(
                                  height: 695.0,
                                  decoration: const BoxDecoration(),
                                  child: FutureBuilder<ApiCallResponse>(
                                    future: RowenaCallCall.call(),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 50.0,
                                            height: 50.0,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                FlutterFlowTheme.of(context)
                                                    .primary,
                                              ),
                                            ),
                                          ),
                                        );
                                      }
                                      final googleMapRowenaCallResponse =
                                          snapshot.data!;

                                      return FlutterFlowGoogleMap(
                                        controller: _model.googleMapsController,
                                        onCameraIdle: (latLng) => setState(() =>
                                            _model.googleMapsCenter = latLng),
                                        initialLocation:
                                            _model.googleMapsCenter ??=
                                                currentUserLocationValue!,
                                        markers: (functions.listDoubletoLatLng(
                                                    NearbyPlacesCall.lat(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?.toList(),
                                                    NearbyPlacesCall.lng(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?.toList()) ??
                                                [])
                                            .map(
                                              (marker) => FlutterFlowMarker(
                                                marker.serialize(),
                                                marker,
                                                () async {
                                                  logFirebaseEvent(
                                                      'MAP_GoogleMap_v7ifufni_ON_MARKER_TAP');
                                                  logFirebaseEvent(
                                                      'GoogleMap_update_app_state');
                                                  FFAppState().bottomSheet =
                                                      true;
                                                  FFAppState()
                                                          .selectedMarkerVicinity =
                                                      valueOrDefault<String>(
                                                    NearbyPlacesCall.vicinity(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'vicinity',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerAvail =
                                                      valueOrDefault<int>(
                                                    DataMallCall.availLots(
                                                      mapPageDataMallResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    0,
                                                  );
                                                  FFAppState().destination =
                                                      valueOrDefault<String>(
                                                    NearbyPlacesCall.vicinity(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'destination',
                                                  );
                                                  FFAppState().origin =
                                                      valueOrDefault<String>(
                                                    functions.latLngToString(
                                                        _model
                                                            .googleMapsCenter),
                                                    'origin',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerWeekdayRate =
                                                      valueOrDefault<String>(
                                                    URACarParkDetailsCall
                                                        .weekdayRate(
                                                      columnURACarParkDetailsResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'weekdayRate',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerWeekdayRateTiming =
                                                      valueOrDefault<String>(
                                                    URACarParkDetailsCall
                                                        .weekdayMinTime(
                                                      columnURACarParkDetailsResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'weekdayRateTiming',
                                                  );
                                                  FFAppState().dayToday =
                                                      valueOrDefault<String>(
                                                    dateTimeFormat(
                                                      'EEEE',
                                                      getCurrentTimestamp,
                                                      locale:
                                                          FFLocalizations.of(
                                                                  context)
                                                              .languageCode,
                                                    ),
                                                    'day',
                                                  );
                                                  FFAppState()
                                                          .streetViewImageUrl =
                                                      'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photo_reference=${valueOrDefault<String>(
                                                    NearbyPlacesCall.photoref(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'photoref',
                                                  )}&key=AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE';
                                                  FFAppState()
                                                          .selectedMarkerName =
                                                      NearbyPlacesCall.name(
                                                    (_model.nearbyPlacesResults
                                                            ?.jsonBody ??
                                                        ''),
                                                  )![valueOrDefault<int>(
                                                    functions.indexMarkerIdentifier(
                                                        _model.googleMapsCenter,
                                                        functions
                                                            .listDoubletoLatLng(
                                                                NearbyPlacesCall.lat(
                                                                  (_model.nearbyPlacesResults
                                                                          ?.jsonBody ??
                                                                      ''),
                                                                )?.toList(),
                                                                NearbyPlacesCall.lng(
                                                                  (_model.nearbyPlacesResults
                                                                          ?.jsonBody ??
                                                                      ''),
                                                                )?.toList())
                                                            ?.toList()),
                                                    0,
                                                  )];
                                                  FFAppState()
                                                          .selectedMarkerSaturdayRate =
                                                      valueOrDefault<String>(
                                                    URACarParkDetailsCall
                                                        .satdayRate(
                                                      columnURACarParkDetailsResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'satdayRate',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerSatRateTiming =
                                                      valueOrDefault<String>(
                                                    URACarParkDetailsCall
                                                        .satdayMin(
                                                      columnURACarParkDetailsResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'satTime',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerSundayRate =
                                                      valueOrDefault<String>(
                                                    URACarParkDetailsCall
                                                        .sunPHRate(
                                                      columnURACarParkDetailsResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'sunRate',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerSunRateTiming =
                                                      valueOrDefault<String>(
                                                    URACarParkDetailsCall
                                                        .sunPHMin(
                                                      columnURACarParkDetailsResponse
                                                          .jsonBody,
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    'sunTiming',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerRating =
                                                      valueOrDefault<String>(
                                                    (NearbyPlacesCall.rating(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )])
                                                        ?.toString(),
                                                    'rating',
                                                  );
                                                  FFAppState().placeID =
                                                      valueOrDefault<String>(
                                                    NearbyPlacesCall.placeid(
                                                      (_model.nearbyPlacesResults
                                                              ?.jsonBody ??
                                                          ''),
                                                    )?[valueOrDefault<int>(
                                                      functions.indexMarkerIdentifier(
                                                          _model.googleMapsCenter,
                                                          functions
                                                              .listDoubletoLatLng(
                                                                  NearbyPlacesCall.lat(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList(),
                                                                  NearbyPlacesCall.lng(
                                                                    (_model.nearbyPlacesResults
                                                                            ?.jsonBody ??
                                                                        ''),
                                                                  )?.toList())
                                                              ?.toList()),
                                                      0,
                                                    )],
                                                    '0',
                                                  );
                                                  FFAppState()
                                                          .selectedMarkerRatingDouble =
                                                      valueOrDefault<double>(
                                                    functions.stringToDouble(
                                                        valueOrDefault<String>(
                                                      (NearbyPlacesCall.rating(
                                                        (_model.nearbyPlacesResults
                                                                ?.jsonBody ??
                                                            ''),
                                                      )?[valueOrDefault<int>(
                                                        functions.indexMarkerIdentifier(
                                                            _model.googleMapsCenter,
                                                            functions
                                                                .listDoubletoLatLng(
                                                                    NearbyPlacesCall.lat(
                                                                      (_model.nearbyPlacesResults
                                                                              ?.jsonBody ??
                                                                          ''),
                                                                    )?.toList(),
                                                                    NearbyPlacesCall.lng(
                                                                      (_model.nearbyPlacesResults
                                                                              ?.jsonBody ??
                                                                          ''),
                                                                    )?.toList())
                                                                ?.toList()),
                                                        0,
                                                      )])
                                                          ?.toString(),
                                                      'rating',
                                                    )),
                                                    0.0,
                                                  );
                                                  FFAppState().incomingCars =
                                                      RowenaCallCall
                                                          .incomingcar(
                                                    googleMapRowenaCallResponse
                                                        .jsonBody,
                                                  )!;
                                                  FFAppState().OutgoingCars =
                                                      RowenaCallCall
                                                          .outgoingcar(
                                                    googleMapRowenaCallResponse
                                                        .jsonBody,
                                                  )!;
                                                  FFAppState().FYPTotalAvail =
                                                      RowenaCallCall.totalavail(
                                                    googleMapRowenaCallResponse
                                                        .jsonBody,
                                                  )!;
                                                  setState(() {});
                                                },
                                              ),
                                            )
                                            .toList(),
                                        markerColor: GoogleMarkerColor.red,
                                        mapType: MapType.normal,
                                        style: GoogleMapStyle.standard,
                                        initialZoom: 14.0,
                                        allowInteraction: true,
                                        allowZoom: true,
                                        showZoomControls: true,
                                        showLocation: true,
                                        showCompass: true,
                                        showMapToolbar: true,
                                        showTraffic: true,
                                        centerMapOnMarkerTap: true,
                                      );
                                    },
                                  ),
                                );
                              },
                            ),
                            Builder(
                              builder: (context) {
                                if (FFAppState().filterSheet == true) {
                                  return Visibility(
                                    visible: FFAppState().filterSheet == true,
                                    child: Container(
                                      width: double.infinity,
                                      height: 700.0,
                                      decoration: const BoxDecoration(
                                        color: Color(0xB20B191E),
                                        shape: BoxShape.rectangle,
                                      ),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          logFirebaseEvent(
                                              'MAP_PAGE_PAGE_Column_e8y2nmho_ON_TAP');
                                          logFirebaseEvent(
                                              'Column_update_app_state');
                                          FFAppState().filterSheet = false;
                                          setState(() {});
                                        },
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Container(
                                              width: double.infinity,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                                boxShadow: const [
                                                  BoxShadow(
                                                    blurRadius: 4.0,
                                                    color: Color(0x25090F13),
                                                    offset: Offset(
                                                      0.0,
                                                      2.0,
                                                    ),
                                                  )
                                                ],
                                                borderRadius: const BorderRadius.only(
                                                  bottomLeft:
                                                      Radius.circular(0.0),
                                                  bottomRight:
                                                      Radius.circular(0.0),
                                                  topLeft:
                                                      Radius.circular(12.0),
                                                  topRight:
                                                      Radius.circular(12.0),
                                                ),
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        14.0, 4.0, 14.0, 4.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Container(
                                                          width: 60.0,
                                                          height: 4.0,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primaryBackground,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        2.0),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      12.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'hzpzznbz' /* Filter */,
                                                            ),
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .headlineSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Outfit',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Divider(
                                                      height: 24.0,
                                                      thickness: 2.0,
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .alternate,
                                                    ),
                                                    Text(
                                                      FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'q7a9egxv' /* Distance */,
                                                      ),
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .headlineSmall
                                                          .override(
                                                            fontFamily:
                                                                'Outfit',
                                                            letterSpacing: 0.0,
                                                          ),
                                                    ),
                                                    SliderTheme(
                                                      data: const SliderThemeData(
                                                        showValueIndicator:
                                                            ShowValueIndicator
                                                                .always,
                                                      ),
                                                      child: Slider(
                                                        activeColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .warning,
                                                        inactiveColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .alternate,
                                                        min: 0.0,
                                                        max: 150.0,
                                                        value: _model
                                                                .sliderValue1 ??=
                                                            75.0,
                                                        label: _model
                                                            .sliderValue1
                                                            ?.toStringAsFixed(
                                                                1),
                                                        onChanged: (newValue) {
                                                          newValue = double
                                                              .parse(newValue
                                                                  .toStringAsFixed(
                                                                      1));
                                                          setState(() => _model
                                                                  .sliderValue1 =
                                                              newValue);
                                                        },
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  10.0),
                                                      child: Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'x1ui3vce' /* 0.0km */,
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Plus Jakarta Sans',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                          Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'hzrxb6x1' /* 150km */,
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Plus Jakarta Sans',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Text(
                                                      FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'aaqezq4h' /* Price */,
                                                      ),
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .headlineSmall
                                                          .override(
                                                            fontFamily:
                                                                'Outfit',
                                                            letterSpacing: 0.0,
                                                          ),
                                                    ),
                                                    SliderTheme(
                                                      data: const SliderThemeData(
                                                        showValueIndicator:
                                                            ShowValueIndicator
                                                                .always,
                                                      ),
                                                      child: Slider(
                                                        activeColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .warning,
                                                        inactiveColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .alternate,
                                                        min: 2.0,
                                                        max: 200.0,
                                                        value: _model
                                                                .sliderValue2 ??=
                                                            101.0,
                                                        label: _model
                                                            .sliderValue2
                                                            ?.toStringAsFixed(
                                                                2),
                                                        onChanged: (newValue) {
                                                          newValue = double
                                                              .parse(newValue
                                                                  .toStringAsFixed(
                                                                      2));
                                                          setState(() => _model
                                                                  .sliderValue2 =
                                                              newValue);
                                                        },
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  10.0),
                                                      child: Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'z227isap' /* $2.00/hour */,
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Plus Jakarta Sans',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                          Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'b3fbtv0y' /* $200/hour */,
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Plus Jakarta Sans',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  10.0),
                                                      child: Text(
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                          'ptrtl11n' /* Rating */,
                                                        ),
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Outfit',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                      ),
                                                    ),
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      10.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: 50.0,
                                                            height: 25.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              borderRadius:
                                                                  const BorderRadius
                                                                      .only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                              ),
                                                              shape: BoxShape
                                                                  .rectangle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryText,
                                                              ),
                                                            ),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          2.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'vwucky2f' /* 5 */,
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Plus Jakarta Sans',
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .solidStar,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  size: 11.0,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      10.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: 50.0,
                                                            height: 25.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              borderRadius:
                                                                  const BorderRadius
                                                                      .only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                              ),
                                                              shape: BoxShape
                                                                  .rectangle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryText,
                                                              ),
                                                            ),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          2.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'juhxy4f9' /* 4 */,
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Plus Jakarta Sans',
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .solidStar,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  size: 11.0,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      10.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: 50.0,
                                                            height: 25.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              borderRadius:
                                                                  const BorderRadius
                                                                      .only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                              ),
                                                              shape: BoxShape
                                                                  .rectangle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryText,
                                                              ),
                                                            ),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          2.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'mxzl8mtv' /* 3 */,
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Plus Jakarta Sans',
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .solidStar,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  size: 11.0,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      10.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: 50.0,
                                                            height: 25.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              borderRadius:
                                                                  const BorderRadius
                                                                      .only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                              ),
                                                              shape: BoxShape
                                                                  .rectangle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryText,
                                                              ),
                                                            ),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          2.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'wz4h2xu6' /* 2 */,
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Plus Jakarta Sans',
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .solidStar,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  size: 11.0,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      10.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: 50.0,
                                                            height: 25.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              borderRadius:
                                                                  const BorderRadius
                                                                      .only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topLeft: Radius
                                                                    .circular(
                                                                        5.0),
                                                                topRight: Radius
                                                                    .circular(
                                                                        5.0),
                                                              ),
                                                              shape: BoxShape
                                                                  .rectangle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryText,
                                                              ),
                                                            ),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          2.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'cechwbb8' /* 1 */,
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Plus Jakarta Sans',
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .solidStar,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  size: 11.0,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  15.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Expanded(
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          16.0,
                                                                          0.0,
                                                                          16.0,
                                                                          0.0),
                                                              child:
                                                                  FFButtonWidget(
                                                                onPressed: () {
                                                                  print(
                                                                      'Button pressed ...');
                                                                },
                                                                text: FFLocalizations.of(
                                                                        context)
                                                                    .getText(
                                                                  '2afkwo7e' /* Clear All */,
                                                                ),
                                                                options:
                                                                    FFButtonOptions(
                                                                  width: double
                                                                      .infinity,
                                                                  height: 50.0,
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  iconPadding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryBackground,
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .override(
                                                                        fontFamily:
                                                                            'Plus Jakarta Sans',
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primaryText,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  elevation:
                                                                      2.0,
                                                                  borderSide:
                                                                      const BorderSide(
                                                                    width: 1.0,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          16.0,
                                                                          0.0,
                                                                          16.0,
                                                                          0.0),
                                                              child:
                                                                  FFButtonWidget(
                                                                onPressed: () {
                                                                  print(
                                                                      'Button pressed ...');
                                                                },
                                                                text: FFLocalizations.of(
                                                                        context)
                                                                    .getText(
                                                                  'nrx6l2jt' /* Apply */,
                                                                ),
                                                                options:
                                                                    FFButtonOptions(
                                                                  width: double
                                                                      .infinity,
                                                                  height: 50.0,
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  iconPadding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .warning,
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .override(
                                                                        fontFamily:
                                                                            'Plus Jakarta Sans',
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .background,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  elevation:
                                                                      2.0,
                                                                  borderSide:
                                                                      const BorderSide(
                                                                    color: Colors
                                                                        .transparent,
                                                                    width: 1.0,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                } else {
                                  return Visibility(
                                    visible: FFAppState().bottomSheet == true,
                                    child: Container(
                                      width: double.infinity,
                                      height: 700.0,
                                      decoration: const BoxDecoration(
                                        color: Color(0xB20B191E),
                                        shape: BoxShape.rectangle,
                                      ),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          logFirebaseEvent(
                                              'MAP_PAGE_PAGE_Column_207eryin_ON_TAP');
                                          logFirebaseEvent(
                                              'Column_update_app_state');
                                          FFAppState().bottomSheet = false;
                                          setState(() {});
                                        },
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Align(
                                              alignment: const AlignmentDirectional(
                                                  1.0, 0.0),
                                              child: Padding(
                                                padding: const EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 12.0, 8.0),
                                                child: FlutterFlowIconButton(
                                                  borderColor:
                                                      Colors.transparent,
                                                  borderRadius: 30.0,
                                                  borderWidth: 1.0,
                                                  buttonSize: 44.0,
                                                  fillColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .primaryBackground,
                                                  icon: Icon(
                                                    Icons.close_rounded,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryText,
                                                    size: 24.0,
                                                  ),
                                                  onPressed: () async {
                                                    logFirebaseEvent(
                                                        'MAP_PAGE_PAGE_close_rounded_ICN_ON_TAP');
                                                    logFirebaseEvent(
                                                        'IconButton_update_app_state');
                                                    FFAppState().bottomSheet =
                                                        false;
                                                    setState(() {});
                                                  },
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      15.0, 0.0, 15.0, 15.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 5.0,
                                                shape: const RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    bottomLeft:
                                                        Radius.circular(16.0),
                                                    bottomRight:
                                                        Radius.circular(16.0),
                                                    topLeft:
                                                        Radius.circular(16.0),
                                                    topRight:
                                                        Radius.circular(16.0),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: double.infinity,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        const BorderRadius.only(
                                                      bottomLeft:
                                                          Radius.circular(16.0),
                                                      bottomRight:
                                                          Radius.circular(16.0),
                                                      topLeft:
                                                          Radius.circular(16.0),
                                                      topRight:
                                                          Radius.circular(16.0),
                                                    ),
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    15.0,
                                                                    2.0,
                                                                    15.0,
                                                                    12.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Stack(
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      const AlignmentDirectional(
                                                                          0.0,
                                                                          0.0),
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            12.0,
                                                                            0.0,
                                                                            0.0),
                                                                    child:
                                                                        ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              8.0),
                                                                      child:
                                                                          Container(
                                                                        width:
                                                                            90.0,
                                                                        height:
                                                                            90.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryBackground,
                                                                          borderRadius:
                                                                              BorderRadius.circular(8.0),
                                                                          shape:
                                                                              BoxShape.rectangle,
                                                                          border:
                                                                              Border.all(
                                                                            color:
                                                                                FlutterFlowTheme.of(context).primaryText,
                                                                          ),
                                                                        ),
                                                                        child: FutureBuilder<
                                                                            ApiCallResponse>(
                                                                          future:
                                                                              GoogleReviewsCall.call(
                                                                            placeId:
                                                                                FFAppState().placeID,
                                                                          ),
                                                                          builder:
                                                                              (context, snapshot) {
                                                                            // Customize what your widget looks like when it's loading.
                                                                            if (!snapshot.hasData) {
                                                                              return Center(
                                                                                child: SizedBox(
                                                                                  width: 50.0,
                                                                                  height: 50.0,
                                                                                  child: CircularProgressIndicator(
                                                                                    valueColor: AlwaysStoppedAnimation<Color>(
                                                                                      FlutterFlowTheme.of(context).primary,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }
                                                                            final imageGoogleReviewsResponse =
                                                                                snapshot.data!;

                                                                            return ClipRRect(
                                                                              borderRadius: BorderRadius.circular(8.0),
                                                                              child: Image.network(
                                                                                FFAppState().streetViewImageUrl != ''
                                                                                    ? FFAppState().streetViewImageUrl
                                                                                    : 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photo_reference=${getJsonField(
                                                                                        imageGoogleReviewsResponse.jsonBody,
                                                                                        r'''$.photos[0].photo_reference''',
                                                                                      ).toString()}&key=AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE',
                                                                                width: 90.0,
                                                                                height: 90.0,
                                                                                fit: BoxFit.cover,
                                                                                cacheWidth: 1000,
                                                                                cacheHeight: 1000,
                                                                              ),
                                                                            );
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Padding(
                                                                  padding: const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          46.0,
                                                                          82.0,
                                                                          0.0,
                                                                          0.0),
                                                                  child:
                                                                      Container(
                                                                    width: 44.0,
                                                                    height:
                                                                        20.0,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .secondaryBackground,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              4.0),
                                                                      shape: BoxShape
                                                                          .rectangle,
                                                                      border:
                                                                          Border
                                                                              .all(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primaryText,
                                                                        width:
                                                                            1.0,
                                                                      ),
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .center,
                                                                      children: [
                                                                        Padding(
                                                                          padding: const EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              2.0,
                                                                              0.0),
                                                                          child:
                                                                              Text(
                                                                            FFAppState().selectedMarkerRating,
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  fontFamily: 'Plus Jakarta Sans',
                                                                                  fontSize: 12.0,
                                                                                  letterSpacing: 0.0,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                        FaIcon(
                                                                          FontAwesomeIcons
                                                                              .solidStar,
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryText,
                                                                          size:
                                                                              11.0,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            Expanded(
                                                              child: Padding(
                                                                padding: const EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        10.0,
                                                                        12.0,
                                                                        0.0,
                                                                        0.0),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Expanded(
                                                                          child:
                                                                              AutoSizeText(
                                                                            valueOrDefault<String>(
                                                                              FFAppState().selectedMarkerName,
                                                                              'name',
                                                                            ),
                                                                            maxLines:
                                                                                1,
                                                                            minFontSize:
                                                                                8.0,
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  fontFamily: 'Plus Jakarta Sans',
                                                                                  fontSize: 14.0,
                                                                                  letterSpacing: 0.0,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    if (FFAppState()
                                                                            .selectedMarkerVicinity !=
                                                                        FFAppState()
                                                                            .FYPCarParkName)
                                                                      Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          Expanded(
                                                                            child:
                                                                                AutoSizeText(
                                                                              valueOrDefault<String>(
                                                                                FFAppState().selectedMarkerVicinity,
                                                                                'vic',
                                                                              ),
                                                                              minFontSize: 5.0,
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Plus Jakarta Sans',
                                                                                    fontSize: 9.0,
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    if (FFAppState()
                                                                            .selectedMarkerVicinity ==
                                                                        FFAppState()
                                                                            .FYPCarParkName)
                                                                      Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          RichText(
                                                                            textScaler:
                                                                                MediaQuery.of(context).textScaler,
                                                                            text:
                                                                                TextSpan(
                                                                              children: [
                                                                                TextSpan(
                                                                                  text: FFAppState().selectedMarkerVicinity,
                                                                                  style: const TextStyle(
                                                                                    color: Color(0xFFB5A21A),
                                                                                    fontWeight: FontWeight.w500,
                                                                                    fontSize: 12.0,
                                                                                  ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: FFLocalizations.of(context).getText(
                                                                                    'r2x347we' /* * */,
                                                                                  ),
                                                                                  style: const TextStyle(
                                                                                    color: Color(0xFFB5A21A),
                                                                                  ),
                                                                                )
                                                                              ],
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Plus Jakarta Sans',
                                                                                    fontSize: 9.0,
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Builder(
                                                                          builder:
                                                                              (context) {
                                                                            if ((FFAppState().dayToday == 'Monday') ||
                                                                                (FFAppState().dayToday == 'Tuesday') ||
                                                                                (FFAppState().dayToday == 'Wednesday') ||
                                                                                (FFAppState().dayToday == 'Thursday') ||
                                                                                (FFAppState().dayToday == 'Friday')) {
                                                                              return RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: valueOrDefault<String>(
                                                                                        FFAppState().selectedMarkerWeekdayRate,
                                                                                        'tt',
                                                                                      ),
                                                                                      style: const TextStyle(
                                                                                        color: Color(0xFFB5A21A),
                                                                                      ),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'cg0uwtz4' /*   */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'k6pgyjmj' /* per */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'qlmf9519' /*   */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: valueOrDefault<String>(
                                                                                        FFAppState().selectedMarkerWeekdayRateTiming,
                                                                                        'uy',
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              );
                                                                            } else if (FFAppState().dayToday == 'Saturday') {
                                                                              return RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: valueOrDefault<String>(
                                                                                        FFAppState().selectedMarkerSaturdayRate,
                                                                                        'y',
                                                                                      ),
                                                                                      style: const TextStyle(
                                                                                        color: Color(0xFFB5A21A),
                                                                                      ),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'c7kbku3t' /*   */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        '2ugy2o2z' /*  per  */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'ha5ay0tf' /*   */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: valueOrDefault<String>(
                                                                                        FFAppState().selectedMarkerSatRateTiming,
                                                                                        'ii',
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              );
                                                                            } else {
                                                                              return RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: FFAppState().selectedMarkerSundayRate,
                                                                                      style: const TextStyle(
                                                                                        color: Color(0xFFB5A21A),
                                                                                      ),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'v47kktw8' /*   */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'yatieo58' /*  per  */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'xaq9kh0t' /*   */,
                                                                                      ),
                                                                                      style: const TextStyle(),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFAppState().selectedMarkerSunRateTiming,
                                                                                      style: const TextStyle(),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              );
                                                                            }
                                                                          },
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        width: double.infinity,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryBackground,
                                                        ),
                                                      ),
                                                      const Divider(
                                                        height: 4.0,
                                                        thickness: 1.0,
                                                        color:
                                                            Color(0xFFE0E3E7),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    10.0,
                                                                    12.0,
                                                                    10.0,
                                                                    20.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Flexible(
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            5.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                child: FutureBuilder<
                                                                    ApiCallResponse>(
                                                                  future:
                                                                      GoogleReviewsCall
                                                                          .call(
                                                                    placeId:
                                                                        FFAppState()
                                                                            .placeID,
                                                                  ),
                                                                  builder: (context,
                                                                      snapshot) {
                                                                    // Customize what your widget looks like when it's loading.
                                                                    if (!snapshot
                                                                        .hasData) {
                                                                      return Center(
                                                                        child:
                                                                            SizedBox(
                                                                          width:
                                                                              50.0,
                                                                          height:
                                                                              50.0,
                                                                          child:
                                                                              CircularProgressIndicator(
                                                                            valueColor:
                                                                                AlwaysStoppedAnimation<Color>(
                                                                              FlutterFlowTheme.of(context).primary,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }
                                                                    final columnGoogleReviewsResponse =
                                                                        snapshot
                                                                            .data!;

                                                                    return Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        if (GoogleReviewsCall.opennowbool(
                                                                              columnGoogleReviewsResponse.jsonBody,
                                                                            ) ==
                                                                            false)
                                                                          Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        't3j18fdu' /* Closed now */,
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Plus Jakarta Sans',
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        if (GoogleReviewsCall.opennowbool(
                                                                              columnGoogleReviewsResponse.jsonBody,
                                                                            ) ==
                                                                            true)
                                                                          Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'jl69umo6' /* Open now */,
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Plus Jakarta Sans',
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: [
                                                                            RichText(
                                                                              textScaler: MediaQuery.of(context).textScaler,
                                                                              text: TextSpan(
                                                                                children: [
                                                                                  TextSpan(
                                                                                    text: FFLocalizations.of(context).getText(
                                                                                      '8qp031gv' /* Distance:  */,
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Plus Jakarta Sans',
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.bold,
                                                                                        ),
                                                                                  ),
                                                                                  TextSpan(
                                                                                    text: valueOrDefault<String>(
                                                                                      DistanceMatrixCall.distance(
                                                                                        stackDistanceMatrixResponse.jsonBody,
                                                                                      ),
                                                                                      'distance',
                                                                                    ),
                                                                                    style: const TextStyle(
                                                                                      color: Color(0xFFB5A21A),
                                                                                    ),
                                                                                  )
                                                                                ],
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Plus Jakarta Sans',
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                        if (FFAppState().selectedMarkerVicinity !=
                                                                            FFAppState().FYPCarParkName)
                                                                          Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'biuehns5' /* Slots available:  */,
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Plus Jakarta Sans',
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: valueOrDefault<String>(
                                                                                        FFAppState().selectedMarkerAvail.toString(),
                                                                                        'availSlots',
                                                                                      ),
                                                                                      style: const TextStyle(
                                                                                        color: Color(0xFFB5A21A),
                                                                                      ),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        if (FFAppState().selectedMarkerVicinity ==
                                                                            FFAppState().FYPCarParkName)
                                                                          Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              RichText(
                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                text: TextSpan(
                                                                                  children: [
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'bed4xao2' /* Slots available:  */,
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Plus Jakarta Sans',
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFAppState().FYPTotalAvail.toString(),
                                                                                      style: const TextStyle(
                                                                                        color: Color(0xFFB5A21A),
                                                                                      ),
                                                                                    ),
                                                                                    TextSpan(
                                                                                      text: FFLocalizations.of(context).getText(
                                                                                        'txjbiu18' /* * */,
                                                                                      ),
                                                                                      style: const TextStyle(
                                                                                        color: Color(0xFFB5A21A),
                                                                                      ),
                                                                                    )
                                                                                  ],
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Plus Jakarta Sans',
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                      ],
                                                                    );
                                                                  },
                                                                ),
                                                              ),
                                                            ),
                                                            Flexible(
                                                              child: Container(
                                                                width: 90.0,
                                                                height: 60.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryBackground,
                                                                ),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    Padding(
                                                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          5.0,
                                                                          0.0),
                                                                      child:
                                                                          FFButtonWidget(
                                                                        onPressed:
                                                                            () async {
                                                                          logFirebaseEvent(
                                                                              'MAP_PAGE_PAGE_VIEW_BTN_ON_TAP');
                                                                          logFirebaseEvent(
                                                                              'Button_navigate_to');

                                                                          context
                                                                              .pushNamed(
                                                                            'ParkingLocationDetailsPage',
                                                                            queryParameters:
                                                                                {
                                                                              'name': serializeParam(
                                                                                FFAppState().selectedMarkerName,
                                                                                ParamType.String,
                                                                              ),
                                                                              'vicinity': serializeParam(
                                                                                FFAppState().selectedMarkerVicinity,
                                                                                ParamType.String,
                                                                              ),
                                                                            }.withoutNulls,
                                                                          );

                                                                          logFirebaseEvent(
                                                                              'Button_google_analytics_event');
                                                                          logFirebaseEvent(
                                                                            'carPark_Interest',
                                                                            parameters: {
                                                                              'carparkName': FFAppState().selectedMarkerName,
                                                                            },
                                                                          );
                                                                        },
                                                                        text: FFLocalizations.of(context)
                                                                            .getText(
                                                                          '78afg87s' /* View */,
                                                                        ),
                                                                        options:
                                                                            FFButtonOptions(
                                                                          height:
                                                                              40.0,
                                                                          padding: const EdgeInsetsDirectional.fromSTEB(
                                                                              24.0,
                                                                              0.0,
                                                                              24.0,
                                                                              0.0),
                                                                          iconPadding: const EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              0.0),
                                                                          color:
                                                                              FlutterFlowTheme.of(context).warning,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .override(
                                                                                fontFamily: 'Plus Jakarta Sans',
                                                                                color: FlutterFlowTheme.of(context).background,
                                                                                letterSpacing: 0.0,
                                                                              ),
                                                                          elevation:
                                                                              3.0,
                                                                          borderSide:
                                                                              const BorderSide(
                                                                            color:
                                                                                Colors.transparent,
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(8.0),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    if (FFAppState()
                                                                            .selectedMarkerVicinity ==
                                                                        FFAppState()
                                                                            .FYPCarParkName)
                                                                      Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.end,
                                                                        children: [
                                                                          Expanded(
                                                                            child:
                                                                                AutoSizeText(
                                                                              FFLocalizations.of(context).getText(
                                                                                'q9o4xfy9' /* * from FYP */,
                                                                              ),
                                                                              minFontSize: 5.0,
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Plus Jakarta Sans',
                                                                                    color: const Color(0xFFB5A21A),
                                                                                    fontSize: 9.0,
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                }
                              },
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}
