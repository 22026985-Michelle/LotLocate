import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'live_location_to_destination_page_model.dart';
export 'live_location_to_destination_page_model.dart';

class LiveLocationToDestinationPageWidget extends StatefulWidget {
  const LiveLocationToDestinationPageWidget({super.key});

  @override
  State<LiveLocationToDestinationPageWidget> createState() =>
      _LiveLocationToDestinationPageWidgetState();
}

class _LiveLocationToDestinationPageWidgetState
    extends State<LiveLocationToDestinationPageWidget> {
  late LiveLocationToDestinationPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LiveLocationToDestinationPageModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'LiveLocationToDestinationPage'});
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: const SafeArea(
          top: true,
          child: SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: custom_widgets.GMap(
              width: double.infinity,
              height: double.infinity,
            ),
          ),
        ),
      ),
    );
  }
}
