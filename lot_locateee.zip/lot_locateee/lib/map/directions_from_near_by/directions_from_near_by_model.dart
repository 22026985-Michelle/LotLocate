import '/flutter_flow/flutter_flow_util.dart';
import 'directions_from_near_by_widget.dart' show DirectionsFromNearByWidget;
import 'package:flutter/material.dart';

class DirectionsFromNearByModel
    extends FlutterFlowModel<DirectionsFromNearByWidget> {
  ///  Local state fields for this page.

  bool directionsActive = false;

  bool showStartPlaces = false;

  bool showEndPlaces = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Custom Action - reverseGeocode] action in DynamicMap widget.
  List<dynamic>? reverseGeocodeJSON;
  // State field(s) for startTextField1 widget.
  final startTextField1Key = GlobalKey();
  FocusNode? startTextField1FocusNode;
  TextEditingController? startTextField1TextController;
  String? startTextField1SelectedOption;
  String? Function(BuildContext, String?)?
      startTextField1TextControllerValidator;
  // Stores action output result for [Custom Action - forwardGeocode] action in startTextField1 widget.
  List<dynamic>? startPlacesJSON;
  // State field(s) for endTextField2 widget.
  final endTextField2Key = GlobalKey();
  FocusNode? endTextField2FocusNode;
  TextEditingController? endTextField2TextController;
  String? endTextField2SelectedOption;
  String? Function(BuildContext, String?)? endTextField2TextControllerValidator;
  // Stores action output result for [Custom Action - forwardGeocode] action in endTextField2 widget.
  List<dynamic>? endPlacesJSON;
  // Stores action output result for [Custom Action - getRouteFromPoints] action in YourLocationText widget.
  List<String>? routeFromStartCopy;
  // Stores action output result for [Custom Action - getRouteFromPoints] action in Container widget.
  List<String>? routeFromStart;
  // Stores action output result for [Custom Action - getRouteFromPoints] action in Container widget.
  List<String>? routeFromEnd;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    startTextField1FocusNode?.dispose();

    endTextField2FocusNode?.dispose();
  }
}
