import '/flutter_flow/flutter_flow_util.dart';
import 'display_directions_widget.dart' show DisplayDirectionsWidget;
import 'package:flutter/material.dart';

class DisplayDirectionsModel extends FlutterFlowModel<DisplayDirectionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
