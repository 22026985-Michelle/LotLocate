import '/flutter_flow/flutter_flow_util.dart';
import 'directions_bottom_sheet_copy_widget.dart'
    show DirectionsBottomSheetCopyWidget;
import 'package:flutter/material.dart';

class DirectionsBottomSheetCopyModel
    extends FlutterFlowModel<DirectionsBottomSheetCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
