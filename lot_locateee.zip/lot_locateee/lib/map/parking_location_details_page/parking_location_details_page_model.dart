import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'parking_location_details_page_widget.dart'
    show ParkingLocationDetailsPageWidget;
import 'package:flutter/material.dart';

class ParkingLocationDetailsPageModel
    extends FlutterFlowModel<ParkingLocationDetailsPageWidget> {
  ///  Local state fields for this page.

  String? pageUpdate = '';

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Custom Action - getFavourites] action in ParkingLocationDetailsPage widget.
  List<dynamic>? userFavs;
  // Stores action output result for [Backend Call - Insert Row] action in Icon widget.
  StatsRow? jn;
  // State field(s) for RatingBar widget.
  double? ratingBarValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
