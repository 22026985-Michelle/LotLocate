import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'directions_page_widget.dart' show DirectionsPageWidget;
import 'package:flutter/material.dart';

class DirectionsPageModel extends FlutterFlowModel<DirectionsPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for originTextField widget.
  final originTextFieldKey = GlobalKey();
  FocusNode? originTextFieldFocusNode;
  TextEditingController? originTextFieldTextController;
  String? originTextFieldSelectedOption;
  String? Function(BuildContext, String?)?
      originTextFieldTextControllerValidator;
  // Stores action output result for [Backend Call - API (GetAddress)] action in originTextField widget.
  ApiCallResponse? apiResultusr;
  // Stores action output result for [Backend Call - API (GetReference)] action in originTextField widget.
  ApiCallResponse? apiResultycg;
  // State field(s) for destinationTextField widget.
  final destinationTextFieldKey = GlobalKey();
  FocusNode? destinationTextFieldFocusNode;
  TextEditingController? destinationTextFieldTextController;
  String? destinationTextFieldSelectedOption;
  String? Function(BuildContext, String?)?
      destinationTextFieldTextControllerValidator;
  // Stores action output result for [Backend Call - API (GetAddress)] action in destinationTextField widget.
  ApiCallResponse? apiResultusr2;
  // Stores action output result for [Backend Call - API (GetReference)] action in destinationTextField widget.
  ApiCallResponse? apiResultycg2;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    originTextFieldFocusNode?.dispose();

    destinationTextFieldFocusNode?.dispose();
  }
}
