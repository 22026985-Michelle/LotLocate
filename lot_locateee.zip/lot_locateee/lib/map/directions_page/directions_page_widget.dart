import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_autocomplete_options_list.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'directions_page_model.dart';
export 'directions_page_model.dart';

class DirectionsPageWidget extends StatefulWidget {
  const DirectionsPageWidget({super.key});

  @override
  State<DirectionsPageWidget> createState() => _DirectionsPageWidgetState();
}

class _DirectionsPageWidgetState extends State<DirectionsPageWidget> {
  late DirectionsPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool originTextFieldFocusListenerRegistered = false;
  bool destinationTextFieldFocusListenerRegistered = false;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DirectionsPageModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'DirectionsPage'});
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('DIRECTIONS_DirectionsPage_ON_INIT_STATE');
      logFirebaseEvent('DirectionsPage_update_app_state');
      FFAppState().instructionsSheet = false;
      setState(() {});
    });

    _model.originTextFieldTextController ??= TextEditingController(
        text: valueOrDefault<String>(
      FFAppState().carparkOrigin,
      'Your current location',
    ));

    _model.destinationTextFieldTextController ??=
        TextEditingController(text: FFAppState().carparkDestination);

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return FutureBuilder<ApiCallResponse>(
      future: GetDirectionsCall.call(
        destination: FFAppState().carparkDestination,
        origin: FFAppState().carparkOrigin,
        mode: FFAppState().carparkMode,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        final directionsPageGetDirectionsResponse = snapshot.data!;

        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            resizeToAvoidBottomInset: false,
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            body: FutureBuilder<ApiCallResponse>(
              future: GetAddressCall.call(),
              builder: (context, snapshot) {
                // Customize what your widget looks like when it's loading.
                if (!snapshot.hasData) {
                  return Center(
                    child: SizedBox(
                      width: 50.0,
                      height: 50.0,
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(
                          FlutterFlowTheme.of(context).primary,
                        ),
                      ),
                    ),
                  );
                }
                final columnGetAddressResponse = snapshot.data!;

                return InkWell(
                  splashColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () async {
                    logFirebaseEvent('DIRECTIONS_Column_loz2klh4_ON_TAP');
                    logFirebaseEvent('Column_update_app_state');
                    FFAppState().carparkMode = valueOrDefault<String>(
                      GetDirectionsCall.stepsTravelMode(
                        directionsPageGetDirectionsResponse.jsonBody,
                      )?[valueOrDefault<int>(
                        FFAppState().addresses.toList().indexOf(
                            _model.destinationTextFieldTextController.text),
                        0,
                      )],
                      'd',
                    );
                    setState(() {});
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Padding(
                        padding:
                            const EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                        child: FutureBuilder<ApiCallResponse>(
                          future: GetReferenceCall.call(),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            final containerGetReferenceResponse =
                                snapshot.data!;

                            return Container(
                              width: double.infinity,
                              height: 115.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        50.0, 0.0, 50.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 6.0, 0.0),
                                          child: Icon(
                                            Icons.radio_button_checked_outlined,
                                            color: Color(0xFF0100FF),
                                            size: 18.0,
                                          ),
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.all(3.0),
                                            child: Autocomplete<String>(
                                              initialValue: TextEditingValue(
                                                  text: valueOrDefault<String>(
                                                FFAppState().carparkOrigin,
                                                'Your current location',
                                              )),
                                              optionsBuilder:
                                                  (textEditingValue) {
                                                if (textEditingValue.text ==
                                                    '') {
                                                  return const Iterable<
                                                      String>.empty();
                                                }
                                                return FFAppState()
                                                    .addresses
                                                    .where((option) {
                                                  final lowercaseOption =
                                                      option.toLowerCase();
                                                  return lowercaseOption
                                                      .contains(textEditingValue
                                                          .text
                                                          .toLowerCase());
                                                });
                                              },
                                              optionsViewBuilder: (context,
                                                  onSelected, options) {
                                                return AutocompleteOptionsList(
                                                  textFieldKey:
                                                      _model.originTextFieldKey,
                                                  textController: _model
                                                      .originTextFieldTextController!,
                                                  options: options.toList(),
                                                  onSelected: onSelected,
                                                  textStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily:
                                                                'Plus Jakarta Sans',
                                                            letterSpacing: 0.0,
                                                          ),
                                                  textHighlightStyle:
                                                      const TextStyle(),
                                                  elevation: 4.0,
                                                  optionBackgroundColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .primaryBackground,
                                                  optionHighlightColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .secondaryBackground,
                                                  maxHeight: 200.0,
                                                );
                                              },
                                              onSelected: (String selection) {
                                                setState(() => _model
                                                        .originTextFieldSelectedOption =
                                                    selection);
                                                FocusScope.of(context)
                                                    .unfocus();
                                              },
                                              fieldViewBuilder: (
                                                context,
                                                textEditingController,
                                                focusNode,
                                                onEditingComplete,
                                              ) {
                                                _model.originTextFieldFocusNode =
                                                    focusNode;
                                                if (!originTextFieldFocusListenerRegistered) {
                                                  originTextFieldFocusListenerRegistered =
                                                      true;
                                                  _model
                                                      .originTextFieldFocusNode!
                                                      .addListener(
                                                    () async {
                                                      logFirebaseEvent(
                                                          'DIRECTIONS_originTextField_ON_FOCUS_CHAN');
                                                      logFirebaseEvent(
                                                          'originTextField_backend_call');
                                                      _model.apiResultycg =
                                                          await GetReferenceCall
                                                              .call(
                                                        input: valueOrDefault<
                                                            String>(
                                                          FFAppState().placeids[
                                                              valueOrDefault<
                                                                  int>(
                                                            FFAppState()
                                                                .addresses
                                                                .toList()
                                                                .indexOf((_model
                                                                    .originTextFieldSelectedOption!)),
                                                            0,
                                                          )],
                                                          'e',
                                                        ),
                                                      );

                                                      if ((_model.apiResultycg
                                                              ?.succeeded ??
                                                          true)) {
                                                        logFirebaseEvent(
                                                            'originTextField_update_app_state');
                                                        FFAppState().location =
                                                            functions
                                                                .makeLatLon(
                                                                    valueOrDefault<
                                                                        double>(
                                                                      GetReferenceCall
                                                                          .lat(
                                                                        (_model.apiResultycg?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      0.0,
                                                                    ),
                                                                    valueOrDefault<
                                                                        double>(
                                                                      GetReferenceCall
                                                                          .lng(
                                                                        (_model.apiResultycg?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      0.0,
                                                                    ));
                                                        logFirebaseEvent(
                                                            'originTextField_update_app_state');
                                                        FFAppState().addToMarkers(
                                                            functions
                                                                .makeLatLon(
                                                                    valueOrDefault<
                                                                        double>(
                                                                      GetReferenceCall
                                                                          .lat(
                                                                        (_model.apiResultycg?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      0.0,
                                                                    ),
                                                                    valueOrDefault<
                                                                        double>(
                                                                      GetReferenceCall
                                                                          .lng(
                                                                        (_model.apiResultycg?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      0.0,
                                                                    )));
                                                        setState(() {});
                                                        logFirebaseEvent(
                                                            'originTextField_update_app_state');
                                                        FFAppState()
                                                                .carparkOrigin =
                                                            valueOrDefault<
                                                                String>(
                                                          _model
                                                              .originTextFieldTextController
                                                              .text,
                                                          'ff',
                                                        );
                                                      } else {
                                                        logFirebaseEvent(
                                                            'originTextField_alert_dialog');
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: const Text(
                                                                  'API Call'),
                                                              content: Text((_model
                                                                          .apiResultycg
                                                                          ?.succeeded ??
                                                                      true)
                                                                  .toString()),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: const Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      }

                                                      setState(() {});
                                                    },
                                                  );
                                                }
                                                _model.originTextFieldTextController =
                                                    textEditingController;
                                                return TextFormField(
                                                  key:
                                                      _model.originTextFieldKey,
                                                  controller:
                                                      textEditingController,
                                                  focusNode: focusNode,
                                                  onEditingComplete:
                                                      onEditingComplete,
                                                  onChanged: (_) =>
                                                      EasyDebounce.debounce(
                                                    '_model.originTextFieldTextController',
                                                    const Duration(milliseconds: 100),
                                                    () async {
                                                      logFirebaseEvent(
                                                          'DIRECTIONS_originTextField_ON_TEXTFIELD_');
                                                      logFirebaseEvent(
                                                          'originTextField_backend_call');
                                                      _model.apiResultusr =
                                                          await GetAddressCall
                                                              .call(
                                                        input: _model
                                                            .originTextFieldTextController
                                                            .text,
                                                      );

                                                      if ((_model.apiResultusr
                                                              ?.succeeded ??
                                                          true)) {
                                                        logFirebaseEvent(
                                                            'originTextField_update_app_state');
                                                        FFAppState().addresses =
                                                            GetAddressCall
                                                                    .addresses(
                                                          (_model.apiResultusr
                                                                  ?.jsonBody ??
                                                              ''),
                                                        )!
                                                                .toList()
                                                                .cast<String>();
                                                        setState(() {});
                                                        logFirebaseEvent(
                                                            'originTextField_update_app_state');
                                                        FFAppState().placeids =
                                                            GetAddressCall
                                                                    .placeid(
                                                          (_model.apiResultusr
                                                                  ?.jsonBody ??
                                                              ''),
                                                        )!
                                                                .toList()
                                                                .cast<String>();
                                                        setState(() {});
                                                      } else {
                                                        logFirebaseEvent(
                                                            'originTextField_alert_dialog');
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: const Text(
                                                                  'API Call'),
                                                              content: Text((_model
                                                                      .apiResultusr
                                                                      ?.bodyText ??
                                                                  '')),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: const Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      }

                                                      setState(() {});
                                                    },
                                                  ),
                                                  autofocus: true,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      '1pepovqr' /* Origin */,
                                                    ),
                                                    labelStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .labelMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    hintText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      '0flemq79' /* Choose starting point */,
                                                    ),
                                                    hintStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .labelMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .alternate,
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide: const BorderSide(
                                                        color:
                                                            Color(0xFF5E5603),
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .error,
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                    focusedErrorBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .error,
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily:
                                                            'Plus Jakarta Sans',
                                                        letterSpacing: 0.0,
                                                      ),
                                                  validator: _model
                                                      .originTextFieldTextControllerValidator
                                                      .asValidator(context),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        50.0, 0.0, 50.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        const Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  2.0, 0.0, 8.0, 0.0),
                                          child: FaIcon(
                                            FontAwesomeIcons.mapMarkerAlt,
                                            color: Color(0xFFFB000D),
                                            size: 19.0,
                                          ),
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.all(3.0),
                                            child: Autocomplete<String>(
                                              initialValue: TextEditingValue(
                                                  text: FFAppState()
                                                      .carparkDestination),
                                              optionsBuilder:
                                                  (textEditingValue) {
                                                if (textEditingValue.text ==
                                                    '') {
                                                  return const Iterable<
                                                      String>.empty();
                                                }
                                                return FFAppState()
                                                    .addresses
                                                    .where((option) {
                                                  final lowercaseOption =
                                                      option.toLowerCase();
                                                  return lowercaseOption
                                                      .contains(textEditingValue
                                                          .text
                                                          .toLowerCase());
                                                });
                                              },
                                              optionsViewBuilder: (context,
                                                  onSelected, options) {
                                                return AutocompleteOptionsList(
                                                  textFieldKey: _model
                                                      .destinationTextFieldKey,
                                                  textController: _model
                                                      .destinationTextFieldTextController!,
                                                  options: options.toList(),
                                                  onSelected: onSelected,
                                                  textStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily:
                                                                'Plus Jakarta Sans',
                                                            letterSpacing: 0.0,
                                                          ),
                                                  textHighlightStyle:
                                                      const TextStyle(),
                                                  elevation: 4.0,
                                                  optionBackgroundColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .primaryBackground,
                                                  optionHighlightColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .secondaryBackground,
                                                  maxHeight: 200.0,
                                                );
                                              },
                                              onSelected: (String selection) {
                                                setState(() => _model
                                                        .destinationTextFieldSelectedOption =
                                                    selection);
                                                FocusScope.of(context)
                                                    .unfocus();
                                              },
                                              fieldViewBuilder: (
                                                context,
                                                textEditingController,
                                                focusNode,
                                                onEditingComplete,
                                              ) {
                                                _model.destinationTextFieldFocusNode =
                                                    focusNode;
                                                if (!destinationTextFieldFocusListenerRegistered) {
                                                  destinationTextFieldFocusListenerRegistered =
                                                      true;
                                                  _model
                                                      .destinationTextFieldFocusNode!
                                                      .addListener(
                                                    () async {
                                                      logFirebaseEvent(
                                                          'DIRECTIONS_destinationTextField_ON_FOCUS');
                                                      logFirebaseEvent(
                                                          'destinationTextField_backend_call');
                                                      _model.apiResultycg2 =
                                                          await GetReferenceCall
                                                              .call(
                                                        input: valueOrDefault<
                                                            String>(
                                                          FFAppState().placeids[
                                                              valueOrDefault<
                                                                  int>(
                                                            FFAppState()
                                                                .addresses
                                                                .toList()
                                                                .indexOf(_model
                                                                    .destinationTextFieldTextController
                                                                    .text),
                                                            0,
                                                          )],
                                                          'yt',
                                                        ),
                                                      );

                                                      if ((_model.apiResultycg2
                                                              ?.succeeded ??
                                                          true)) {
                                                        logFirebaseEvent(
                                                            'destinationTextField_update_app_state');
                                                        FFAppState().location =
                                                            functions
                                                                .makeLatLon(
                                                                    GetReferenceCall
                                                                        .lat(
                                                                      (_model.apiResultycg2
                                                                              ?.jsonBody ??
                                                                          ''),
                                                                    )!,
                                                                    GetReferenceCall
                                                                        .lng(
                                                                      (_model.apiResultycg2
                                                                              ?.jsonBody ??
                                                                          ''),
                                                                    )!);
                                                        logFirebaseEvent(
                                                            'destinationTextField_update_app_state');
                                                        FFAppState().addToMarkers(
                                                            functions
                                                                .makeLatLon(
                                                                    valueOrDefault<
                                                                        double>(
                                                                      GetReferenceCall
                                                                          .lat(
                                                                        (_model.apiResultycg2?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      0.0,
                                                                    ),
                                                                    valueOrDefault<
                                                                        double>(
                                                                      GetReferenceCall
                                                                          .lng(
                                                                        (_model.apiResultycg2?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      0.0,
                                                                    )));
                                                        setState(() {});
                                                        logFirebaseEvent(
                                                            'destinationTextField_update_app_state');
                                                        FFAppState()
                                                                .carparkDestination =
                                                            valueOrDefault<
                                                                String>(
                                                          _model
                                                              .destinationTextFieldTextController
                                                              .text,
                                                          'fh',
                                                        );
                                                      } else {
                                                        logFirebaseEvent(
                                                            'destinationTextField_alert_dialog');
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: const Text(
                                                                  'API Call'),
                                                              content: Text((_model
                                                                      .apiResultycg2
                                                                      ?.bodyText ??
                                                                  '')),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: const Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      }

                                                      logFirebaseEvent(
                                                          'destinationTextField_navigate_to');

                                                      context.pushNamed(
                                                          'DirectionsPage');

                                                      logFirebaseEvent(
                                                          'destinationTextField_update_app_state');
                                                      FFAppState()
                                                              .instructionsSheet =
                                                          true;
                                                      FFAppState().travelRow =
                                                          true;
                                                      setState(() {});

                                                      setState(() {});
                                                    },
                                                  );
                                                }
                                                _model.destinationTextFieldTextController =
                                                    textEditingController;
                                                return TextFormField(
                                                  key: _model
                                                      .destinationTextFieldKey,
                                                  controller:
                                                      textEditingController,
                                                  focusNode: focusNode,
                                                  onEditingComplete:
                                                      onEditingComplete,
                                                  onChanged: (_) =>
                                                      EasyDebounce.debounce(
                                                    '_model.destinationTextFieldTextController',
                                                    const Duration(milliseconds: 100),
                                                    () async {
                                                      logFirebaseEvent(
                                                          'DIRECTIONS_destinationTextField_ON_TEXTF');
                                                      logFirebaseEvent(
                                                          'destinationTextField_backend_call');
                                                      _model.apiResultusr2 =
                                                          await GetAddressCall
                                                              .call(
                                                        input: _model
                                                            .destinationTextFieldTextController
                                                            .text,
                                                      );

                                                      if ((_model.apiResultusr2
                                                              ?.succeeded ??
                                                          true)) {
                                                        logFirebaseEvent(
                                                            'destinationTextField_update_app_state');
                                                        FFAppState().addresses =
                                                            GetAddressCall
                                                                    .addresses(
                                                          (_model.apiResultusr2
                                                                  ?.jsonBody ??
                                                              ''),
                                                        )!
                                                                .toList()
                                                                .cast<String>();
                                                        setState(() {});
                                                        logFirebaseEvent(
                                                            'destinationTextField_update_app_state');
                                                        FFAppState().placeids =
                                                            GetAddressCall
                                                                    .placeid(
                                                          (_model.apiResultusr2
                                                                  ?.jsonBody ??
                                                              ''),
                                                        )!
                                                                .toList()
                                                                .cast<String>();
                                                        setState(() {});
                                                      } else {
                                                        logFirebaseEvent(
                                                            'destinationTextField_alert_dialog');
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: const Text(
                                                                  'API Call'),
                                                              content: Text((_model
                                                                          .apiResultusr2
                                                                          ?.succeeded ??
                                                                      true)
                                                                  .toString()),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: const Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      }

                                                      setState(() {});
                                                    },
                                                  ),
                                                  autofocus: true,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      'gcm24lec' /* Destination */,
                                                    ),
                                                    labelStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .labelMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    hintText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      'ux0pjx4t' /* Choose destination */,
                                                    ),
                                                    hintStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .labelMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .alternate,
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide: const BorderSide(
                                                        color:
                                                            Color(0xFF5E5603),
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .error,
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                    focusedErrorBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .error,
                                                        width: 2.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8.0),
                                                    ),
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily:
                                                            'Plus Jakarta Sans',
                                                        letterSpacing: 0.0,
                                                      ),
                                                  validator: _model
                                                      .destinationTextFieldTextControllerValidator
                                                      .asValidator(context),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                      if ((FFAppState().carparkDestination != '') &&
                          (FFAppState().carparkOrigin != ''))
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 100.0,
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    FlutterFlowIconButton(
                                      buttonSize: 40.0,
                                      icon: Icon(
                                        Icons.directions_car,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 24.0,
                                      ),
                                      onPressed: () {
                                        print('IconButton pressed ...');
                                      },
                                    ),
                                    RichText(
                                      textScaler:
                                          MediaQuery.of(context).textScaler,
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                            text: FFLocalizations.of(context)
                                                .getText(
                                              'ntqncm33' /*  */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily:
                                                      'Plus Jakarta Sans',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryText,
                                                  fontSize: 10.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                          ),
                                          TextSpan(
                                            text: FFLocalizations.of(context)
                                                .getText(
                                              'fynwyz7v' /*   */,
                                            ),
                                            style: const TextStyle(),
                                          ),
                                          TextSpan(
                                            text: FFLocalizations.of(context)
                                                .getText(
                                              'y84p5f8n' /* mins */,
                                            ),
                                            style: const TextStyle(),
                                          )
                                        ],
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Plus Jakarta Sans',
                                              fontSize: 10.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'DIRECTIONS_Container_0h4xcoew_ON_TAP');
                                  logFirebaseEvent(
                                      'Container_update_app_state');
                                  FFAppState().carparkMode = 'bicycling';
                                  setState(() {});
                                },
                                child: Container(
                                  width: 100.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      logFirebaseEvent(
                                          'DIRECTIONS_PAGE_PAGE_Row_cmrg3n81_ON_TAP');
                                      logFirebaseEvent('Row_update_app_state');
                                      FFAppState().carparkMode = 'Bicycling';
                                      setState(() {});
                                    },
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        FlutterFlowIconButton(
                                          buttonSize: 40.0,
                                          icon: Icon(
                                            Icons.directions_bike,
                                            color: FlutterFlowTheme.of(context)
                                                .primaryText,
                                            size: 24.0,
                                          ),
                                          onPressed: () {
                                            print('IconButton pressed ...');
                                          },
                                        ),
                                        RichText(
                                          textScaler:
                                              MediaQuery.of(context).textScaler,
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text: valueOrDefault<String>(
                                                  GetDirectionsCall
                                                      .walkingDuration(
                                                    directionsPageGetDirectionsResponse
                                                        .jsonBody,
                                                  )?[valueOrDefault<int>(
                                                    FFAppState()
                                                        .addresses
                                                        .toList()
                                                        .indexOf(_model
                                                            .destinationTextFieldTextController
                                                            .text),
                                                    0,
                                                  )],
                                                  'no',
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryText,
                                                          fontSize: 10.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                              ),
                                              TextSpan(
                                                text:
                                                    FFLocalizations.of(context)
                                                        .getText(
                                                  'mb4s1mpx' /*   */,
                                                ),
                                                style: const TextStyle(),
                                              ),
                                              TextSpan(
                                                text:
                                                    FFLocalizations.of(context)
                                                        .getText(
                                                  'khla6cnu' /* mins */,
                                                ),
                                                style: const TextStyle(),
                                              )
                                            ],
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily:
                                                      'Plus Jakarta Sans',
                                                  fontSize: 10.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'DIRECTIONS_Container_epua66di_ON_TAP');
                                  logFirebaseEvent(
                                      'Container_update_app_state');
                                  FFAppState().carparkMode = 'walking';
                                  setState(() {});
                                },
                                child: Container(
                                  width: 100.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      FlutterFlowIconButton(
                                        buttonSize: 40.0,
                                        icon: Icon(
                                          Icons.directions_walk,
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          size: 24.0,
                                        ),
                                        onPressed: () {
                                          print('IconButton pressed ...');
                                        },
                                      ),
                                      RichText(
                                        textScaler:
                                            MediaQuery.of(context).textScaler,
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text: valueOrDefault<String>(
                                                GetDirectionsCall
                                                    .walkingDuration(
                                                  directionsPageGetDirectionsResponse
                                                      .jsonBody,
                                                )?[valueOrDefault<int>(
                                                  FFAppState()
                                                      .addresses
                                                      .toList()
                                                      .indexOf(_model
                                                          .destinationTextFieldTextController
                                                          .text),
                                                  0,
                                                )],
                                                'dri',
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily:
                                                        'Plus Jakarta Sans',
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    fontSize: 10.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                            ),
                                            TextSpan(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                '057v6jcj' /*   */,
                                              ),
                                              style: const TextStyle(),
                                            ),
                                            TextSpan(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'otjoybpx' /* mins */,
                                              ),
                                              style: const TextStyle(),
                                            )
                                          ],
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                fontSize: 10.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'DIRECTIONS_Container_541n1amo_ON_TAP');
                                  logFirebaseEvent(
                                      'Container_update_app_state');
                                  FFAppState().carparkMode = 'transit';
                                  setState(() {});
                                },
                                child: Container(
                                  width: 100.0,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      FlutterFlowIconButton(
                                        borderColor: Colors.transparent,
                                        borderRadius: 30.0,
                                        buttonSize: 40.0,
                                        icon: Icon(
                                          Icons.directions_bus_rounded,
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          size: 24.0,
                                        ),
                                        onPressed: () {
                                          print('IconButton pressed ...');
                                        },
                                      ),
                                      RichText(
                                        textScaler:
                                            MediaQuery.of(context).textScaler,
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text: valueOrDefault<String>(
                                                GetDirectionsCall
                                                    .walkingDuration(
                                                  directionsPageGetDirectionsResponse
                                                      .jsonBody,
                                                )?[valueOrDefault<int>(
                                                  FFAppState()
                                                      .addresses
                                                      .toList()
                                                      .indexOf(_model
                                                          .destinationTextFieldTextController
                                                          .text),
                                                  0,
                                                )],
                                                'dri',
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily:
                                                        'Plus Jakarta Sans',
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    fontSize: 10.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                            ),
                                            TextSpan(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                '6b50opao' /*   */,
                                              ),
                                              style: const TextStyle(),
                                            ),
                                            TextSpan(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'ryi0dyoy' /* mins */,
                                              ),
                                              style: const TextStyle(),
                                            )
                                          ],
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                fontSize: 10.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      Expanded(
                        child: FlutterFlowGoogleMap(
                          controller: _model.googleMapsController,
                          onCameraIdle: (latLng) =>
                              _model.googleMapsCenter = latLng,
                          initialLocation: _model.googleMapsCenter ??=
                              FFAppState().location!,
                          markers: FFAppState()
                              .markers
                              .map(
                                (marker) => FlutterFlowMarker(
                                  marker.serialize(),
                                  marker,
                                ),
                              )
                              .toList(),
                          markerColor: GoogleMarkerColor.red,
                          mapType: MapType.normal,
                          style: GoogleMapStyle.standard,
                          initialZoom: 14.0,
                          allowInteraction: true,
                          allowZoom: true,
                          showZoomControls: true,
                          showLocation: true,
                          showCompass: false,
                          showMapToolbar: false,
                          showTraffic: false,
                          centerMapOnMarkerTap: true,
                        ),
                      ),
                      if (FFAppState().instructionsSheet)
                        Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 5.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            height: 105.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              boxShadow: const [
                                BoxShadow(
                                  blurRadius: 4.0,
                                  color: Color(0x25090F13),
                                  offset: Offset(
                                    0.0,
                                    2.0,
                                  ),
                                )
                              ],
                              borderRadius: const BorderRadius.only(
                                bottomLeft: Radius.circular(0.0),
                                bottomRight: Radius.circular(0.0),
                                topLeft: Radius.circular(12.0),
                                topRight: Radius.circular(12.0),
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  14.0, 4.0, 14.0, 4.0),
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 60.0,
                                          height: 4.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(2.0),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        FFButtonWidget(
                                          onPressed: () {
                                            print('Button pressed ...');
                                          },
                                          text: FFLocalizations.of(context)
                                              .getText(
                                            'hzo8ls7y' /* Directions */,
                                          ),
                                          icon: const Icon(
                                            Icons.subdirectory_arrow_right,
                                            size: 15.0,
                                          ),
                                          options: FFButtonOptions(
                                            height: 40.0,
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    24.0, 0.0, 24.0, 0.0),
                                            iconPadding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 0.0, 0.0),
                                            color: FlutterFlowTheme.of(context)
                                                .warning,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .override(
                                                      fontFamily:
                                                          'Plus Jakarta Sans',
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .background,
                                                      letterSpacing: 0.0,
                                                    ),
                                            elevation: 3.0,
                                            borderSide: const BorderSide(
                                              color: Colors.transparent,
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(22.0),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: double.infinity,
                                          height: 50.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                          ),
                                          child: Text(
                                            valueOrDefault<String>(
                                              GetDirectionsCall.instructions(
                                                directionsPageGetDirectionsResponse
                                                    .jsonBody,
                                              )?[valueOrDefault<int>(
                                                FFAppState()
                                                    .addresses
                                                    .toList()
                                                    .indexOf(_model
                                                        .destinationTextFieldTextController
                                                        .text),
                                                0,
                                              )],
                                              'ins',
                                            ),
                                            textAlign: TextAlign.justify,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily:
                                                      'Plus Jakarta Sans',
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
