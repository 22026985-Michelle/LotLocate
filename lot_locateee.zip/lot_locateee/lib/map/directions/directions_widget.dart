import '/flutter_flow/flutter_flow_autocomplete_options_list.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/map/directions_bottom_sheet/directions_bottom_sheet_widget.dart';
import '/custom_code/actions/index.dart' as actions;
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/permissions_util.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'directions_model.dart';
export 'directions_model.dart';

class DirectionsWidget extends StatefulWidget {
  const DirectionsWidget({
    super.key,
    this.rideDetailsReference,
  });

  final DocumentReference? rideDetailsReference;

  @override
  State<DirectionsWidget> createState() => _DirectionsWidgetState();
}

class _DirectionsWidgetState extends State<DirectionsWidget> {
  late DirectionsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  LatLng? currentUserLocationValue;
  bool startTextField1FocusListenerRegistered = false;
  bool endTextField2FocusListenerRegistered = false;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DirectionsModel());

    logFirebaseEvent('screen_view', parameters: {'screen_name': 'Directions'});
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('DIRECTIONS_PAGE_Directions_ON_INIT_STATE');
      currentUserLocationValue =
          await getCurrentUserLocation(defaultLocation: const LatLng(0.0, 0.0));
      logFirebaseEvent('Directions_update_app_state');
      FFAppState().location = currentUserLocationValue;
      FFAppState().instructionsSheet = false;
      setState(() {});
    });

    _model.startTextField1TextController ??= TextEditingController();

    _model.endTextField2TextController ??= TextEditingController();

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).alternate,
          body: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: SizedBox(
                  height: double.infinity,
                  child: Stack(
                    children: [
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          logFirebaseEvent(
                              'DIRECTIONS_Container_fpxy99py_ON_TAP');
                          logFirebaseEvent('DynamicMap_update_app_state');

                          setState(() {});
                        },
                        child: SizedBox(
                          width: double.infinity,
                          height: double.infinity,
                          child: custom_widgets.DynamicMap(
                            width: double.infinity,
                            height: double.infinity,
                            accessToken:
                                'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                            startingPoint: FFAppState().location!,
                            startingZoom: 11.0,
                            reverseGeocodeAction:
                                (accessToken, position) async {
                              logFirebaseEvent(
                                  'DIRECTIONS_Container_fpxy99py_CALLBACK');
                              logFirebaseEvent('DynamicMap_custom_action');
                              _model.reverseGeocodeJSON =
                                  await actions.reverseGeocode(
                                position,
                                accessToken,
                              );

                              setState(() {});
                            },
                          ),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    0.0, 5.0, 0.0, 0.0),
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          logFirebaseEvent(
                                              'DIRECTIONS_Container_a26i9ean_ON_TAP');
                                          logFirebaseEvent(
                                              'Container_update_app_state');
                                          FFAppState().travelType = 'driving';
                                          FFAppState().drivingBool = true;
                                          FFAppState().transitBool = false;
                                          FFAppState().bicyclingBool = false;
                                          FFAppState().walkingBool = false;
                                          FFAppState().update(() {});
                                        },
                                        child: Container(
                                          width: 40.0,
                                          height: 40.0,
                                          decoration: const BoxDecoration(),
                                          child: Builder(
                                            builder: (context) {
                                              if (FFAppState().drivingBool) {
                                                return Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFFBDAD3D),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50.0),
                                                  ),
                                                  child: Icon(
                                                    Icons
                                                        .directions_car_rounded,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    size: 24.0,
                                                  ),
                                                );
                                              } else {
                                                return Icon(
                                                  Icons.directions_car_rounded,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryBackground,
                                                  size: 24.0,
                                                );
                                              }
                                            },
                                          ),
                                        ),
                                      ),
                                      InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          logFirebaseEvent(
                                              'DIRECTIONS_Container_29hs4343_ON_TAP');
                                          logFirebaseEvent(
                                              'Container_update_app_state');
                                          FFAppState().travelType = 'walking';
                                          FFAppState().drivingBool = false;
                                          FFAppState().transitBool = false;
                                          FFAppState().bicyclingBool = false;
                                          FFAppState().walkingBool = true;
                                          setState(() {});
                                        },
                                        child: Container(
                                          width: 40.0,
                                          height: 40.0,
                                          decoration: const BoxDecoration(),
                                          child: Builder(
                                            builder: (context) {
                                              if (FFAppState().walkingBool) {
                                                return Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFFBDAD3D),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50.0),
                                                  ),
                                                  child: Icon(
                                                    Icons
                                                        .directions_walk_outlined,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    size: 24.0,
                                                  ),
                                                );
                                              } else {
                                                return Icon(
                                                  Icons
                                                      .directions_walk_outlined,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryBackground,
                                                  size: 24.0,
                                                );
                                              }
                                            },
                                          ),
                                        ),
                                      ),
                                      InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          logFirebaseEvent(
                                              'DIRECTIONS_Container_3p07qn6y_ON_TAP');
                                          logFirebaseEvent(
                                              'Container_update_app_state');
                                          FFAppState().travelType = 'cycling';
                                          FFAppState().drivingBool = false;
                                          FFAppState().transitBool = false;
                                          FFAppState().bicyclingBool = true;
                                          FFAppState().walkingBool = false;
                                          setState(() {});
                                        },
                                        child: Container(
                                          width: 40.0,
                                          height: 40.0,
                                          decoration: const BoxDecoration(),
                                          child: Builder(
                                            builder: (context) {
                                              if (FFAppState().bicyclingBool) {
                                                return Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFFBDAD3D),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50.0),
                                                  ),
                                                  child: Icon(
                                                    Icons.directions_bike,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    size: 24.0,
                                                  ),
                                                );
                                              } else {
                                                return Icon(
                                                  Icons.directions_bike,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryBackground,
                                                  size: 24.0,
                                                );
                                              }
                                            },
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                decoration: const BoxDecoration(),
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      50.0, 0.0, 50.0, 0.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 6.0, 0.0),
                                        child: Icon(
                                          Icons.radio_button_checked_outlined,
                                          color: Color(0xFF44A921),
                                          size: 18.0,
                                        ),
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.all(3.0),
                                          child: Container(
                                            width: double.infinity,
                                            height: 50.0,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              borderRadius:
                                                  BorderRadius.circular(12.0),
                                              border: Border.all(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .accent4,
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Flexible(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(3.0),
                                                    child: Autocomplete<String>(
                                                      initialValue:
                                                          const TextEditingValue(),
                                                      optionsBuilder:
                                                          (textEditingValue) {
                                                        if (textEditingValue
                                                                .text ==
                                                            '') {
                                                          return const Iterable<
                                                              String>.empty();
                                                        }
                                                        return FFAppState()
                                                            .addresses
                                                            .where((option) {
                                                          final lowercaseOption =
                                                              option
                                                                  .toLowerCase();
                                                          return lowercaseOption
                                                              .contains(
                                                                  textEditingValue
                                                                      .text
                                                                      .toLowerCase());
                                                        });
                                                      },
                                                      optionsViewBuilder:
                                                          (context, onSelected,
                                                              options) {
                                                        return AutocompleteOptionsList(
                                                          textFieldKey: _model
                                                              .startTextField1Key,
                                                          textController: _model
                                                              .startTextField1TextController!,
                                                          options:
                                                              options.toList(),
                                                          onSelected:
                                                              onSelected,
                                                          textStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Plus Jakarta Sans',
                                                                    letterSpacing:
                                                                        0.0,
                                                                  ),
                                                          textHighlightStyle:
                                                              const TextStyle(),
                                                          elevation: 4.0,
                                                          optionBackgroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .primaryBackground,
                                                          optionHighlightColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .secondaryBackground,
                                                          maxHeight: 200.0,
                                                        );
                                                      },
                                                      onSelected:
                                                          (String selection) {
                                                        setState(() => _model
                                                                .startTextField1SelectedOption =
                                                            selection);
                                                        FocusScope.of(context)
                                                            .unfocus();
                                                      },
                                                      fieldViewBuilder: (
                                                        context,
                                                        textEditingController,
                                                        focusNode,
                                                        onEditingComplete,
                                                      ) {
                                                        _model.startTextField1FocusNode =
                                                            focusNode;
                                                        if (!startTextField1FocusListenerRegistered) {
                                                          startTextField1FocusListenerRegistered =
                                                              true;
                                                          _model
                                                              .startTextField1FocusNode!
                                                              .addListener(() =>
                                                                  setState(
                                                                      () {}));
                                                        }
                                                        _model.startTextField1TextController =
                                                            textEditingController;
                                                        return TextFormField(
                                                          key: _model
                                                              .startTextField1Key,
                                                          controller:
                                                              textEditingController,
                                                          focusNode: focusNode,
                                                          onEditingComplete:
                                                              onEditingComplete,
                                                          onChanged: (_) =>
                                                              EasyDebounce
                                                                  .debounce(
                                                            '_model.startTextField1TextController',
                                                            const Duration(
                                                                milliseconds:
                                                                    20),
                                                            () async {
                                                              logFirebaseEvent(
                                                                  'DIRECTIONS_startTextField1_ON_TEXTFIELD_');
                                                              if (_model.startTextField1TextController
                                                                          .text !=
                                                                      '') {
                                                                logFirebaseEvent(
                                                                    'startTextField1_update_page_state');
                                                                _model.showStartPlaces =
                                                                    true;
                                                                _model.showEndPlaces =
                                                                    false;
                                                                setState(() {});
                                                              } else {
                                                                logFirebaseEvent(
                                                                    'startTextField1_update_page_state');
                                                                _model.showStartPlaces =
                                                                    false;
                                                                setState(() {});
                                                                logFirebaseEvent(
                                                                    'startTextField1_update_app_state');
                                                                FFAppState()
                                                                        .instructionsSheet =
                                                                    false;
                                                                setState(() {});
                                                              }

                                                              logFirebaseEvent(
                                                                  'startTextField1_custom_action');
                                                              _model.startPlacesJSON =
                                                                  await actions
                                                                      .forwardGeocode(
                                                                _model
                                                                    .startTextField1TextController
                                                                    .text,
                                                                'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                              );

                                                              setState(() {});
                                                            },
                                                          ),
                                                          autofocus: true,
                                                          obscureText: false,
                                                          decoration:
                                                              InputDecoration(
                                                            labelStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyLarge
                                                                    .override(
                                                                      fontFamily:
                                                                          'Plus Jakarta Sans',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .primaryText,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                            hintText:
                                                                FFLocalizations.of(
                                                                        context)
                                                                    .getText(
                                                              'p2i29bwd' /* Find Starting Point */,
                                                            ),
                                                            hintStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Plus Jakarta Sans',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .primaryText,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                            enabledBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  const BorderSide(
                                                                color: Color(
                                                                    0x00000000),
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            focusedBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  const BorderSide(
                                                                color: Color(
                                                                    0x00000000),
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            errorBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  BorderSide(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .error,
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            focusedErrorBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  BorderSide(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .error,
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            filled: true,
                                                            fillColor: Colors
                                                                .transparent,
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Plus Jakarta Sans',
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .primaryText,
                                                                letterSpacing:
                                                                    0.0,
                                                              ),
                                                          validator: _model
                                                              .startTextField1TextControllerValidator
                                                              .asValidator(
                                                                  context),
                                                        );
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                FlutterFlowIconButton(
                                                  borderRadius: 20.0,
                                                  borderWidth: 1.0,
                                                  buttonSize: 40.0,
                                                  icon: Icon(
                                                    Icons.close_sharp,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryText,
                                                    size: 24.0,
                                                  ),
                                                  onPressed: () async {
                                                    logFirebaseEvent(
                                                        'DIRECTIONS_PAGE_close_sharp_ICN_ON_TAP');
                                                    logFirebaseEvent(
                                                        'IconButton_reset_form_fields');
                                                    setState(() {
                                                      _model
                                                          .startTextField1TextController
                                                          ?.clear();
                                                    });
                                                    logFirebaseEvent(
                                                        'IconButton_update_app_state');
                                                    FFAppState()
                                                            .instructionsSheet =
                                                        false;
                                                    FFAppState()
                                                            .noOfStartPlaces =
                                                        FFAppState()
                                                                .noOfStartPlaces +
                                                            -1;
                                                    FFAppState().STARTMARKER =
                                                        null;
                                                    FFAppState()
                                                        .removeFromPlaces(
                                                            FFAppState()
                                                                .startLocation!);
                                                    FFAppState()
                                                        .removeAtIndexFromRouteCoordinates(
                                                            0);
                                                    setState(() {});
                                                  },
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              if (_model.directionsActive)
                                Container(
                                  decoration: const BoxDecoration(),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        50.0, 0.0, 52.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  2.0, 0.0, 11.0, 0.0),
                                          child: FaIcon(
                                            FontAwesomeIcons.mapMarkerAlt,
                                            color: FlutterFlowTheme.of(context)
                                                .error,
                                            size: 18.0,
                                          ),
                                        ),
                                        Expanded(
                                          child: Container(
                                            width: double.infinity,
                                            height: 50.0,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              borderRadius:
                                                  BorderRadius.circular(12.0),
                                              border: Border.all(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .accent4,
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Flexible(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(3.0),
                                                    child: Autocomplete<String>(
                                                      initialValue:
                                                          const TextEditingValue(),
                                                      optionsBuilder:
                                                          (textEditingValue) {
                                                        if (textEditingValue
                                                                .text ==
                                                            '') {
                                                          return const Iterable<
                                                              String>.empty();
                                                        }
                                                        return FFAppState()
                                                            .addresses
                                                            .where((option) {
                                                          final lowercaseOption =
                                                              option
                                                                  .toLowerCase();
                                                          return lowercaseOption
                                                              .contains(
                                                                  textEditingValue
                                                                      .text
                                                                      .toLowerCase());
                                                        });
                                                      },
                                                      optionsViewBuilder:
                                                          (context, onSelected,
                                                              options) {
                                                        return AutocompleteOptionsList(
                                                          textFieldKey: _model
                                                              .endTextField2Key,
                                                          textController: _model
                                                              .endTextField2TextController!,
                                                          options:
                                                              options.toList(),
                                                          onSelected:
                                                              onSelected,
                                                          textStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Plus Jakarta Sans',
                                                                    letterSpacing:
                                                                        0.0,
                                                                  ),
                                                          textHighlightStyle:
                                                              const TextStyle(),
                                                          elevation: 4.0,
                                                          optionBackgroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .primaryBackground,
                                                          optionHighlightColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .secondaryBackground,
                                                          maxHeight: 200.0,
                                                        );
                                                      },
                                                      onSelected:
                                                          (String selection) {
                                                        setState(() => _model
                                                                .endTextField2SelectedOption =
                                                            selection);
                                                        FocusScope.of(context)
                                                            .unfocus();
                                                      },
                                                      fieldViewBuilder: (
                                                        context,
                                                        textEditingController,
                                                        focusNode,
                                                        onEditingComplete,
                                                      ) {
                                                        _model.endTextField2FocusNode =
                                                            focusNode;
                                                        if (!endTextField2FocusListenerRegistered) {
                                                          endTextField2FocusListenerRegistered =
                                                              true;
                                                          _model
                                                              .endTextField2FocusNode!
                                                              .addListener(() =>
                                                                  setState(
                                                                      () {}));
                                                        }
                                                        _model.endTextField2TextController =
                                                            textEditingController;
                                                        return TextFormField(
                                                          key: _model
                                                              .endTextField2Key,
                                                          controller:
                                                              textEditingController,
                                                          focusNode: focusNode,
                                                          onEditingComplete:
                                                              onEditingComplete,
                                                          onChanged: (_) =>
                                                              EasyDebounce
                                                                  .debounce(
                                                            '_model.endTextField2TextController',
                                                            const Duration(
                                                                milliseconds:
                                                                    20),
                                                            () async {
                                                              logFirebaseEvent(
                                                                  'DIRECTIONS_endTextField2_ON_TEXTFIELD_CH');
                                                              if (_model.endTextField2TextController
                                                                          .text !=
                                                                      '') {
                                                                logFirebaseEvent(
                                                                    'endTextField2_update_page_state');
                                                                _model.showStartPlaces =
                                                                    false;
                                                                _model.showEndPlaces =
                                                                    true;
                                                                setState(() {});
                                                              } else {
                                                                logFirebaseEvent(
                                                                    'endTextField2_update_page_state');
                                                                _model.showEndPlaces =
                                                                    false;
                                                                setState(() {});
                                                                logFirebaseEvent(
                                                                    'endTextField2_update_app_state');
                                                                FFAppState().removeFromPlaces(
                                                                    FFAppState()
                                                                        .endLocation!);
                                                                FFAppState()
                                                                        .instructionsSheet =
                                                                    false;
                                                                setState(() {});
                                                              }

                                                              logFirebaseEvent(
                                                                  'endTextField2_custom_action');
                                                              _model.endPlacesJSON =
                                                                  await actions
                                                                      .forwardGeocode(
                                                                _model
                                                                    .endTextField2TextController
                                                                    .text,
                                                                'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                              );

                                                              setState(() {});
                                                            },
                                                          ),
                                                          autofocus: true,
                                                          obscureText: false,
                                                          decoration:
                                                              InputDecoration(
                                                            labelStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyLarge
                                                                    .override(
                                                                      fontFamily:
                                                                          'Plus Jakarta Sans',
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                            hintText:
                                                                FFLocalizations.of(
                                                                        context)
                                                                    .getText(
                                                              'gym54vr1' /* Find Destination */,
                                                            ),
                                                            hintStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Plus Jakarta Sans',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .primaryText,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                            enabledBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  const BorderSide(
                                                                color: Color(
                                                                    0x00000000),
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            focusedBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  const BorderSide(
                                                                color: Color(
                                                                    0x00000000),
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            errorBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  BorderSide(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .error,
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            focusedErrorBorder:
                                                                OutlineInputBorder(
                                                              borderSide:
                                                                  BorderSide(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .error,
                                                                width: 2.0,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8.0),
                                                            ),
                                                            filled: true,
                                                            fillColor: Colors
                                                                .transparent,
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Plus Jakarta Sans',
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .primaryText,
                                                                letterSpacing:
                                                                    0.0,
                                                              ),
                                                          validator: _model
                                                              .endTextField2TextControllerValidator
                                                              .asValidator(
                                                                  context),
                                                        );
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                FlutterFlowIconButton(
                                                  borderColor:
                                                      Colors.transparent,
                                                  borderRadius: 20.0,
                                                  borderWidth: 1.0,
                                                  buttonSize: 40.0,
                                                  icon: Icon(
                                                    Icons.close_sharp,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryText,
                                                    size: 24.0,
                                                  ),
                                                  onPressed: () async {
                                                    logFirebaseEvent(
                                                        'DIRECTIONS_PAGE_close_sharp_ICN_ON_TAP');
                                                    logFirebaseEvent(
                                                        'IconButton_reset_form_fields');
                                                    setState(() {
                                                      _model
                                                          .endTextField2TextController
                                                          ?.clear();
                                                    });
                                                    logFirebaseEvent(
                                                        'IconButton_update_app_state');
                                                    FFAppState()
                                                        .removeFromPlaces(
                                                            FFAppState()
                                                                .endLocation!);
                                                    FFAppState()
                                                            .instructionsSheet =
                                                        false;
                                                    FFAppState().noOfEndPlaces =
                                                        FFAppState()
                                                                .noOfEndPlaces +
                                                            -1;
                                                    FFAppState().ENDMARKER =
                                                        null;
                                                    FFAppState()
                                                        .routeCoordinates = [];
                                                    setState(() {});
                                                  },
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          Stack(
                            children: [
                              if (_model.showStartPlaces &&
                                  !_model.showEndPlaces)
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      boxShadow: const [
                                        BoxShadow(
                                          blurRadius: 4.0,
                                          color: Color(0x33000000),
                                          offset: Offset(
                                            0.0,
                                            2.0,
                                          ),
                                        )
                                      ],
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    child: Stack(
                                      children: [
                                        Column(
                                          mainAxisSize: MainAxisSize.max,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      15.0, 15.0, 15.0, 0.0),
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  logFirebaseEvent(
                                                      'DIRECTIONS_PAGE_YourLocationText_ON_TAP');
                                                  currentUserLocationValue =
                                                      await getCurrentUserLocation(
                                                          defaultLocation:
                                                              const LatLng(0.0, 0.0));
                                                  logFirebaseEvent(
                                                      'YourLocationText_request_permissions');
                                                  await requestPermission(
                                                      locationPermission);
                                                  logFirebaseEvent(
                                                      'YourLocationText_update_app_state');
                                                  FFAppState().noOfStartPlaces =
                                                      FFAppState()
                                                              .noOfStartPlaces +
                                                          1;
                                                  setState(() {});
                                                  if (FFAppState()
                                                          .noOfStartPlaces ==
                                                      1) {
                                                    logFirebaseEvent(
                                                        'YourLocationText_update_app_state');
                                                    FFAppState()
                                                        .updatePlacesAtIndex(
                                                      0,
                                                      (_) => functions
                                                          .flipCoordLocation(
                                                              currentUserLocationValue!),
                                                    );
                                                    FFAppState().pointClicked =
                                                        false;
                                                    FFAppState().startLocation =
                                                        functions.flipCoordLocation(
                                                            currentUserLocationValue!);
                                                    FFAppState().STARTMARKER =
                                                        FFAppState()
                                                            .startLocation;
                                                    setState(() {});
                                                    if (FFAppState()
                                                            .places
                                                            .length >
                                                        1) {
                                                      logFirebaseEvent(
                                                          'YourLocationText_custom_action');
                                                      _model.routeFromStartCopy =
                                                          await actions
                                                              .getRouteFromPoints(
                                                        'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                        FFAppState()
                                                            .places
                                                            .toList(),
                                                        FFAppState().travelType,
                                                      );
                                                    }
                                                    logFirebaseEvent(
                                                        'YourLocationText_update_page_state');
                                                    _model.showStartPlaces =
                                                        false;
                                                    setState(() {});
                                                    logFirebaseEvent(
                                                        'YourLocationText_custom_action');
                                                    await actions
                                                        .performReverseGeocode(
                                                      currentUserLocationValue!,
                                                      'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                    );
                                                    logFirebaseEvent(
                                                        'YourLocationText_set_form_field');
                                                    setState(() {
                                                      _model.startTextField1TextController
                                                              ?.text =
                                                          FFAppState()
                                                              .namePlace;
                                                      _model.startTextField1TextController
                                                              ?.selection =
                                                          TextSelection.collapsed(
                                                              offset: _model
                                                                  .startTextField1TextController!
                                                                  .text
                                                                  .length);
                                                    });
                                                  }

                                                  setState(() {});
                                                },
                                                child: Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    'picyor4o' /* Your location */,
                                                  ),
                                                  textAlign: TextAlign.start,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily:
                                                            'Plus Jakarta Sans',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        letterSpacing: 0.0,
                                                      ),
                                                ),
                                              ),
                                            ),
                                            if (_model.startPlacesJSON !=
                                                    null &&
                                                (_model.startPlacesJSON)!
                                                    .isNotEmpty)
                                              Padding(
                                                padding: const EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        15.0, 0.0, 15.0, 15.0),
                                                child: Builder(
                                                  builder: (context) {
                                                    final startPlaces = _model
                                                        .startPlacesJSON!
                                                        .toList();

                                                    return ListView.separated(
                                                      padding: EdgeInsets.zero,
                                                      shrinkWrap: true,
                                                      scrollDirection:
                                                          Axis.vertical,
                                                      itemCount:
                                                          startPlaces.length,
                                                      separatorBuilder: (_,
                                                              __) =>
                                                          const SizedBox(height: 2.0),
                                                      itemBuilder: (context,
                                                          startPlacesIndex) {
                                                        final startPlacesItem =
                                                            startPlaces[
                                                                startPlacesIndex];
                                                        return InkWell(
                                                          splashColor: Colors
                                                              .transparent,
                                                          focusColor: Colors
                                                              .transparent,
                                                          hoverColor: Colors
                                                              .transparent,
                                                          highlightColor: Colors
                                                              .transparent,
                                                          onTap: () async {
                                                            logFirebaseEvent(
                                                                'DIRECTIONS_Container_qkg42e6g_ON_TAP');
                                                            if (getJsonField(
                                                                  startPlacesItem,
                                                                  r'''$.geometry.coordinates''',
                                                                ) !=
                                                                null) {
                                                              logFirebaseEvent(
                                                                  'Container_update_app_state');
                                                              FFAppState()
                                                                  .updatePlacesAtIndex(
                                                                0,
                                                                (_) => functions.flipCoords(
                                                                    (getJsonField(
                                                                  startPlacesItem,
                                                                  r'''$.geometry.coordinates''',
                                                                  true,
                                                                ) as List)
                                                                        .map<String>((s) =>
                                                                            s.toString())
                                                                        .toList()),
                                                              );
                                                              FFAppState()
                                                                      .pointClicked =
                                                                  false;
                                                              FFAppState()
                                                                      .startLocation =
                                                                  functions.flipCoords(
                                                                      (getJsonField(
                                                                startPlacesItem,
                                                                r'''$.geometry.coordinates''',
                                                                true,
                                                              ) as List)
                                                                          .map<String>((s) =>
                                                                              s.toString())
                                                                          .toList());
                                                              FFAppState()
                                                                      .STARTMARKER =
                                                                  FFAppState()
                                                                      .startLocation;
                                                              setState(() {});
                                                              logFirebaseEvent(
                                                                  'Container_custom_action');
                                                              _model.routeFromStart =
                                                                  await actions
                                                                      .getRouteFromPoints(
                                                                'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                                FFAppState()
                                                                    .places
                                                                    .toList(),
                                                                FFAppState()
                                                                    .travelType,
                                                              );
                                                              logFirebaseEvent(
                                                                  'Container_update_page_state');
                                                              _model.showStartPlaces =
                                                                  false;
                                                              setState(() {});
                                                              logFirebaseEvent(
                                                                  'Container_set_form_field');
                                                              setState(() {
                                                                _model.startTextField1TextController
                                                                        ?.text =
                                                                    getJsonField(
                                                                  startPlacesItem,
                                                                  r'''$.place_name''',
                                                                ).toString();
                                                                _model.startTextField1TextController
                                                                        ?.selection =
                                                                    TextSelection.collapsed(
                                                                        offset: _model
                                                                            .startTextField1TextController!
                                                                            .text
                                                                            .length);
                                                              });
                                                            }

                                                            setState(() {});
                                                          },
                                                          child: Container(
                                                            decoration:
                                                                const BoxDecoration(),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Expanded(
                                                                  child: Text(
                                                                    valueOrDefault<
                                                                        String>(
                                                                      getJsonField(
                                                                        startPlacesItem,
                                                                        r'''$.place_name''',
                                                                      )?.toString(),
                                                                      'ut',
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Plus Jakarta Sans',
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ].divide(const SizedBox(
                                                                  width: 5.0)),
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                    );
                                                  },
                                                ),
                                              ),
                                            if (!(_model.startPlacesJSON !=
                                                    null &&
                                                (_model.startPlacesJSON)!
                                                    .isNotEmpty))
                                              const Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: SizedBox(
                                                  width: 50.0,
                                                  height: 50.0,
                                                  child: custom_widgets
                                                      .LoadingIndicator(
                                                    width: 50.0,
                                                    height: 50.0,
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              if (!_model.showStartPlaces &&
                                  _model.showEndPlaces)
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      boxShadow: const [
                                        BoxShadow(
                                          blurRadius: 4.0,
                                          color: Color(0x33000000),
                                          offset: Offset(
                                            0.0,
                                            2.0,
                                          ),
                                        )
                                      ],
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    child: Stack(
                                      children: [
                                        if (_model.endPlacesJSON != null &&
                                            (_model.endPlacesJSON)!.isNotEmpty)
                                          Padding(
                                            padding: const EdgeInsets.all(15.0),
                                            child: Builder(
                                              builder: (context) {
                                                final endPlaces = _model
                                                    .endPlacesJSON!
                                                    .toList();

                                                return ListView.separated(
                                                  padding: EdgeInsets.zero,
                                                  shrinkWrap: true,
                                                  scrollDirection:
                                                      Axis.vertical,
                                                  itemCount: endPlaces.length,
                                                  separatorBuilder: (_, __) =>
                                                      const SizedBox(height: 2.0),
                                                  itemBuilder: (context,
                                                      endPlacesIndex) {
                                                    final endPlacesItem =
                                                        endPlaces[
                                                            endPlacesIndex];
                                                    return InkWell(
                                                      splashColor:
                                                          Colors.transparent,
                                                      focusColor:
                                                          Colors.transparent,
                                                      hoverColor:
                                                          Colors.transparent,
                                                      highlightColor:
                                                          Colors.transparent,
                                                      onTap: () async {
                                                        logFirebaseEvent(
                                                            'DIRECTIONS_Container_nj9kbw3s_ON_TAP');
                                                        currentUserLocationValue =
                                                            await getCurrentUserLocation(
                                                                defaultLocation:
                                                                    const LatLng(0.0,
                                                                        0.0));
                                                        if (getJsonField(
                                                              endPlacesItem,
                                                              r'''$.geometry.coordinates''',
                                                            ) !=
                                                            null) {
                                                          if (FFAppState()
                                                                  .places.isEmpty) {
                                                            logFirebaseEvent(
                                                                'Container_update_app_state');
                                                            FFAppState()
                                                                    .STARTMARKER =
                                                                currentUserLocationValue;
                                                            FFAppState()
                                                                .insertAtIndexInPlaces(
                                                                    0,
                                                                    FFAppState()
                                                                        .STARTMARKER!);
                                                            setState(() {});
                                                            logFirebaseEvent(
                                                                'Container_update_app_state');
                                                            FFAppState().addToPlaces(functions.flipCoords(
                                                                (getJsonField(
                                                              endPlacesItem,
                                                              r'''$.geometry.coordinates''',
                                                              true,
                                                            ) as List)
                                                                    .map<String>(
                                                                        (s) => s
                                                                            .toString())
                                                                    .toList()));
                                                            FFAppState()
                                                                    .pointClicked =
                                                                false;
                                                            FFAppState()
                                                                    .endLocation =
                                                                functions.flipCoords(
                                                                    (getJsonField(
                                                              endPlacesItem,
                                                              r'''$.geometry.coordinates''',
                                                              true,
                                                            ) as List)
                                                                        .map<String>((s) =>
                                                                            s.toString())
                                                                        .toList());
                                                            FFAppState()
                                                                    .ENDMARKER =
                                                                FFAppState()
                                                                    .endLocation;
                                                            setState(() {});
                                                            logFirebaseEvent(
                                                                'Container_custom_action');
                                                            await actions
                                                                .performReverseGeocode(
                                                              currentUserLocationValue!,
                                                              'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                            );
                                                            logFirebaseEvent(
                                                                'Container_set_form_field');
                                                            setState(() {
                                                              _model.endTextField2TextController
                                                                      ?.text =
                                                                  FFAppState()
                                                                      .namePlace;
                                                              _model.endTextField2TextController
                                                                      ?.selection =
                                                                  TextSelection.collapsed(
                                                                      offset: _model
                                                                          .endTextField2TextController!
                                                                          .text
                                                                          .length);
                                                            });
                                                          } else {
                                                            logFirebaseEvent(
                                                                'Container_update_app_state');
                                                            FFAppState()
                                                                .updatePlacesAtIndex(
                                                              1,
                                                              (_) => functions.flipCoords(
                                                                  (getJsonField(
                                                                endPlacesItem,
                                                                r'''$.geometry.coordinates''',
                                                                true,
                                                              ) as List)
                                                                      .map<String>(
                                                                          (s) =>
                                                                              s.toString())
                                                                      .toList()),
                                                            );
                                                            FFAppState()
                                                                    .pointClicked =
                                                                false;
                                                            FFAppState()
                                                                    .endLocation =
                                                                functions.flipCoords(
                                                                    (getJsonField(
                                                              endPlacesItem,
                                                              r'''$.geometry.coordinates''',
                                                              true,
                                                            ) as List)
                                                                        .map<String>((s) =>
                                                                            s.toString())
                                                                        .toList());
                                                            FFAppState()
                                                                    .ENDMARKER =
                                                                FFAppState()
                                                                    .endLocation;
                                                            setState(() {});
                                                          }

                                                          logFirebaseEvent(
                                                              'Container_update_app_state');
                                                          FFAppState()
                                                                  .ENDMARKER =
                                                              FFAppState()
                                                                  .endLocation;
                                                          setState(() {});
                                                          logFirebaseEvent(
                                                              'Container_custom_action');
                                                          _model.routeFromEnd =
                                                              await actions
                                                                  .getRouteFromPoints(
                                                            'pk.eyJ1IjoibWVpaWkiLCJhIjoiY2x3YzhqZzBpMDAwNjJrbnk2Zng2a2h4MyJ9.WagKyApxcx3sw2N79SbTWA',
                                                            FFAppState()
                                                                .places
                                                                .toList(),
                                                            FFAppState()
                                                                .travelType,
                                                          );
                                                          logFirebaseEvent(
                                                              'Container_bottom_sheet');
                                                          showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            context: context,
                                                            builder: (context) {
                                                              return GestureDetector(
                                                                onTap: () => _model
                                                                        .unfocusNode
                                                                        .canRequestFocus
                                                                    ? FocusScope.of(
                                                                            context)
                                                                        .requestFocus(_model
                                                                            .unfocusNode)
                                                                    : FocusScope.of(
                                                                            context)
                                                                        .unfocus(),
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      const DirectionsBottomSheetWidget(),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));

                                                          logFirebaseEvent(
                                                              'Container_update_page_state');
                                                          _model.showEndPlaces =
                                                              false;
                                                          setState(() {});
                                                          logFirebaseEvent(
                                                              'Container_set_form_field');
                                                          setState(() {
                                                            _model.endTextField2TextController
                                                                    ?.text =
                                                                getJsonField(
                                                              endPlacesItem,
                                                              r'''$.place_name''',
                                                            ).toString();
                                                            _model.endTextField2TextController
                                                                    ?.selection =
                                                                TextSelection.collapsed(
                                                                    offset: _model
                                                                        .endTextField2TextController!
                                                                        .text
                                                                        .length);
                                                          });
                                                          logFirebaseEvent(
                                                              'Container_update_app_state');
                                                          FFAppState()
                                                                  .engStringLocation =
                                                              getJsonField(
                                                            endPlacesItem,
                                                            r'''$.place_name''',
                                                          ).toString();
                                                          setState(() {});
                                                        }

                                                        setState(() {});
                                                      },
                                                      child: Container(
                                                        decoration:
                                                            const BoxDecoration(),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Expanded(
                                                              child: Text(
                                                                valueOrDefault<
                                                                    String>(
                                                                  getJsonField(
                                                                    endPlacesItem,
                                                                    r'''$.place_name''',
                                                                  )?.toString(),
                                                                  'ee',
                                                                ),
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Plus Jakarta Sans',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .primaryText,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ),
                                                          ].divide(const SizedBox(
                                                              width: 5.0)),
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                            ),
                                          ),
                                        if (!(_model.endPlacesJSON != null &&
                                            (_model.endPlacesJSON)!.isNotEmpty))
                                          const Align(
                                            alignment:
                                                AlignmentDirectional(0.0, 0.0),
                                            child: SizedBox(
                                              width: 50.0,
                                              height: 50.0,
                                              child: custom_widgets
                                                  .LoadingIndicator(
                                                width: 50.0,
                                                height: 50.0,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                      Stack(
                        children: [
                          Align(
                            alignment: const AlignmentDirectional(1.0, 1.0),
                            child: Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 10.0, 10.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'DIRECTIONS_Container_7syuaz4c_ON_TAP');
                                  if (_model.directionsActive) {
                                    if (FFAppState().places.length == 2) {
                                      logFirebaseEvent(
                                          'Container_update_app_state');
                                      FFAppState().removeAtIndexFromPlaces(1);
                                      setState(() {});
                                    }
                                  }
                                  logFirebaseEvent(
                                      'Container_update_page_state');
                                  _model.directionsActive =
                                      !_model.directionsActive;
                                  setState(() {});
                                },
                                child: Container(
                                  width: 50.0,
                                  height: 50.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context).warning,
                                    boxShadow: const [
                                      BoxShadow(
                                        blurRadius: 4.0,
                                        color: Color(0x33000000),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                      )
                                    ],
                                    borderRadius: BorderRadius.circular(30.0),
                                  ),
                                  child: Stack(
                                    children: [
                                      if (!_model.directionsActive)
                                        Align(
                                          alignment:
                                              const AlignmentDirectional(0.0, 0.0),
                                          child: Icon(
                                            Icons.directions,
                                            color: FlutterFlowTheme.of(context)
                                                .background,
                                            size: 30.0,
                                          ),
                                        ),
                                      if (_model.directionsActive)
                                        Align(
                                          alignment:
                                              const AlignmentDirectional(0.0, 0.0),
                                          child: Icon(
                                            Icons.close,
                                            color: FlutterFlowTheme.of(context)
                                                .background,
                                            size: 30.0,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
