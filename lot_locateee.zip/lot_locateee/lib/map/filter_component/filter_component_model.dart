import '/flutter_flow/flutter_flow_util.dart';
import 'filter_component_widget.dart' show FilterComponentWidget;
import 'package:flutter/material.dart';

class FilterComponentModel extends FlutterFlowModel<FilterComponentWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for DistanceSlider widget.
  double? distanceSliderValue;
  // State field(s) for PriceSlider widget.
  double? priceSliderValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
