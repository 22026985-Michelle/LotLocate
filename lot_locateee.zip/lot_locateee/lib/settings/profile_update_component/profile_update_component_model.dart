import '/flutter_flow/flutter_flow_util.dart';
import 'profile_update_component_widget.dart' show ProfileUpdateComponentWidget;
import 'package:flutter/material.dart';

class ProfileUpdateComponentModel
    extends FlutterFlowModel<ProfileUpdateComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
