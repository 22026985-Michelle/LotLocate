import '/flutter_flow/flutter_flow_util.dart';
import 'log_out_component_widget.dart' show LogOutComponentWidget;
import 'package:flutter/material.dart';

class LogOutComponentModel extends FlutterFlowModel<LogOutComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
