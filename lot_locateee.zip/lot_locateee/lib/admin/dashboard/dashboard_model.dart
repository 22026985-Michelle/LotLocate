import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/components/user_info_top_bar/user_info_top_bar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dashboard_widget.dart' show DashboardWidget;
import 'package:flutter/material.dart';

class DashboardModel extends FlutterFlowModel<DashboardWidget> {
  ///  Local state fields for this page.

  int currentRow = 0;

  int noOfRows = 0;

  List<ChartDataStruct> chartData = [];
  void addToChartData(ChartDataStruct item) => chartData.add(item);
  void removeFromChartData(ChartDataStruct item) => chartData.remove(item);
  void removeAtIndexFromChartData(int index) => chartData.removeAt(index);
  void insertAtIndexInChartData(int index, ChartDataStruct item) =>
      chartData.insert(index, item);
  void updateChartDataAtIndex(int index, Function(ChartDataStruct) updateFn) =>
      chartData[index] = updateFn(chartData[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for user_Info_topBar component.
  late UserInfoTopBarModel userInfoTopBarModel;
  // Stores action output result for [Custom Action - getUserFavoritePlaces] action in Button widget.
  List<dynamic>? userFavsOutput;

  @override
  void initState(BuildContext context) {
    userInfoTopBarModel = createModel(context, () => UserInfoTopBarModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    userInfoTopBarModel.dispose();
  }
}
