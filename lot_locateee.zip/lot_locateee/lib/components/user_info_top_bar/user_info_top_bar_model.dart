import '/flutter_flow/flutter_flow_util.dart';
import 'user_info_top_bar_widget.dart' show UserInfoTopBarWidget;
import 'package:flutter/material.dart';

class UserInfoTopBarModel extends FlutterFlowModel<UserInfoTopBarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
