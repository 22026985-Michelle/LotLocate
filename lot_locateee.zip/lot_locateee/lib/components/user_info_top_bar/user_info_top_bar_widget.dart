import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/account_drop_down/account_drop_down_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'user_info_top_bar_model.dart';
export 'user_info_top_bar_model.dart';

class UserInfoTopBarWidget extends StatefulWidget {
  const UserInfoTopBarWidget({super.key});

  @override
  State<UserInfoTopBarWidget> createState() => _UserInfoTopBarWidgetState();
}

class _UserInfoTopBarWidgetState extends State<UserInfoTopBarWidget> {
  late UserInfoTopBarModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => UserInfoTopBarModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) => FutureBuilder<List<UserInfoRow>>(
        future: UserInfoTable().querySingleRow(
          queryFn: (q) => q.eq(
            'id',
            currentUserUid,
          ),
        ),
        builder: (context, snapshot) {
          // Customize what your widget looks like when it's loading.
          if (!snapshot.hasData) {
            return Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            );
          }
          List<UserInfoRow> rowUserInfoRowList = snapshot.data!;

          final rowUserInfoRow =
              rowUserInfoRowList.isNotEmpty ? rowUserInfoRowList.first : null;

          return InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              logFirebaseEvent('USER_INFO_TOP_BAR_Row_ps14zudc_ON_TAP');
              logFirebaseEvent('Row_alert_dialog');
              await showAlignedDialog(
                barrierColor: const Color(0x001D2428),
                context: context,
                isGlobal: false,
                avoidOverflow: true,
                targetAnchor: const AlignmentDirectional(1.0, 1.0)
                    .resolve(Directionality.of(context)),
                followerAnchor: const AlignmentDirectional(1.0, -1.0)
                    .resolve(Directionality.of(context)),
                builder: (dialogContext) {
                  return const Material(
                    color: Colors.transparent,
                    child: AccountDropDownWidget(),
                  );
                },
              ).then((value) => setState(() {}));
            },
            child: Row(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FutureBuilder<List<UserInfoRow>>(
                  future: UserInfoTable().querySingleRow(
                    queryFn: (q) => q.eq(
                      'id',
                      currentUserUid,
                    ),
                  ),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: SizedBox(
                          width: 50.0,
                          height: 50.0,
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                              FlutterFlowTheme.of(context).primary,
                            ),
                          ),
                        ),
                      );
                    }
                    List<UserInfoRow> columnUserInfoRowList = snapshot.data!;

                    final columnUserInfoRow = columnUserInfoRowList.isNotEmpty
                        ? columnUserInfoRowList.first
                        : null;

                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(27.0),
                            child: Image.network(
                              valueOrDefault<String>(
                                () {
                                  if (columnUserInfoRow?.id == null ||
                                      columnUserInfoRow?.id == '') {
                                    return valueOrDefault<String>(
                                      'https://ui-avatars.com/api/?name=${functions.getLocalPartFromEmail(currentUserEmail)}&size=128&bold=true&background=23395B&color=fff&rounded=true&uppercase=true&format=svg',
                                      'pic',
                                    );
                                  } else if (rowUserInfoRow?.pfp == null ||
                                      rowUserInfoRow?.pfp == '') {
                                    return valueOrDefault<String>(
                                      'https://ui-avatars.com/api/?name=${valueOrDefault<String>(
                                        rowUserInfoRow?.name,
                                        'name',
                                      )}&size=128&bold=true&background=23395B&color=fff&rounded=true&uppercase=true&format=svg',
                                      'pic',
                                    );
                                  } else {
                                    return columnUserInfoRow?.pfp;
                                  }
                                }(),
                                'pic',
                              ),
                              width: 46.0,
                              height: 46.0,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (rowUserInfoRow?.name != null &&
                            rowUserInfoRow?.name != '')
                          Text(
                            valueOrDefault<String>(
                              rowUserInfoRow?.name,
                              'name',
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: 'Plus Jakarta Sans',
                                      letterSpacing: 0.0,
                                    ),
                          ),
                        Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 2.0, 0.0, 0.0),
                          child: Text(
                            currentUserEmail,
                            style:
                                FlutterFlowTheme.of(context).bodySmall.override(
                                      fontFamily: 'Plus Jakarta Sans',
                                      color: const Color(0xFFAB9502),
                                      letterSpacing: 0.0,
                                    ),
                          ),
                        ),
                        if (currentUserEmail == '')
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 2.0, 0.0, 0.0),
                            child: Text(
                              '+$currentPhoneNumber',
                              style: FlutterFlowTheme.of(context)
                                  .bodySmall
                                  .override(
                                    fontFamily: 'Plus Jakarta Sans',
                                    color: const Color(0xFFAB9502),
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      FlutterFlowIconButton(
                        borderRadius: 20.0,
                        borderWidth: 1.0,
                        buttonSize: 40.0,
                        icon: Icon(
                          Icons.settings_rounded,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 24.0,
                        ),
                        onPressed: () async {
                          logFirebaseEvent(
                              'USER_INFO_TOP_BAR_settings_rounded_ICN_O');
                          logFirebaseEvent('IconButton_navigate_to');

                          context.pushNamed('appSettingsPage');
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
