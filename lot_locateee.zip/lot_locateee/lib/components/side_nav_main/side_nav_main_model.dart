import '/flutter_flow/flutter_flow_util.dart';
import 'side_nav_main_widget.dart' show SideNavMainWidget;
import 'package:flutter/material.dart';

class SideNavMainModel extends FlutterFlowModel<SideNavMainWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
