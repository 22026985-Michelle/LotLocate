import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'zh_Hans', 'ms', 'fr'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? zh_HansText = '',
    String? msText = '',
    String? frText = '',
  }) =>
      [enText, zh_HansText, msText, frText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // OnBoardingPage
  {
    'uzxacjo0': {
      'en': 'LotLocate',
      'fr': 'LotLocaliser',
      'ms': 'LotLocate',
      'zh_Hans': '地段定位',
    },
    'xgrs26kh': {
      'en': 'Get Started',
      'fr': 'Commencer',
      'ms': 'Mulakan',
      'zh_Hans': '立即开始',
    },
    '8wlktes7': {
      'en': 'My Account',
      'fr': 'Mon compte',
      'ms': 'Akaun saya',
      'zh_Hans': '我的账户',
    },
    '3kt2kjft': {
      'en': 'Explore nearby parking spots',
      'fr': 'Découvrez les places de stationnement à proximité',
      'ms': 'Terokai tempat letak kereta berhampiran',
      'zh_Hans': '探索附近的停车位',
    },
    '352153x8': {
      'en': 'Search for closest parking spots from a location',
      'fr':
          'Rechercher les places de stationnement les plus proches à partir d\'un emplacement',
      'ms': 'Cari tempat letak kereta terdekat dari lokasi',
      'zh_Hans': '搜索距离某个位置最近的停车位',
    },
    '324b2k4o': {
      'en': 'No more waiting for parking tickets',
      'fr': 'Plus besoin d\'attendre les tickets de stationnement',
      'ms': 'Tidak perlu lagi menunggu tiket parking',
      'zh_Hans': '不再需要等待停车罚单',
    },
    '5quznpau': {
      'en': 'Check parking slots and rates',
      'fr': 'Vérifiez les places de stationnement et les tarifs',
      'ms': 'Semak slot dan kadar letak kereta',
      'zh_Hans': '检查停车位和费率',
    },
    '68uvnd7z': {
      'en': 'Get Directions to Car Park',
      'fr': 'Obtenir un itinéraire pour se rendre au parking',
      'ms': 'Dapatkan Arah ke Tempat Letak Kereta',
      'zh_Hans': '获取前往停车场的路线',
    },
    'mp8xnycu': {
      'en': 'Easily head to your desired car park',
      'fr': 'Accédez facilement au parking de votre choix',
      'ms': 'Pergi dengan mudah ke tempat letak kereta yang anda inginkan',
      'zh_Hans': '轻松前往您想要的停车场',
    },
    'vpj4jalt': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // CreateAccPage
  {
    '5jltyl98': {
      'en': 'LotLocate',
      'fr': 'LotLocaliser',
      'ms': 'LotLocate',
      'zh_Hans': '地段定位',
    },
    '7go4iglb': {
      'en': 'Create Account',
      'fr': 'Créer un compte',
      'ms': 'Buat akaun',
      'zh_Hans': '创建账户',
    },
    'cosqletq': {
      'en': 'Email',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'y9hjefoc': {
      'en': 'Name',
      'fr': 'Nom',
      'ms': 'Nama',
      'zh_Hans': '姓名',
    },
    'us6itttg': {
      'en': 'Email',
      'fr': 'E-mail',
      'ms': 'E-mel',
      'zh_Hans': '电子邮件',
    },
    'm7ajfvdt': {
      'en': 'Password',
      'fr': 'Mot de passe',
      'ms': 'Kata laluan',
      'zh_Hans': '密码',
    },
    'ke8f8cwf': {
      'en': 'Confirm Password',
      'fr': 'Confirmez le mot de passe',
      'ms': 'Sahkan Kata Laluan',
      'zh_Hans': '确认密码',
    },
    'qzeja4gf': {
      'en': 'Please enter first name',
      'fr': 'Veuillez saisir votre prénom',
      'ms': 'Sila masukkan nama pertama',
      'zh_Hans': '请输入名字',
    },
    'zvi2oq6o': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '693aonj7': {
      'en': 'Please enter email address',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'd1sxovii': {
      'en': 'Invalid email',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'uosg6oj5': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'mivbhhtf': {
      'en': 'Please enter password',
      'fr': 'Veuillez entrer le mot de passe',
      'ms': 'Sila masukkan kata laluan',
      'zh_Hans': '请输入密码',
    },
    'i97stf61': {
      'en': 'At least 8 characters required',
      'fr': 'Au moins 8 caractères requis',
      'ms': 'Sekurang-kurangnya 8 aksara diperlukan',
      'zh_Hans': '至少需要 8 个字符',
    },
    'd8psz8l5': {
      'en': 'Email should not exceed 120 characters',
      'fr': 'L\'e-mail ne doit pas dépasser 120 caractères',
      'ms': 'E-mel tidak boleh melebihi 120 aksara',
      'zh_Hans': '电子邮件不得超过 120 个字符',
    },
    'ajsakbum': {
      'en':
          'Password must contain at least one number, one alphabet character, and one special character.',
      'fr':
          'Le mot de passe doit contenir au moins un chiffre, un caractère alphabétique et un caractère spécial.',
      'ms':
          'Kata laluan mesti mengandungi sekurang-kurangnya satu nombor, satu aksara abjad dan satu aksara khas.',
      'zh_Hans': '密码必须至少包含一个数字、一个字母字符和一个特殊字符。',
    },
    'ui3yod71': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '2scz9lyz': {
      'en': 'Please enter confirmation password',
      'fr': 'Veuillez saisir le mot de passe de confirmation',
      'ms': 'Sila masukkan kata laluan pengesahan',
      'zh_Hans': '请输入确认密码',
    },
    'sh8t69vu': {
      'en': 'At least 8 characters required',
      'fr': 'Au moins 8 caractères requis',
      'ms': 'Sekurang-kurangnya 8 aksara diperlukan',
      'zh_Hans': '至少需要 8 个字符',
    },
    'bw3d2tkc': {
      'en': 'Email should not exceed 120 characters',
      'fr': 'L\'e-mail ne doit pas dépasser 120 caractères',
      'ms': 'E-mel tidak boleh melebihi 120 aksara',
      'zh_Hans': '电子邮件不得超过 120 个字符',
    },
    '0o2g3ewc': {
      'en':
          'Password must contain at least one number, one alphabet character, and one special character.',
      'fr':
          'Le mot de passe doit contenir au moins un chiffre, un caractère alphabétique et un caractère spécial.',
      'ms':
          'Kata laluan mesti mengandungi sekurang-kurangnya satu nombor, satu aksara abjad dan satu aksara khas.',
      'zh_Hans': '密码必须至少包含一个数字、一个字母字符和一个特殊字符。',
    },
    '6h9trxzx': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'xqfa0fqv': {
      'en': 'Passwords do not match',
      'fr': 'Les mots de passe ne correspondent pas',
      'ms': 'Kata laluan tidak sepadan',
      'zh_Hans': '密码不匹配',
    },
    'qpcqkx01': {
      'en': 'Sign Up',
      'fr': 'Se connecter',
      'ms': 'Log Masuk',
      'zh_Hans': '登入',
    },
    '2bpsg0hh': {
      'en': 'Register with Google',
      'fr': 'Continuer avec Google',
      'ms': 'Teruskan dengan Google',
      'zh_Hans': '继续使用 Google',
    },
    'q1xh1u6q': {
      'en': 'Already have an account?  Sign in',
      'fr': 'Vous avez déjà un compte?  Se connecter',
      'ms': 'Sudah mempunyai akaun?  Log masuk',
      'zh_Hans': '已有账户？登录',
    },
    'hqdez1d0': {
      'en': ' here.',
      'fr': 'ici.',
      'ms': 'di sini.',
      'zh_Hans': '这里。',
    },
    '2fnqfhz5': {
      'en': 'Phone',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'sgao4y2o': {
      'en': 'Password',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ui2hrdff': {
      'en': 'Confirm Password',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ilj1g59v': {
      'en': 'Field is required',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'pfgiw8m3': {
      'en': '8 characters required',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'klekrvw2': {
      'en': 'A +65 is required',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'x395z6pn': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ed1cuwtd': {
      'en': 'Please enter password',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ieywqmb6': {
      'en': 'At least 8 characters required',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'dugtvkl5': {
      'en': 'Email should not exceed 120 characters',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jmo21xxw': {
      'en':
          'Password must contain at least one number, one alphabet character, and one special character.',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'h5w6e8vo': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'yi385fzi': {
      'en': 'Please enter confirmation password',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'b88008yu': {
      'en': 'At least 8 characters required',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'gx0b04wn': {
      'en': 'Email should not exceed 120 characters',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'samho2oo': {
      'en':
          'Password must contain at least one number, one alphabet character, and one special character.',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'z7d4vcv2': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'i11g6cex': {
      'en': 'Passwords do not match',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'm09pedhk': {
      'en': 'Sign Up',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'n6c7jegb': {
      'en': 'Already have an account?  Sign in',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jc6f868s': {
      'en': ' here.',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // OTPPage
  {
    'ygs864ze': {
      'en': 'LotLocate',
      'fr': 'LotLocaliser',
      'ms': 'LotLocate',
      'zh_Hans': '地段定位',
    },
    '1jhflsb7': {
      'en': 'Log In',
      'fr': 'Content de te revoir!',
      'ms': 'Selamat kembali!',
      'zh_Hans': '欢迎回来！',
    },
    'padxemg3': {
      'en': 'Welcome Back!',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '74q216qr': {
      'en': 'Email',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'f1onk9zn': {
      'en': 'Enter your email',
      'fr': 'Entrer votre Email',
      'ms': 'Masukkan emel anda',
      'zh_Hans': '输入你的电子邮箱',
    },
    'sa2mj9w0': {
      'en': 'Enter your password',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'h0s7w2jx': {
      'en': 'Get OTP',
      'fr': 'Obtenir OTP',
      'ms': 'Dapatkan OTP',
      'zh_Hans': '获取 OTP',
    },
    '1x8ou1py': {
      'en': 'Don\'t have an account? Sign up',
      'fr': 'Vous n\'avez pas de compte ? S\'inscrire',
      'ms': 'Tiada akaun? daftar',
      'zh_Hans': '还没有账户？注册',
    },
    'z6qwuiqr': {
      'en': ' here.',
      'fr': 'ici.',
      'ms': 'di sini.',
      'zh_Hans': '这里。',
    },
    'rdk7s01k': {
      'en': 'Log In with Google',
      'fr': 'Continuer avec Google',
      'ms': 'Teruskan dengan Google',
      'zh_Hans': '继续使用 Google',
    },
    'ant47pca': {
      'en': 'Phone',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '1j7h6v8o': {
      'en': 'Enter your phone number (+65)',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'x2l2skvh': {
      'en': 'Enter your password',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'qkvj9sxi': {
      'en': 'Get OTP',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'yjz78v76': {
      'en': 'Don\'t have an account? Sign up',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ttpamg2f': {
      'en': ' here.',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // EditProfilePage
  {
    '8whc0njx': {
      'en': 'Name',
      'fr': 'Nom',
      'ms': 'Nama',
      'zh_Hans': '姓名',
    },
    'c3w8xnjr': {
      'en': 'Phone Number',
      'fr': 'Numéro de téléphone',
      'ms': 'Nombor telefon',
      'zh_Hans': '电话号码',
    },
    'urk137wi': {
      'en': 'Email',
      'fr': 'E-mail',
      'ms': 'E-mel',
      'zh_Hans': '电子邮件',
    },
    'ukfbvla4': {
      'en': 'Update',
      'fr': 'Mise à jour',
      'ms': 'Kemas kini',
      'zh_Hans': '更新',
    },
    '18i75t8s': {
      'en': 'Delete account',
      'fr': 'Supprimer le compte',
      'ms': 'Padam akaun',
      'zh_Hans': '删除帐户',
    },
    'bk6nbmpp': {
      'en': 'Edit profile',
      'fr': 'Editer le profil',
      'ms': 'Sunting profil',
      'zh_Hans': '编辑个人资料',
    },
    '6kr9s0m4': {
      'en': 'Profile',
      'fr': 'Profil',
      'ms': 'Profil',
      'zh_Hans': '轮廓',
    },
  },
  // ProfilePage
  {
    'cvyq50k8': {
      'en': 'Edit profile',
      'fr': 'Editer le profil',
      'ms': 'Sunting profil',
      'zh_Hans': '编辑个人资料',
    },
    '06m8crig': {
      'en': 'Languages',
      'fr': 'Langues',
      'ms': 'Bahasa',
      'zh_Hans': '语言',
    },
    '85riq6zd': {
      'en': 'Privacy Policy',
      'fr': 'politique de confidentialité',
      'ms': 'Dasar Privasi',
      'zh_Hans': '隐私政策',
    },
    'ijmuee1y': {
      'en': 'Support',
      'fr': 'Soutien',
      'ms': 'Sokongan',
      'zh_Hans': '支持',
    },
    '1y64p4f0': {
      'en': 'Terms of Service',
      'fr': 'Conditions d\'utilisation',
      'ms': 'Syarat Perkhidmatan',
      'zh_Hans': '服务条款',
    },
    'w075k0ez': {
      'en': 'Dashboard',
      'fr': 'Paramètres de l\'application',
      'ms': 'Tetapan Apl',
      'zh_Hans': '应用程序设置',
    },
    '5bgflujj': {
      'en': 'Favourites',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'vz1hej8r': {
      'en': 'App Settings',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ss3czm5g': {
      'en': 'Logout',
      'fr': 'Se déconnecter',
      'ms': 'Log keluar',
      'zh_Hans': '登出',
    },
    'itbu9qzj': {
      'en': 'Profile',
      'fr': 'Profil',
      'ms': 'Profil',
      'zh_Hans': '轮廓',
    },
    'qd2uaf6k': {
      'en': 'Profile',
      'fr': 'Profil',
      'ms': 'Profil',
      'zh_Hans': '轮廓',
    },
  },
  // CreateProfilePage
  {
    'edmu519w': {
      'en': 'Complete Profile',
      'fr': 'Profil complet',
      'ms': 'Profil Lengkap',
      'zh_Hans': '完整简介',
    },
    '8sfkm7xs': {
      'en': 'Please fill up the following details to complete your profile',
      'fr':
          'Veuillez remplir les informations suivantes pour compléter votre profil',
      'ms': 'Sila isi butiran berikut untuk melengkapkan profil anda',
      'zh_Hans': '请填写以下详细信息以完成您的个人资料',
    },
    'w2oevbbo': {
      'en': 'Add your image',
      'fr': 'Ajoutez votre image',
      'ms': 'Tambah imej anda',
      'zh_Hans': '添加您的图片',
    },
    'a8sff5d1': {
      'en': 'Later',
      'fr': 'Plus tard',
      'ms': 'Nanti',
      'zh_Hans': '之后',
    },
    'cxbn0o28': {
      'en': 'Update',
      'fr': 'Mise à jour',
      'ms': 'Kemas kini',
      'zh_Hans': '更新',
    },
    'csu3kg4r': {
      'en': 'Add Profile Picture',
      'fr': 'Créer un profil',
      'ms': 'Buat profil',
      'zh_Hans': '创建个人资料',
    },
    'viptkewe': {
      'en': 'Profile',
      'fr': 'Profil',
      'ms': 'Profil',
      'zh_Hans': '轮廓',
    },
  },
  // appSettingsPage
  {
    '7y700e21': {
      'en': 'App Settings',
      'fr': 'Paramètres de l\'application',
      'ms': 'Tetapan Apl',
      'zh_Hans': '应用程序设置',
    },
    '73n2mauj': {
      'en': 'Camera',
      'fr': 'Notifications push',
      'ms': 'Pemberitahuan Tolak',
      'zh_Hans': '推送通知',
    },
    'cyh2ox48': {
      'en': 'Allow us to access your camera',
      'fr':
          'Recevez des notifications Push de notre application de manière semi-régulière.',
      'ms':
          'Terima pemberitahuan Push daripada aplikasi kami secara separa tetap.',
      'zh_Hans': '定期从我们的应用程序接收推送通知。',
    },
    'upadv30s': {
      'en': 'Photo Library',
      'fr': 'Services de location',
      'ms': 'Perkhidmatan Lokasi',
      'zh_Hans': '位置服务',
    },
    '6unhbp7a': {
      'en': 'Allow us to access your Photo Library',
      'fr':
          'Permettez-nous de suivre votre position, cela permet de suivre vos dépenses et de garantir votre sécurité.',
      'ms':
          'Benarkan kami menjejak lokasi anda, ini membantu menjejaki perbelanjaan dan memastikan anda selamat.',
      'zh_Hans': '允许我们追踪您的位置，这有助于追踪您的消费并确保您的安全。',
    },
    '7leje5op': {
      'en': 'Location Services',
      'fr': 'Services de location',
      'ms': 'Perkhidmatan Lokasi',
      'zh_Hans': '位置服务',
    },
    'd3xiluvi': {
      'en': 'Allow us to get your current location',
      'fr':
          'Permettez-nous de suivre votre position, cela permet de suivre vos dépenses et de garantir votre sécurité.',
      'ms':
          'Benarkan kami menjejak lokasi anda, ini membantu menjejaki perbelanjaan dan memastikan anda selamat.',
      'zh_Hans': '允许我们追踪您的位置，这有助于追踪您的消费并确保您的安全。',
    },
    'bfuurpgl': {
      'en': 'Light Mode',
      'fr': 'Mode lumière',
      'ms': 'Mod Cahaya',
      'zh_Hans': '灯光模式',
    },
    '4x7ymvs9': {
      'en': 'Dark Mode',
      'fr': 'Mode sombre',
      'ms': 'Mod Gelap',
      'zh_Hans': '暗黑模式',
    },
    'wgf1710x': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // LanguagesPage
  {
    'zlmka2iz': {
      'en': 'English',
      'fr': 'Anglais',
      'ms': 'Inggeris',
      'zh_Hans': '英语',
    },
    'rgvknhjl': {
      'en': '中文 (简体)',
      'fr': '中文 (简体)',
      'ms': '中文 (简体)',
      'zh_Hans': '中文 (English)',
    },
    'o6lzofc6': {
      'en': 'Bahasa Melayu',
      'fr': 'Bahasa Melayu',
      'ms': 'Bahasa Melayu',
      'zh_Hans': '马来语',
    },
    'b8u8s7e5': {
      'en': 'Français',
      'fr': 'Français',
      'ms': 'Français',
      'zh_Hans': '法語',
    },
    'cedn7wkh': {
      'en': 'Update',
      'fr': 'Mise à jour',
      'ms': 'Kemas kini',
      'zh_Hans': '更新',
    },
    'ayr24kw8': {
      'en': 'Languages',
      'fr': 'Langues',
      'ms': 'Bahasa',
      'zh_Hans': '语言',
    },
    '5h6qvzm2': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // TermsCondtionsPage
  {
    'prf3o7a6': {
      'en':
          'Welcome to LotLocate, a car slot availability application (\"the App\"). The following terms and conditions govern your use of the App. By accessing or using the App, you agree to be bound by these terms and conditions. If you disagree with any part of these terms and conditions, please do not use the App.\n\nUse of the App:\nThe App is provided solely for your personal and non-commercial use.\nYou must be at least 18 years old to use the App.\nYou agree not to use the App for any illegal or unauthorized purpose.\n\nAccount Registration:\nIn order to access certain features of the App, you may be required to create an account.\nYou agree to provide accurate and complete information during the registration process.\nYou are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.\n\nCar Slot Availability:\nThe App provides information about car slot availability in designated parking areas.\nWhile we strive to provide accurate and up-to-date information, we do not guarantee the availability of car slots at any given time.\n\nUser Conduct:\nYou agree to use the App in compliance with all applicable laws and regulations.\nYou agree not to disrupt or interfere with the operation of the App.\nYou agree not to attempt to gain unauthorized access to any part of the App or to any other user\'s account.\n\nIntellectual Property:\nAll content and materials available on the App, including but not limited to text, graphics, logos, images, and software, are the property of LotLocate or its licensors and are protected by copyright and other intellectual property laws.\nYou may not modify, reproduce, distribute, or create derivative works based on any content or materials from the App without prior written consent from LotLocate.\n\nPrivacy Policy:\nBy using the App, you agree to the terms of our Privacy Policy, which is incorporated into these terms and conditions by reference.\nOur Privacy Policy outlines how we collect, use, and disclose personal information.\n\nLimitation of Liability:\nTo the fullest extent permitted by law, LotLocate shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising out of or in connection with your use of the App.\nLotLocate shall not be liable for any loss or damage resulting from any errors, omissions, or inaccuracies in the information provided by the App.\n\nIndemnification:\nYou agree to indemnify and hold harmless LotLocate and its affiliates, officers, directors, employees, and agents from any claims, liabilities, damages, costs, or expenses (including attorneys\' fees) arising out of or in connection with your use of the App or your violation of these terms and conditions.\n\nChanges to Terms:\nLotLocate reserves the right to modify or update these terms and conditions at any time without prior notice. The most current version of these terms will be posted on the App.\nYour continued use of the App after any changes to these terms and conditions constitutes your acceptance of the revised terms.\n\nGoverning Law:\nThese terms and conditions shall be governed by and construed in accordance with the laws of [Your Country], without regard to its conflict of law principles.\nAny dispute arising out of or in connection with these terms and conditions shall be subject to the exclusive jurisdiction of the courts of Singapore.',
      'fr':
          'Bienvenue sur LotLocate, une application de disponibilité d\'emplacements de voiture (« l\'Application »). Les termes et conditions suivants régissent votre utilisation de l\'application. En accédant ou en utilisant l\'application, vous acceptez d\'être lié par ces termes et conditions. Si vous n\'êtes pas d\'accord avec une partie de ces termes et conditions, veuillez ne pas utiliser l\'application.\n\nUtilisation de l\'application :\nL\'application est fournie uniquement pour votre usage personnel et non commercial.\nVous devez avoir au moins 18 ans pour utiliser l\'application.\nVous acceptez de ne pas utiliser l\'application à des fins illégales ou non autorisées.\n\nEnregistrement du Compte:\nAfin d\'accéder à certaines fonctionnalités de l\'Application, vous devrez peut-être créer un compte.\nVous acceptez de fournir des informations exactes et complètes lors du processus d’inscription.\nVous êtes responsable du maintien de la confidentialité des informations d\'identification de votre compte et de toutes les activités qui se produisent sous votre compte.\n\nDisponibilité des emplacements de voiture :\nL\'application fournit des informations sur la disponibilité des emplacements de voiture dans les zones de stationnement désignées.\nBien que nous nous efforcions de fournir des informations précises et à jour, nous ne garantissons pas la disponibilité des emplacements de voiture à un moment donné.\n\nComportement de l\'utilisateur :\nVous acceptez d\'utiliser l\'application conformément à toutes les lois et réglementations applicables.\nVous acceptez de ne pas perturber ou interférer avec le fonctionnement de l\'Application.\nVous acceptez de ne pas tenter d\'obtenir un accès non autorisé à toute partie de l\'Application ou au compte de tout autre utilisateur.\n\nPropriété intellectuelle:\nTout le contenu et le matériel disponibles sur l\'application, y compris, mais sans s\'y limiter, les textes, graphiques, logos, images et logiciels, sont la propriété de LotLocate ou de ses concédants de licence et sont protégés par le droit d\'auteur et d\'autres lois sur la propriété intellectuelle.\nVous ne pouvez pas modifier, reproduire, distribuer ou créer des œuvres dérivées basées sur tout contenu ou matériel de l\'application sans le consentement écrit préalable de LotLocate.\n\nPolitique de confidentialité:\nEn utilisant l\'application, vous acceptez les termes de notre politique de confidentialité, qui est intégrée aux présentes conditions générales par référence.\nNotre politique de confidentialité décrit la manière dont nous collectons, utilisons et divulguons les informations personnelles.\n\nLimitation de responsabilité:\nDans toute la mesure permise par la loi, LotLocate ne sera pas responsable des dommages directs, indirects, accessoires, spéciaux, consécutifs ou punitifs découlant de ou en relation avec votre utilisation de l\'application.\nLotLocate ne sera pas responsable de toute perte ou dommage résultant d\'erreurs, d\'omissions ou d\'inexactitudes dans les informations fournies par l\'application.\n\nIndemnité:\nVous acceptez d\'indemniser et de dégager LotLocate et ses sociétés affiliées, dirigeants, administrateurs, employés et agents de toute réclamation, responsabilité, dommage, coût ou dépense (y compris les honoraires d\'avocat) découlant de ou en relation avec votre utilisation de l\'application. ou votre violation de ces termes et conditions.\n\nModifications des conditions :\nLotLocate se réserve le droit de modifier ou de mettre à jour ces termes et conditions à tout moment et sans préavis. La version la plus récente de ces conditions sera publiée sur l\'application.\nVotre utilisation continue de l’Application après toute modification de ces termes et conditions constitue votre acceptation des conditions révisées.\n\nLoi applicable :\nCes termes et conditions seront régis et interprétés conformément aux lois de [Votre Pays], sans égard à ses principes de conflit de lois.\nTout litige découlant de ou en relation avec les présentes conditions générales sera soumis à la compétence exclusive des tribunaux de Singapour.',
      'ms':
          'Selamat datang ke LotLocate, aplikasi ketersediaan slot kereta (\"Apl\"). Terma dan syarat berikut mengawal penggunaan Apl anda. Dengan mengakses atau menggunakan Apl, anda bersetuju untuk terikat dengan terma dan syarat ini. Jika anda tidak bersetuju dengan mana-mana bahagian terma dan syarat ini, sila jangan gunakan Apl.\n\nPenggunaan Apl:\nAplikasi ini disediakan semata-mata untuk kegunaan peribadi dan bukan komersial anda.\nAnda mesti berumur sekurang-kurangnya 18 tahun untuk menggunakan Apl.\nAnda bersetuju untuk tidak menggunakan Apl untuk sebarang tujuan yang menyalahi undang-undang atau tidak dibenarkan.\n\nPendaftaran Akaun:\nUntuk mengakses ciri tertentu Apl, anda mungkin dikehendaki membuat akaun.\nAnda bersetuju untuk memberikan maklumat yang tepat dan lengkap semasa proses pendaftaran.\nAnda bertanggungjawab untuk mengekalkan kerahsiaan bukti kelayakan akaun anda dan untuk semua aktiviti yang berlaku di bawah akaun anda.\n\nKetersediaan Slot Kereta:\nApp menyediakan maklumat tentang ketersediaan slot kereta di kawasan tempat letak kereta yang ditetapkan.\nWalaupun kami berusaha untuk memberikan maklumat yang tepat dan terkini, kami tidak menjamin ketersediaan slot kereta pada bila-bila masa.\n\nTingkah Laku Pengguna:\nAnda bersetuju untuk menggunakan Apl ini dengan mematuhi semua undang-undang dan peraturan yang berkenaan.\nAnda bersetuju untuk tidak mengganggu atau mengganggu pengendalian Apl.\nAnda bersetuju untuk tidak cuba mendapatkan akses tanpa kebenaran kepada mana-mana bahagian Apl atau kepada mana-mana akaun pengguna lain.\n\nHarta Intelek:\nSemua kandungan dan bahan yang tersedia pada Apl, termasuk tetapi tidak terhad kepada teks, grafik, logo, imej dan perisian, adalah hak milik LotLocate atau pemberi lesennya dan dilindungi oleh undang-undang hak cipta dan harta intelek yang lain.\nAnda tidak boleh mengubah suai, menghasilkan semula, mengedar atau mencipta karya terbitan berdasarkan mana-mana kandungan atau bahan daripada Apl tanpa kebenaran bertulis daripada LotLocate terlebih dahulu.\n\nDasar Privasi:\nDengan menggunakan Apl, anda bersetuju menerima terma Dasar Privasi kami, yang dimasukkan ke dalam terma dan syarat ini melalui rujukan.\nDasar Privasi kami menggariskan cara kami mengumpul, menggunakan dan mendedahkan maklumat peribadi.\n\nHad Liabiliti:\nSetakat yang dibenarkan oleh undang-undang, LotLocate tidak akan bertanggungjawab ke atas sebarang kerosakan langsung, tidak langsung, sampingan, khas, berbangkit atau punitif yang timbul daripada atau berkaitan dengan penggunaan Apl oleh anda.\nLotLocate tidak akan bertanggungjawab ke atas sebarang kehilangan atau kerosakan akibat daripada sebarang ralat, peninggalan atau ketidaktepatan dalam maklumat yang diberikan oleh Apl.\n\nGanti rugi:\nAnda bersetuju untuk menanggung rugi dan menahan LotLocate dan ahli gabungannya, pegawai, pengarah, pekerja dan ejennya daripada sebarang tuntutan, liabiliti, ganti rugi, kos atau perbelanjaan (termasuk yuran peguam) yang timbul daripada atau berkaitan dengan penggunaan Aplikasi oleh anda atau pelanggaran anda terhadap terma dan syarat ini.\n\nPerubahan kepada Syarat:\nLotLocate berhak untuk mengubah suai atau mengemas kini terma dan syarat ini pada bila-bila masa tanpa notis awal. Versi terkini syarat ini akan disiarkan pada Apl.\nPenggunaan Apl anda yang berterusan selepas sebarang perubahan pada terma dan syarat ini merupakan penerimaan anda terhadap terma yang disemak.\n\nUndang-undang yang memerintah:\nTerma dan syarat ini akan ditadbir oleh dan ditafsirkan mengikut undang-undang [Negara Anda], tanpa mengambil kira percanggahan prinsip undang-undangnya.\nSebarang pertikaian yang timbul daripada atau berkaitan dengan terma dan syarat ini hendaklah tertakluk kepada bidang kuasa eksklusif mahkamah Singapura.',
      'zh_Hans':
          '欢迎使用 LotLocate，这是一款停车位可用性应用程序（“应用程序”）。以下条款和条件约束您对应用程序的使用。通过访问或使用应用程序，您同意受这些条款和条件的约束。如果您不同意这些条款和条件的任何部分，请不要使用应用程序。\n\n应用程序的使用：\n应用程序仅供您个人和非商业使用。\n您必须年满 18 岁才能使用应用程序。\n您同意不将应用程序用于任何非法或未经授权的目的。\n\n帐户注册：\n为了访问应用程序的某些功能，您可能需要创建一个帐户。\n您同意在注册过程中提供准确和完整的信息。\n您有责任维护您的帐户凭据的机密性以及您帐户下发生的所有活动。\n\n停车位可用性：\n应用程序提供有关指定停车区域停车位可用性的信息。\n虽然我们努力提供准确和最新的信息，但我们不保证任何时候都有停车位可用。\n\n用户行为：\n您同意遵守所有适用法律和法规使用该应用程序。\n您同意不破坏或干扰该应用程序的运行。\n您同意不试图未经授权访问该应用程序的任何部分或任何其他用户的帐户。\n\n知识产权：\n该应用程序上提供的所有内容和材料，包括但不限于文本、图形、徽标、图像和软件，均为 LotLocate 或其许可方的财产，受版权和其他知识产权法的保护。\n未经 LotLocate 事先书面同意，您不得修改、复制、分发或基于该应用程序的任何内容或材料创作衍生作品。\n\n隐私政策：\n使用该应用程序，即表示您同意我们的隐私政策的条款，该政策通过引用纳入这些条款和条件。\n我们的隐私政策概述了我们如何收集、使用和披露个人信息。\n\n责任限制：\n在法律允许的最大范围内，LotLocate 不对因您使用本应用程序或与您使用本应用程序有关而产生的任何直接、间接、偶然、特殊、后果性或惩罚性损害负责。\nLotLocate 不对因本应用程序提供的信息中的任何错误、遗漏或不准确而造成的任何损失或损害负责。\n\n赔偿：\n您同意赔偿并使 LotLocate 及其关联公司、管理人员、董事、员工和代理人免受因您使用本应用程序或您违反这些条款和条件而产生的任何索赔、责任、损害、成本或费用（包括律师费）。\n\n条款变更：\nLotLocate 保留随时修改或更新这些条款和条件的权利，恕不另行通知。这些条款的最新版本将发布在应用程序上。\n在这些条款和条件发生任何变化后，您继续使用本应用程序即表示您接受修订后的条款。\n\n适用法律：\n这些条款和条件应受 [您所在国家/地区] 法律的管辖和解释，而不考虑其法律原则冲突。\n因这些条款和条件引起的或与之相关的任何争议均应受新加坡法院的专属管辖。',
    },
    'r4gh4u7z': {
      'en': 'Terms and conditions',
      'fr': 'Termes et conditions',
      'ms': 'Terma dan syarat',
      'zh_Hans': '条款和条件',
    },
    'qcbkave2': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // PrivacyPolicyPage
  {
    'acsoih6k': {
      'en':
          'This Privacy Policy describes how LotLocate (\"we\", \"us\", or \"our\") collects, uses, and discloses personal information when you use our car slot availability application (\"the App\").\n\nInformation We Collect\n\nInformation You Provide:\nWhen you create an account, we may collect personal information such as your name, email address, and password. If you contact us for support or other inquiries, we may collect your name, email address, and any other information you provide voluntarily.\n\nAutomatically Collected Information:\nWhen you use the App, we may automatically collect certain information about your device, including your IP address, device type, operating system, and browser type. We may also collect information about your usage of the App, such as the pages you visit and the actions you take.\n\nHow We Use Your Information\n\nTo Provide and Improve the App:\nWe use the information we collect to provide and improve the functionality of the App. This includes providing car slot availability information, analyzing usage trends, and identifying areas for improvement.\n\nTo Communicate with You:\nWe may use your contact information to communicate with you about your account, updates to the App, and other relevant information. We may also send you promotional emails or newsletters, but you can opt out of receiving these communications at any time.\n\nFor Legal Purposes:\nWe may use your information to comply with applicable laws, regulations, or legal processes, or to protect our rights or the rights of others. Information Sharing and Disclosure\n\nService Providers:\nWe may share your personal information with third-party service providers who perform services on our behalf, such as hosting, analytics, and customer support.\n\nBusiness Transfers:\nIn the event that LotLocate is involved in a merger, acquisition, or sale of all or a portion of its assets, your personal information may be transferred as part of the transaction.\n\nLegal Compliance:\nWe may disclose your information if we believe it is necessary to comply with applicable laws, regulations, or legal processes, or to protect our rights or the rights of others.\n\nYour Choices\n\nAccount Information: You may update or delete your account information at any time by logging into your account settings.\nCommunications: You may opt out of receiving promotional emails or newsletters by following the instructions provided in the email.\n\nSecurity\n\nWe take reasonable measures to protect the security of your personal information, but please be aware that no method of transmission over the internet or electronic storage is completely secure.\n\nChanges to This Privacy Policy\n\nWe may update this Privacy Policy from time to time, and any changes will be posted on this page. Your continued use of the App after any changes to this Privacy Policy constitutes your acceptance of the revised terms.\n\nContact Us\n\nIf you have any questions or concerns about this Privacy Policy, please contact us at lotlocate@gmail.com.',
      'fr':
          'Cette politique de confidentialité décrit comment LotLocate (« nous », « notre » ou « notre ») collecte, utilise et divulgue des informations personnelles lorsque vous utilisez notre application de disponibilité de emplacements de voiture (« l\'Application »).\n\nInformations que nous collectons\n\nInformations que vous fournissez :\nLorsque vous créez un compte, nous pouvons collecter des informations personnelles telles que votre nom, votre adresse e-mail et votre mot de passe. Si vous nous contactez pour obtenir de l\'aide ou d\'autres demandes de renseignements, nous pouvons recueillir votre nom, votre adresse e-mail et toute autre information que vous fournissez volontairement.\n\nInformations collectées automatiquement :\nLorsque vous utilisez l\'application, nous pouvons collecter automatiquement certaines informations sur votre appareil, notamment votre adresse IP, votre type d\'appareil, votre système d\'exploitation et votre type de navigateur. Nous pouvons également collecter des informations sur votre utilisation de l\'Application, telles que les pages que vous visitez et les actions que vous effectuez.\n\nComment nous utilisons vos informations\n\nPour fournir et améliorer l\'application :\nNous utilisons les informations que nous collectons pour fournir et améliorer les fonctionnalités de l\'application. Cela comprend la fourniture d\'informations sur la disponibilité des emplacements de voiture, l\'analyse des tendances d\'utilisation et l\'identification des domaines à améliorer.\n\nPour communiquer avec toi:\nNous pouvons utiliser vos coordonnées pour communiquer avec vous au sujet de votre compte, des mises à jour de l\'application et d\'autres informations pertinentes. Nous pouvons également vous envoyer des e-mails promotionnels ou des newsletters, mais vous pouvez refuser de recevoir ces communications à tout moment.\n\nÀ des fins juridiques :\nNous pouvons utiliser vos informations pour nous conformer aux lois, réglementations ou procédures juridiques applicables, ou pour protéger nos droits ou ceux d’autrui. Partage et divulgation d’informations\n\nLes fournisseurs de services:\nNous pouvons partager vos informations personnelles avec des prestataires de services tiers qui fournissent des services en notre nom, tels que l\'hébergement, l\'analyse et le support client.\n\nTransferts d\'entreprises :\nDans le cas où LotLocate serait impliqué dans une fusion, une acquisition ou une vente de tout ou partie de ses actifs, vos informations personnelles pourront être transférées dans le cadre de la transaction.\n\nConformité légale:\nNous pouvons divulguer vos informations si nous pensons que cela est nécessaire pour nous conformer aux lois, réglementations ou procédures juridiques applicables, ou pour protéger nos droits ou ceux d\'autrui.\n\nVos choix\n\nInformations sur le compte : vous pouvez mettre à jour ou supprimer les informations de votre compte à tout moment en vous connectant aux paramètres de votre compte.\nCommunications : vous pouvez refuser de recevoir des e-mails promotionnels ou des newsletters en suivant les instructions fournies dans l\'e-mail.\n\nSécurité\n\nNous prenons des mesures raisonnables pour protéger la sécurité de vos informations personnelles, mais sachez qu\'aucune méthode de transmission sur Internet ou de stockage électronique n\'est complètement sécurisée.\n\nModifications de cette politique de confidentialité\n\nNous pouvons mettre à jour cette politique de confidentialité de temps à autre, et toute modification sera publiée sur cette page. Votre utilisation continue de l\'application après toute modification de cette politique de confidentialité constitue votre acceptation des conditions révisées.\n\nContactez-nous\n\nSi vous avez des questions ou des préoccupations concernant cette politique de confidentialité, veuillez nous contacter à lotlocate@gmail.com.',
      'ms':
          'Dasar Privasi ini menerangkan cara LotLocate (\"kami\", \"kami\", atau \"kami\") mengumpul, menggunakan dan mendedahkan maklumat peribadi apabila anda menggunakan aplikasi ketersediaan slot kereta kami (\"Apl\").\n\nMaklumat yang Kami Kumpul\n\nMaklumat yang Anda Berikan:\nApabila anda membuat akaun, kami mungkin mengumpul maklumat peribadi seperti nama, alamat e-mel dan kata laluan anda. Jika anda menghubungi kami untuk mendapatkan sokongan atau pertanyaan lain, kami mungkin mengumpul nama, alamat e-mel anda dan sebarang maklumat lain yang anda berikan secara sukarela.\n\nMaklumat Dikumpul Secara Automatik:\nApabila anda menggunakan Apl, kami mungkin secara automatik mengumpul maklumat tertentu tentang peranti anda, termasuk alamat IP anda, jenis peranti, sistem pengendalian dan jenis penyemak imbas. Kami juga mungkin mengumpul maklumat tentang penggunaan Apl anda, seperti halaman yang anda lawati dan tindakan yang anda ambil.\n\nBagaimana Kami Menggunakan Maklumat Anda\n\nUntuk Menyediakan dan Memperbaik Apl:\nKami menggunakan maklumat yang kami kumpulkan untuk menyediakan dan menambah baik kefungsian Apl. Ini termasuk menyediakan maklumat ketersediaan slot kereta, menganalisis arah aliran penggunaan dan mengenal pasti kawasan untuk penambahbaikan.\n\nUntuk Berkomunikasi dengan Anda:\nKami mungkin menggunakan maklumat hubungan anda untuk berkomunikasi dengan anda tentang akaun anda, kemas kini pada Apl dan maklumat lain yang berkaitan. Kami juga mungkin menghantar e-mel atau surat berita promosi kepada anda, tetapi anda boleh menarik diri daripada menerima komunikasi ini pada bila-bila masa.\n\nUntuk Tujuan Undang-undang:\nKami mungkin menggunakan maklumat anda untuk mematuhi undang-undang, peraturan atau proses undang-undang yang berkenaan, atau untuk melindungi hak kami atau hak orang lain. Perkongsian dan Pendedahan Maklumat\n\nPembekal Perkhidmatan:\nKami mungkin berkongsi maklumat peribadi anda dengan penyedia perkhidmatan pihak ketiga yang melaksanakan perkhidmatan bagi pihak kami, seperti pengehosan, analitik dan sokongan pelanggan.\n\nPemindahan Perniagaan:\nSekiranya LotLocate terlibat dalam penggabungan, pemerolehan atau penjualan semua atau sebahagian daripada asetnya, maklumat peribadi anda mungkin dipindahkan sebagai sebahagian daripada transaksi.\n\nPematuhan Undang-undang:\nKami mungkin mendedahkan maklumat anda jika kami percaya adalah perlu untuk mematuhi undang-undang, peraturan, atau proses undang-undang yang berkenaan, atau untuk melindungi hak kami atau hak orang lain.\n\nPilihan Anda\n\nMaklumat Akaun: Anda boleh mengemas kini atau memadam maklumat akaun anda pada bila-bila masa dengan melog masuk ke tetapan akaun anda.\nKomunikasi: Anda boleh menarik diri daripada menerima e-mel atau surat berita promosi dengan mengikut arahan yang diberikan dalam e-mel.\n\nKeselamatan\n\nKami mengambil langkah yang munasabah untuk melindungi keselamatan maklumat peribadi anda, tetapi harap maklum bahawa tiada kaedah penghantaran melalui Internet atau storan elektronik adalah selamat sepenuhnya.\n\nPerubahan kepada Dasar Privasi Ini\n\nKami mungkin mengemas kini Dasar Privasi ini dari semasa ke semasa, dan sebarang perubahan akan disiarkan di halaman ini. Penggunaan berterusan Apl anda selepas sebarang perubahan pada Dasar Privasi ini merupakan penerimaan anda terhadap syarat yang telah disemak.\n\nHubungi Kami\n\nJika anda mempunyai sebarang soalan atau kebimbangan mengenai Dasar Privasi ini, sila hubungi kami di lotlocate@gmail.com.',
      'zh_Hans':
          '本隐私政策描述了 LotLocate（“我们”）在您使用我们的车位可用性应用程序（“应用程序”）时如何收集、使用和披露个人信息。\n\n我们收集的信息\n\n您提供的信息：\n当您创建帐户时，我们可能会收集您的姓名、电子邮件地址和密码等个人信息。 如果您联系我们寻求支持或其他咨询，我们可能会收集您的姓名、电子邮件地址以及您自愿提供的任何其他信息。\n\n自动收集的信息：\n当您使用应用程序时，我们可能会自动收集有关您设备的某些信息，包括您的 IP 地址、设备类型、操作系统和浏览器类型。 我们还可能收集有关您对应用程序使用情况的信息，例如您访问的页面和您采取的操作。\n\n我们如何使用您的信息\n\n提供和改进应用程序：\n我们使用收集的信息来提供和改进应用程序的功能。 这包括提供车位可用性信息、分析使用趋势和确定需要改进的领域。\n\n与您沟通：\n我们可能会使用您的联系信息与您沟通您的帐户、应用程序更新和其他相关信息。我们还可能向您发送促销电子邮件或新闻通讯，但您可以随时选择不接收这些通信。\n\n出于法律目的：\n我们可能会使用您的信息来遵守适用的法律、法规或法律程序，或保护我们的权利或他人的权利。信息共享和披露\n\n服务提供商：\n我们可能会与代表我们提供托管、分析和客户支持等服务的第三方服务提供商共享您的个人信息。\n\n业务转让：\n如果 LotLocate 涉及合并、收购或出售其全部或部分资产，您的个人信息可能会作为交易的一部分被转让。\n\n法律合规：\n如果我们认为有必要遵守适用的法律、法规或法律程序，或保护我们的权利或他人的权利，我们可能会披露您的信息。\n\n您的选择\n\n帐户信息：您可以随时登录帐户设置来更新或删除帐户信息。\n\n通信：您可以按照电子邮件中提供的说明选择不接收促销电子邮件或新闻通讯。\n\n安全\n\n我们采取合理措施保护您的个人信息安全，但请注意，没有任何通过互联网或电子存储传输的方法完全安全。\n\n本隐私政策的变更\n\n我们可能会不时更新本隐私政策，任何变更都将发布在此页面上。在本隐私政策发生任何变更后，您继续使用应用程序即表示您接受修订后的条款。\n\n联系我们\n\n如果您对本隐私政策有任何疑问或担忧，请通过 lotlocate@gmail.com 与我们联系。',
    },
    'm5q7cz6k': {
      'en': 'Privacy policy',
      'fr': 'Politique de confidentialité',
      'ms': 'Dasar privasi',
      'zh_Hans': '隐私政策',
    },
    'zfz6cjv7': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // SupportPage
  {
    'vspkcbl8': {
      'en': 'Welcome to support',
      'fr': 'Bienvenue au support',
      'ms': 'Selamat datang untuk menyokong',
      'zh_Hans': '欢迎支持',
    },
    '6gj6bv8m': {
      'en': 'How can we help you?',
      'fr': 'Comment pouvons-nous vous aider?',
      'ms': 'Bagaimanakah kami boleh membantu anda?',
      'zh_Hans': '我们该怎样帮助你？',
    },
    '22xjx4m8': {
      'en': 'Type your response/feedback/question:',
      'fr': 'Consultez la FAQ ci-dessous',
      'ms': 'Semak Soalan Lazim di bawah',
      'zh_Hans': '查看以下常见问题解答',
    },
    'vgg0mkrf': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    't6encbjq': {
      'en': 'Type here...',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '2t26b0kw': {
      'en': 'Send',
      'fr': 'Discuter maintenant',
      'ms': 'Berbual sekarang',
      'zh_Hans': '现在聊天',
    },
    'jvc8q3fx': {
      'en': 'Help and support',
      'fr': 'Aide et soutien',
      'ms': 'Bantuan dan sokongan',
      'zh_Hans': '帮助和支持',
    },
    '13x7e5r9': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // NotificationsPage
  {
    '27z3vshj': {
      'en': 'Share',
      'fr': 'Partager',
      'ms': 'Kongsi',
      'zh_Hans': '分享',
    },
    'zhaa8ld6': {
      'en': 'Title',
      'fr': 'Titre',
      'ms': 'Tajuk',
      'zh_Hans': '标题',
    },
    'ksmc8fzm': {
      'en': 'Subtitle goes here...',
      'fr': 'Le sous-titre va ici...',
      'ms': 'Sari kata pergi di sini...',
      'zh_Hans': '此处加字幕...',
    },
    'g7lcy2iz': {
      'en': 'Notifications',
      'fr': 'Notifications',
      'ms': 'Pemberitahuan',
      'zh_Hans': '通知',
    },
    'znoysb42': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // PhoneOTPPage
  {
    '4ckp84ck': {
      'en': 'LotLocate',
      'fr': 'LotLocaliser',
      'ms': 'LotLocate',
      'zh_Hans': '地段定位',
    },
    '5ikbrwnk': {
      'en': 'Log In',
      'fr': 'Se connecter',
      'ms': 'Log masuk',
      'zh_Hans': '登录',
    },
    'gr15jt32': {
      'en': 'Welcome Back!',
      'fr': 'Content de te revoir!',
      'ms': 'Selamat kembali!',
      'zh_Hans': '欢迎回来！',
    },
    'lmqbfern': {
      'en': 'Enter your phone number (+65)',
      'fr': 'Entrez votre numéro de téléphone',
      'ms': 'Masukkan nombor telefon anda',
      'zh_Hans': '输入你的电话号码',
    },
    'u1ayy6zp': {
      'en': 'Get OTP',
      'fr': 'Obtenir OTP',
      'ms': 'Dapatkan OTP',
      'zh_Hans': '获取 OTP',
    },
    'a6rrd6yu': {
      'en': 'Don\'t have an account? Sign up',
      'fr': 'Vous n\'avez pas de compte ? S\'inscrire',
      'ms': 'Tiada akaun? daftar',
      'zh_Hans': '还没有账户？注册',
    },
    'vuhxx22f': {
      'en': ' here.',
      'fr': 'ici.',
      'ms': 'di sini.',
      'zh_Hans': '这里。',
    },
    'gki8s64n': {
      'en': 'Log In with Google',
      'fr': 'Continuer avec Google',
      'ms': 'Teruskan dengan Google',
      'zh_Hans': '继续使用 Google',
    },
    'gl3xvoyd': {
      'en': 'Get OTP by Email',
      'fr': 'Obtenez OTP par e-mail',
      'ms': 'Dapatkan OTP melalui E-mel',
      'zh_Hans': '通过电子邮件获取 OTP',
    },
    'nzibbqro': {
      'en': ' here.',
      'fr': 'ici.',
      'ms': 'di sini.',
      'zh_Hans': '这里。',
    },
  },
  // ParkingLocationDetailsPage
  {
    'ufir5x8p': {
      'en': 'Total Available Slots: ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'p36rcue3': {
      'en': '*',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'bwki7owp': {
      'en': 'Incoming Cars: ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'globwl2s': {
      'en': '*',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'y2x3ttb0': {
      'en': 'Outgoing Cars: ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ocs5euzb': {
      'en': '*',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '5vays54v': {
      'en': 'Go',
      'fr': 'Obtenir des directions',
      'ms': 'Dapatkan arah',
      'zh_Hans': '获取路线',
    },
    'givwok86': {
      'en': '* from FYP',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'dm6cqdj2': {
      'en': 'Photos',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'xifjtmu5': {
      'en': 'Facilities',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'sqhvi3zz': {
      'en': 'WheelChair Accessible Entrance',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'kdxwcdc5': {
      'en': 'Opening hours',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'gdl7407z': {
      'en': 'This carpark has not registered their opening hours with Google.',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jmdq9yvg': {
      'en': 'Car Park Rates',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '636wy4mi': {
      'en': 'Weekday Rate:   ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'yxxytc0s': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'yo8i8qwy': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'vgi213z7': {
      'en': ' per ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'pyfrtf3l': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'dgjbr6nv': {
      'en': 'Saturday Rate:   ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ck2gl3dr': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'tnp550e3': {
      'en': ' per ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'n66amq2t': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '21fkwtmf': {
      'en': 'Sunday Rate:   ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'hhxy43bg': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'cvu9vhll': {
      'en': ' per ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ul0nmh6x': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '0ewql6f6': {
      'en': 'Review Summary',
      'fr': 'Résumé des commentaires',
      'ms': 'Ringkasan Semakan',
      'zh_Hans': '评测总结',
    },
    'qfpp6gd9': {
      'en': 'Home',
      'fr': 'Maison',
      'ms': 'Rumah',
      'zh_Hans': '家',
    },
  },
  // MapPage
  {
    'ev4ac407': {
      'en': 'Search',
      'fr': 'Rechercher un parking ou un code de parking',
      'ms': 'Cari Tempat Letak Kereta atau Kod Tempat Letak Kereta',
      'zh_Hans': '搜索停车场或停车场代码',
    },
    'hzpzznbz': {
      'en': 'Filter',
      'fr': 'Filtre',
      'ms': 'Penapis',
      'zh_Hans': '筛选',
    },
    'q7a9egxv': {
      'en': 'Distance',
      'fr': 'Distance',
      'ms': 'Jarak',
      'zh_Hans': '距离',
    },
    'x1ui3vce': {
      'en': '0.0km',
      'fr': '0,0km',
      'ms': '0.0km',
      'zh_Hans': '0.0公里',
    },
    'hzrxb6x1': {
      'en': '150km',
      'fr': '150km',
      'ms': '150km',
      'zh_Hans': '150公里',
    },
    'aaqezq4h': {
      'en': 'Price',
      'fr': 'Prix',
      'ms': 'harga',
      'zh_Hans': '价格',
    },
    'z227isap': {
      'en': '\$2.00/hour',
      'fr': '2,00 \$/heure',
      'ms': '\$2.00/jam',
      'zh_Hans': '2.00 美元/小时',
    },
    'b3fbtv0y': {
      'en': '\$200/hour',
      'fr': '200 \$/heure',
      'ms': '\$200/jam',
      'zh_Hans': '200美元/小时',
    },
    'ptrtl11n': {
      'en': 'Rating',
      'fr': 'Notation',
      'ms': 'Penilaian',
      'zh_Hans': '评分',
    },
    'vwucky2f': {
      'en': '5',
      'fr': '5',
      'ms': '5',
      'zh_Hans': '5',
    },
    'juhxy4f9': {
      'en': '4',
      'fr': '4',
      'ms': '4',
      'zh_Hans': '4',
    },
    'mxzl8mtv': {
      'en': '3',
      'fr': '3',
      'ms': '3',
      'zh_Hans': '3',
    },
    'wz4h2xu6': {
      'en': '2',
      'fr': '2',
      'ms': '2',
      'zh_Hans': '2',
    },
    'cechwbb8': {
      'en': '1',
      'fr': '1',
      'ms': '1',
      'zh_Hans': '1',
    },
    '2afkwo7e': {
      'en': 'Clear All',
      'fr': 'Tout effacer',
      'ms': 'Kosongkan semua',
      'zh_Hans': '清除全部',
    },
    'nrx6l2jt': {
      'en': 'Apply',
      'fr': 'Appliquer',
      'ms': 'Mohon',
      'zh_Hans': '申请',
    },
    'r2x347we': {
      'en': '*',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'cg0uwtz4': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'k6pgyjmj': {
      'en': 'per',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'qlmf9519': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'c7kbku3t': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '2ugy2o2z': {
      'en': ' per ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ha5ay0tf': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'v47kktw8': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'yatieo58': {
      'en': ' per ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'xaq9kh0t': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    't3j18fdu': {
      'en': 'Closed now',
      'fr': 'Distance:',
      'ms': 'Jarak:',
      'zh_Hans': '距离：',
    },
    'jl69umo6': {
      'en': 'Open now',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '8qp031gv': {
      'en': 'Distance: ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'biuehns5': {
      'en': 'Slots available: ',
      'fr': 'Emplacements disponibles :',
      'ms': 'Slot tersedia:',
      'zh_Hans': '可用插槽：',
    },
    'bed4xao2': {
      'en': 'Slots available: ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'txjbiu18': {
      'en': '*',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '78afg87s': {
      'en': 'View',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'q9o4xfy9': {
      'en': '* from FYP',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'cd2pe0ba': {
      'en': 'Near By',
      'fr': 'Proche',
      'ms': 'Berdekatan',
      'zh_Hans': '附近',
    },
  },
  // LiveLocationToDestinationPage
  {
    'z7ggs8mp': {
      'en': 'Directions',
      'fr': 'Directions',
      'ms': 'Arah',
      'zh_Hans': '路线',
    },
  },
  // DirectionsPage
  {
    '1pepovqr': {
      'en': 'Origin',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '0flemq79': {
      'en': 'Choose starting point',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'p1qdt19e': {
      'en': 'Option 1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'gcm24lec': {
      'en': 'Destination',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ux0pjx4t': {
      'en': 'Choose destination',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'd3zqzqp0': {
      'en': 'Option 1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ntqncm33': {
      'en': '',
      'fr': 'Distance:',
      'ms': 'Jarak:',
      'zh_Hans': '距离：',
    },
    'fynwyz7v': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'y84p5f8n': {
      'en': 'mins',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'mb4s1mpx': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'khla6cnu': {
      'en': 'mins',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '057v6jcj': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'otjoybpx': {
      'en': 'mins',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '6b50opao': {
      'en': ' ',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ryi0dyoy': {
      'en': 'mins',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'hzo8ls7y': {
      'en': 'Directions',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'c1wcv5yf': {
      'en': 'Go',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // FlavaPage
  {
    'n2se7h3n': {
      'en': 'Start',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '0xj7maje': {
      'en': 'Home',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // Directions
  {
    '1yxslf81': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'p2i29bwd': {
      'en': 'Find Starting Point',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'mjrthy56': {
      'en': 'Option 1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'peeckbbu': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'gym54vr1': {
      'en': 'Find Destination',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'qnlduqm3': {
      'en': 'Option 1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'picyor4o': {
      'en': 'Your location',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'f2c535wv': {
      'en': 'Go',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // ClaudeChatBot
  {
    't6qen1sz': {
      'en': 'Enter message…',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'mkmun62k': {
      'en': 'SEND',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'dc72kp47': {
      'en': 'LotLocate ChatBot',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'p8xdx7cn': {
      'en': 'Claude',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // CreateAccWithPhonePage
  {
    'v8o4vlvq': {
      'en': 'Add Phone Number? (optional)',
      'fr': 'Créer un compte',
      'ms': 'Buat akaun',
      'zh_Hans': '创建账户',
    },
    'bz8mswhz': {
      'en': 'Please enter first name',
      'fr': 'Veuillez saisir votre prénom',
      'ms': 'Sila masukkan nama pertama',
      'zh_Hans': '请输入名字',
    },
    '1bsz2u61': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'ovr3bjjz': {
      'en': 'Please enter phone number',
      'fr': 'Veuillez entrer le numéro de téléphone',
      'ms': 'Sila masukkan nombor telefon',
      'zh_Hans': '请输入电话号码',
    },
    'l6giq7uq': {
      'en': 'Phone number should be all numbers',
      'fr': 'Le numéro de téléphone doit être composé uniquement de chiffres',
      'ms': 'Nombor telefon hendaklah semua nombor',
      'zh_Hans': '电话号码应全部为数字',
    },
    '5cuipbgh': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '4hatg3oq': {
      'en': 'Please enter email',
      'fr': 'Veuillez entrer votre email',
      'ms': 'Sila masukkan e-mel',
      'zh_Hans': '请输入电子邮箱',
    },
    'jrwdo3nx': {
      'en': 'At least 6 characters required',
      'fr': 'Au moins 6 caractères requis',
      'ms': 'Sekurang-kurangnya 6 aksara diperlukan',
      'zh_Hans': '至少需要 6 个字符',
    },
    'yob132a9': {
      'en': 'Email should not exceed 30 characters',
      'fr': 'L\'e-mail ne doit pas dépasser 30 caractères',
      'ms': 'E-mel tidak boleh melebihi 30 aksara',
      'zh_Hans': '电子邮件不得超过 30 个字符',
    },
    'd8pa09hz': {
      'en': 'Please enter a valid email',
      'fr': 'Veuillez entrer un email valide',
      'ms': 'Sila masukkan e-mel yang sah',
      'zh_Hans': '请输入有效电子邮件',
    },
    'cri8dpul': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '4er3evqy': {
      'en': 'Please enter password',
      'fr': 'Veuillez entrer le mot de passe',
      'ms': 'Sila masukkan kata laluan',
      'zh_Hans': '请输入密码',
    },
    'b5bf4ur4': {
      'en': 'At least 8 characters required',
      'fr': 'Au moins 8 caractères requis',
      'ms': 'Sekurang-kurangnya 8 aksara diperlukan',
      'zh_Hans': '至少需要 8 个字符',
    },
    'i7pruokr': {
      'en': 'Email should not exceed 120 characters',
      'fr': 'L\'e-mail ne doit pas dépasser 120 caractères',
      'ms': 'E-mel tidak boleh melebihi 120 aksara',
      'zh_Hans': '电子邮件不得超过 120 个字符',
    },
    'oull4mzi': {
      'en':
          'Password must contain at least one number, one alphabet character, and one special character.',
      'fr':
          'Le mot de passe doit contenir au moins un chiffre, un caractère alphabétique et un caractère spécial.',
      'ms':
          'Kata laluan mesti mengandungi sekurang-kurangnya satu nombor, satu aksara abjad dan satu aksara khas.',
      'zh_Hans': '密码必须至少包含一个数字、一个字母字符和一个特殊字符。',
    },
    '0mqqk9ni': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'wqcfijen': {
      'en': 'Please enter confirmation password',
      'fr': 'Veuillez saisir le mot de passe de confirmation',
      'ms': 'Sila masukkan kata laluan pengesahan',
      'zh_Hans': '请输入确认密码',
    },
    '6ni6hvye': {
      'en': 'At least 8 characters required',
      'fr': 'Au moins 8 caractères requis',
      'ms': 'Sekurang-kurangnya 8 aksara diperlukan',
      'zh_Hans': '至少需要 8 个字符',
    },
    'mdwo0dmd': {
      'en': 'Email should not exceed 120 characters',
      'fr': 'L\'e-mail ne doit pas dépasser 120 caractères',
      'ms': 'E-mel tidak boleh melebihi 120 aksara',
      'zh_Hans': '电子邮件不得超过 120 个字符',
    },
    '9tshfjve': {
      'en':
          'Password must contain at least one number, one alphabet character, and one special character.',
      'fr':
          'Le mot de passe doit contenir au moins un chiffre, un caractère alphabétique et un caractère spécial.',
      'ms':
          'Kata laluan mesti mengandungi sekurang-kurangnya satu nombor, satu aksara abjad dan satu aksara khas.',
      'zh_Hans': '密码必须至少包含一个数字、一个字母字符和一个特殊字符。',
    },
    't4r9mty5': {
      'en': 'Please choose an option from the dropdown',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'ms': 'Sila pilih pilihan daripada menu lungsur',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '9fg9vxys': {
      'en': 'Later',
      'fr': 'Plus tard',
      'ms': 'Nanti',
      'zh_Hans': '之后',
    },
    'ei2giwvk': {
      'en': 'Update',
      'fr': 'Mise à jour',
      'ms': 'Kemas kini',
      'zh_Hans': '更新',
    },
    'vptova70': {
      'en': 'Phone Number',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // Dashboard
  {
    'caxflv31': {
      'en': 'Get Statistics',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'd8omz5no': {
      'en': 'Dashboard',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'k25qi29p': {
      'en': 'Home',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // Matilda
  {
    '5w0ekj4h': {
      'en': 'Press on me to try our Voice Assistant, Matilda!',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'irs7uu43': {
      'en': 'LotLocate Voice Assistant',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'c8lfptlu': {
      'en': 'Matilda',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // LotLocateClaude
  {
    'di96zytv': {
      'en': 'LotLocate Voice Assistant',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ks7kf1y0': {
      'en': 'Matilda',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // LotLocateChatGPTRegular
  {
    'kayxo97h': {
      'en': 'LotLocate Voice Assistant (Working)',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'g6rjc8qf': {
      'en': 'Matilda',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // DirectionsFromNearBy
  {
    'eup7qcak': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '19avtqwi': {
      'en': 'Find Starting Point',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jdjjoipp': {
      'en': 'Option 1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'j199agvi': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'z6hu5w3u': {
      'en': 'Find Destination',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'zzifw444': {
      'en': 'Option 1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'sdxww2c7': {
      'en': 'Your location',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'bxenaq8n': {
      'en': 'Go',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // FavouritePlaces
  {
    'ngdu0ppy': {
      'en': 'Search for favourite',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'hmq22wsr': {
      'en': 'Favourited Places',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'evaldfi3': {
      'en': 'Refresh me after!',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '3q2gio0f': {
      'en': 'Home',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // LotLocateChatGPTRegularCopy
  {
    '90szpfw1': {
      'en': 'LotLocate Voice Assistant (Working)',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'n1t2rggn': {
      'en': 'Matilda',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // UsersPage
  {
    'p2g25d3e': {
      'en': 'Search for patients...',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'fe1pwykp': {
      'en': 'Randy Rudolph',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'cqp3fcy7': {
      'en': '(123) 456-7890',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'xsczhlxd': {
      'en': 'name@domain.com',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jxaeqy3g': {
      'en': 'Search patients',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ia9mesx9': {
      'en': 'Home',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // accountDropDown
  {
    '1ft91rs6': {
      'en': 'Account Options',
      'fr': 'Options de compte',
      'ms': 'Pilihan Akaun',
      'zh_Hans': '账户选项',
    },
    '2nj7gwtx': {
      'en': 'My Account',
      'fr': 'Mon compte',
      'ms': 'Akaun saya',
      'zh_Hans': '我的账户',
    },
    '70gp47jh': {
      'en': 'Settings',
      'fr': 'Paramètres',
      'ms': 'tetapan',
      'zh_Hans': '设置',
    },
    'k4vmuoc2': {
      'en': 'Light Mode',
      'fr': 'Mode lumière',
      'ms': 'Mod Cahaya',
      'zh_Hans': '灯光模式',
    },
    'jnpr3y66': {
      'en': 'Dark Mode',
      'fr': 'Mode sombre',
      'ms': 'Mod Gelap',
      'zh_Hans': '暗黑模式',
    },
    'x8ixoay0': {
      'en': 'Log out',
      'fr': 'Se déconnecter',
      'ms': 'Log keluar',
      'zh_Hans': '登出',
    },
  },
  // sideNav_Main
  {
    '5rr2lkho': {
      'en': 'LotLocate',
      'fr': 'LotLocaliser',
      'ms': 'LotLocate',
      'zh_Hans': '地段定位',
    },
    'qqxgd4mo': {
      'en': 'Near By',
      'fr': 'Proche',
      'ms': 'Berdekatan',
      'zh_Hans': '附近',
    },
    'pru9gd6k': {
      'en': 'Booking',
      'fr': 'Réservation',
      'ms': 'Tempahan',
      'zh_Hans': '預訂',
    },
    'owsu25v5': {
      'en': 'Ai Chat',
      'fr': 'Chat Ai',
      'ms': 'Ai Chat',
      'zh_Hans': '愛聊',
    },
  },
  // EmailOTPComponent
  {
    '54cav2d7': {
      'en': 'Enter the OTP',
      'fr': 'Entrez l\'OTP',
      'ms': 'Masukkan OTP',
      'zh_Hans': '输入 OTP',
    },
    'xgu2npir': {
      'en': 'Cancel',
      'fr': 'Annuler',
      'ms': 'Batal',
      'zh_Hans': '取消',
    },
    'ltdn2qzw': {
      'en': 'Verify Code',
      'fr': 'Vérifier le code',
      'ms': 'Sahkan kod',
      'zh_Hans': '验证码',
    },
  },
  // LogOutComponent
  {
    'ghbmkciy': {
      'en': 'Logout',
      'fr': 'Se déconnecter',
      'ms': 'Log keluar',
      'zh_Hans': '登出',
    },
    '0g5b5lmk': {
      'en': 'Are you sure you want to logout of your account?',
      'fr': 'Êtes-vous sûr de vouloir vous déconnecter de votre compte ?',
      'ms': 'Adakah anda pasti mahu log keluar daripada akaun anda?',
      'zh_Hans': '您确定要退出您的账户吗？',
    },
    '33wqrlog': {
      'en': 'No',
      'fr': 'Non',
      'ms': 'Tidak',
      'zh_Hans': '不',
    },
    'i6xjbk2c': {
      'en': 'Logout',
      'fr': 'Se déconnecter',
      'ms': 'Log keluar',
      'zh_Hans': '登出',
    },
  },
  // ProfileUpdateComponent
  {
    '2lsek381': {
      'en': 'Update your particulars?',
      'fr': 'Mettre à jour vos coordonnées ?',
      'ms': 'Kemas kini butiran anda?',
      'zh_Hans': '更新您的资料吗？',
    },
    'vv2jdi4h': {
      'en': 'Cancel',
      'fr': 'Annuler',
      'ms': 'Batal',
      'zh_Hans': '取消',
    },
    '21fr5qu7': {
      'en': 'Save Changes',
      'fr': 'Sauvegarder les modifications',
      'ms': 'Simpan Perubahan',
      'zh_Hans': '保存更改',
    },
  },
  // DeleteAccountComponent
  {
    'dgu84s0s': {
      'en': 'Delete your account?',
      'fr': 'Supprimer votre compte?',
      'ms': 'Padamkan akaun anda?',
      'zh_Hans': '删除你的帳戶？',
    },
    'gt64vfue': {
      'en': 'Cancel',
      'fr': 'Annuler',
      'ms': 'Batal',
      'zh_Hans': '取消',
    },
    'ko7ypaw3': {
      'en': 'Confirm',
      'fr': 'Confirmer',
      'ms': 'sahkan',
      'zh_Hans': '确认',
    },
  },
  // PhoneOTPComponent
  {
    '07dmw5hp': {
      'en': 'Enter the OTP',
      'fr': 'Entrez l\'OTP',
      'ms': 'Masukkan OTP',
      'zh_Hans': '输入 OTP',
    },
    'vzbcoxu6': {
      'en': 'Cancel',
      'fr': 'Annuler',
      'ms': 'Batal',
      'zh_Hans': '取消',
    },
    '9whih53i': {
      'en': 'Verify Code',
      'fr': 'Vérifier le code',
      'ms': 'Sahkan kod',
      'zh_Hans': '验证码',
    },
  },
  // FilterComponent
  {
    'uqcw280c': {
      'en': 'Filter',
      'fr': 'Filtre',
      'ms': 'Penapis',
      'zh_Hans': '筛选',
    },
    'rmnuha42': {
      'en': 'Distance',
      'fr': 'Distance',
      'ms': 'Jarak',
      'zh_Hans': '距离',
    },
    '39mzp2hi': {
      'en': '0.0km',
      'fr': '0,0km',
      'ms': '0.0km',
      'zh_Hans': '0.0公里',
    },
    'rw7i6wok': {
      'en': '150km',
      'fr': '150km',
      'ms': '150km',
      'zh_Hans': '150公里',
    },
    'ayoze8bi': {
      'en': 'Price',
      'fr': 'Prix',
      'ms': 'harga',
      'zh_Hans': '价格',
    },
    't75lyhj2': {
      'en': '\$2.00/hour',
      'fr': '2,00 \$/heure',
      'ms': '\$2.00/jam',
      'zh_Hans': '2.00 美元/小时',
    },
    '3zvao1pk': {
      'en': '\$200/hour',
      'fr': '200 \$/heure',
      'ms': '\$200/jam',
      'zh_Hans': '200美元/小时',
    },
    'xz3dg14u': {
      'en': 'Rating',
      'fr': 'Notation',
      'ms': 'Penilaian',
      'zh_Hans': '评分',
    },
    'spjap7xx': {
      'en': '5',
      'fr': '5',
      'ms': '5',
      'zh_Hans': '5',
    },
    'mxihimt2': {
      'en': '5',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'j40hqqa1': {
      'en': '4',
      'fr': '4',
      'ms': '4',
      'zh_Hans': '4',
    },
    'uoj0ii22': {
      'en': '4',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'f0d5jh7h': {
      'en': '3',
      'fr': '3',
      'ms': '3',
      'zh_Hans': '3',
    },
    'b0jqt1kh': {
      'en': '3',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'b4nyy3ui': {
      'en': '2',
      'fr': '2',
      'ms': '2',
      'zh_Hans': '2',
    },
    'kwib5fbm': {
      'en': '2',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '12v728he': {
      'en': '1',
      'fr': '1',
      'ms': '1',
      'zh_Hans': '1',
    },
    't1jnlphc': {
      'en': '1',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '6t1avffq': {
      'en': 'Clear All',
      'fr': 'Tout effacer',
      'ms': 'Kosongkan semua',
      'zh_Hans': '清除全部',
    },
    '7e3lv43r': {
      'en': 'Apply',
      'fr': 'Appliquer',
      'ms': 'Mohon',
      'zh_Hans': '申请',
    },
  },
  // DirectionsBottomSheet
  {
    'nyf3uv4i': {
      'en': 'Directions',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
  // Miscellaneous
  {
    '1ilv0ixf': {
      'en': 'Email address',
      'fr': 'Adresse e-mail',
      'ms': 'Alamat emel',
      'zh_Hans': '电子邮件地址',
    },
    'nwpjdfkn': {
      'en': 'Password',
      'fr': 'Mot de passe',
      'ms': 'Kata laluan',
      'zh_Hans': '密码',
    },
    '80z87tpw': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'gb2scwyn': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'gp5vst4e': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'o34tx2cf': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'z34dis43': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'qqlfqjcm': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    's3ebk372': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    '2uo1g5gi': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'yzmy4fik': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'ufurrz4p': {
      'en': 'Calling',
      'fr': 'Appel',
      'ms': 'Memanggil',
      'zh_Hans': '呼唤',
    },
    'ld9e31z2': {
      'en': 'Not Called',
      'fr': 'Non appelé',
      'ms': 'Tidak Dipanggil',
      'zh_Hans': '未呼叫',
    },
    '5q9lhont': {
      'en': 'Pending Review',
      'fr': 'En attendant l\'examen',
      'ms': 'Menunggu Semakan',
      'zh_Hans': '待审核',
    },
    'ij2z18fs': {
      'en': 'Closed',
      'fr': 'Fermé',
      'ms': 'tertutup',
      'zh_Hans': '关闭',
    },
    'j2ehw344': {
      'en': 'Completed',
      'fr': 'Complété',
      'ms': 'Selesai',
      'zh_Hans': '完全的',
    },
    '2e8w8ib5': {
      'en': 'Please select...',
      'fr': 'Veuillez sélectionner...',
      'ms': 'Sila pilih...',
      'zh_Hans': '请选择...',
    },
    '6vqm0yx1': {
      'en': 'Search for an item...',
      'fr': 'Rechercher un article...',
      'ms': 'Cari item...',
      'zh_Hans': '搜索商品...',
    },
    '8klk4nmz': {
      'en': 'All',
      'fr': 'Tous',
      'ms': 'Semua',
      'zh_Hans': '全部',
    },
    'zx8dwj8i': {
      'en': 'Pending',
      'fr': 'En attente',
      'ms': 'Yang belum selesai',
      'zh_Hans': '待办的',
    },
    '3koc6na9': {
      'en': 'Completed',
      'fr': 'Complété',
      'ms': 'Selesai',
      'zh_Hans': '完全的',
    },
    'x6vjdnh3': {
      'en': 'Calling',
      'fr': 'Appel',
      'ms': 'Memanggil',
      'zh_Hans': '呼唤',
    },
    'g842lvaz': {
      'en': 'All',
      'fr': 'Tous',
      'ms': 'Semua',
      'zh_Hans': '全部',
    },
    'rypr22ar': {
      'en': '50%',
      'fr': '50%',
      'ms': '50%',
      'zh_Hans': '50％',
    },
    'qwqgf3zw': {
      'en': 'Notifications',
      'fr': 'Notifications',
      'ms': 'Pemberitahuan',
      'zh_Hans': '通知',
    },
    'ckay04jx': {
      'en': 'Notifications',
      'fr': 'Notifications',
      'ms': 'Pemberitahuan',
      'zh_Hans': '通知',
    },
    '1hvxflj5': {
      'en': 'Turn on notifications',
      'fr': 'Activer les notifications',
      'ms': 'Hidupkan pemberitahuan',
      'zh_Hans': '打开通知',
    },
    'jnhpsn1g': {
      'en': 'Male',
      'fr': 'Mâle',
      'ms': 'jantan',
      'zh_Hans': '男性',
    },
    'of0d1czc': {
      'en': 'Female',
      'fr': 'Femelle',
      'ms': 'perempuan',
      'zh_Hans': '女性',
    },
    'y90g4xw4': {
      'en': 'Other',
      'fr': 'Autre',
      'ms': 'Lain-lain',
      'zh_Hans': '其他',
    },
    'srpjkmaq': {
      'en': 'Design',
      'fr': 'Conception',
      'ms': 'Reka bentuk',
      'zh_Hans': '设计',
    },
    'ayilj2tq': {
      'en': 'Marketing',
      'fr': 'Commercialisation',
      'ms': 'Pemasaran',
      'zh_Hans': '营销',
    },
    'ytbqwtwc': {
      'en': 'Development',
      'fr': 'Développement',
      'ms': 'Pembangunan',
      'zh_Hans': '发展',
    },
    'dv3u0w64': {
      'en': 'Management',
      'fr': 'Gestion',
      'ms': 'Pengurusan',
      'zh_Hans': '管理',
    },
    'hzi6q7i2': {
      'en': 'Operations',
      'fr': 'Opérations',
      'ms': 'operasi',
      'zh_Hans': '运营',
    },
    '6syw3t41': {
      'en': 'Customer Service',
      'fr': 'Service client',
      'ms': 'Khidmat Pelanggan',
      'zh_Hans': '客户服务',
    },
    '22kl5zmt': {
      'en': 'Design',
      'fr': 'Conception',
      'ms': 'Reka bentuk',
      'zh_Hans': '设计',
    },
    'ryptabxe': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'cxo48cwx': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'ppu8i3vs': {
      'en': 'Button',
      'fr': 'Bouton',
      'ms': 'Butang',
      'zh_Hans': '按钮',
    },
    'l3z234l7': {
      'en': 'LotLocate would like to access your camera',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '32us0u1o': {
      'en': 'LotLocate would like to access your Photo Library',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'mml2v2hy': {
      'en': 'LotLocate would like to get your location',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'k1y33xcf': {
      'en': 'LotLocate would like access your microphone',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'zz56x5p8': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '8lcobupz': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'piu9qb3f': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ffdhdrxt': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '4c0sdwug': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'qjr6wcoq': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'y68844xb': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '4m54qvdt': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'dvwhrjib': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '6blpx8bb': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'q9rt7zhg': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'sduzpzyx': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'goa35uu0': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jfr5e4fo': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'kky5jlqe': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '98g3d6jp': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ypskymyz': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '2m1bk2v7': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ywi2khtm': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'ac3vvhh0': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'zf49p2f5': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'jajlia0m': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'hdsu19p7': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    '6xbzoad9': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
    'fzl3nkh4': {
      'en': '',
      'fr': '',
      'ms': '',
      'zh_Hans': '',
    },
  },
].reduce((a, b) => a..addAll(b));
