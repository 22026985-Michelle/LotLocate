import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/auth/supabase_auth/auth_util.dart';

dynamic saveChatHistory(
  dynamic chatHistory,
  dynamic newChat,
) {
  // If chatHistory isn't a list, make it a list and then add newChat
  if (chatHistory is List) {
    chatHistory.add(newChat);
    return chatHistory;
  } else {
    return [newChat];
  }
}

dynamic convertToJSON(String prompt) {
  // take the prompt and return a JSON with form [{"role": "user", "content": prompt}]
  return json.decode('{"role": "user", "content": "$prompt"}');
}

String? latLngToString(LatLng? inputLocation) {
  // return inputLocation as string
  if (inputLocation == null) {
    return null;
  }
  return '${inputLocation.latitude},${inputLocation.longitude}';
}

List<LatLng>? listDoubletoLatLng(
  List<double>? latitude,
  List<double>? longitude,
) {
  // return latitude and longitude combined
  if (latitude == null || longitude == null) {
    return null;
  }
  if (latitude.length != longitude.length) {
    throw ArgumentError(
        'Latitude and longitude lists must have the same length');
  }
  final List<LatLng> result = [];
  for (int i = 0; i < latitude.length; i++) {
    result.add(LatLng(latitude[i], longitude[i]));
  }
  return result;
}

int? indexMarkerIdentifier(
  LatLng? centreMarkerCoordinate,
  List<LatLng>? listofLocation,
) {
  // return index of argument 1 in argument 2
  if (centreMarkerCoordinate == null || listofLocation == null) {
    return null;
  }
  for (int i = 0; i < listofLocation.length; i++) {
    if (centreMarkerCoordinate == listofLocation[i]) {
      return i;
    }
  }
  return null;
}

String? constructPhotoUrl(
  String photoReference,
  String apiKey,
) {
  return 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' +
      photoReference +
      '&key=' +
      apiKey;
}

dynamic generateMessages(
  List<MessagesRecord> messages,
  String newMessage,
) {
  List<Map<String, String>> msgs = [];
  messages.forEach((element) {
    msgs.add({
      "role": element.user == "ChatGPT" ? "assistant" : "user",
      "content": element.message!
    });
  });

  msgs.add({"role": "user", "content": newMessage});

  return jsonEncode(msgs);
}

dynamic generateMessage(String newMessage) {
  List<Map<String, String>> msgs = [
    {"role": "user", "content": newMessage}
  ];

  return jsonEncode(msgs);
}

LatLng makeLatLon(
  double lat,
  double lon,
) {
  return LatLng(lat, lon);
}

String newLine() {
  return "\n";
}

int? secondsToMinutes(int? durInSeconds) {
  // convert durInSeconds to minutes from seconds, return integer
  if (durInSeconds == null) {
    return null;
  }
  return (durInSeconds / 60).floor();
}

dynamic generateMessagesClaude(List<MessageTypeStruct> messages) {
  List<Map<String, String>> msgs = [];
  messages.forEach((element) {
    msgs.add({"role": element.role, "content": element.message});
  });

  // msgs.add({"role": "user", "content": newMessage});

  return jsonEncode(msgs);
}

LatLng flipCoords(List<String> coordinates) {
  double longitude = double.parse(coordinates[0]);
  double latitude = double.parse(coordinates[1]);
  LatLng latlng = LatLng(latitude, longitude);
  return latlng;
}

LatLng flipCoordLocation(LatLng coordinates) {
  return LatLng(coordinates.latitude, coordinates.longitude);
}

String getPlaceNameFromCoordinatesFunction(LatLng coordinates) {
  double lat = (coordinates.latitude * 10000).round() / 10000;
  double lng = (coordinates.longitude * 10000).round() / 10000;

  // Create a simple representation of the location
  String placeName = 'Location at $lat, $lng';

  return placeName;
}

String getLocalPartFromEmail(String email) {
  final atIndex = email.indexOf('@');
  if (atIndex != -1) {
    return email.substring(0, atIndex);
  } else {
    return email;
  }
}

dynamic claudeConverter(
  String? message,
  String? systemPrompt,
) {
  message ??= '';
  systemPrompt ??= '';

  return [
    {"role": "user", "content": message}
  ];
}

dynamic chatGPTConverter(String? message) {
// null safety
  message ??= '';

  List<dynamic> result = [];

  // add the role
  result.add({"role": "user", "content": message});
  print(result);
  return result;
}

dynamic openAIMessageFormatter(
  String userMessage,
  String systemPrompt,
) {
  return [
    {"role": "system", "content": systemPrompt},
    {"role": "user", "content": userMessage}
  ];
}

double stringToDouble(String input) {
  try {
    return double.parse(input);
  } catch (e) {
    print("Error parsing string to double: $e");
    // You can choose to return a default value or rethrow the exception
    return 0.0; // or throw e;
  }
}

LatLng? stringToLatLng(String? input) {
  // convert argument 1 to lat lng
  if (input == null) {
    return null;
  }
  final parts = input.split(',');
  if (parts.length != 2) {
    return null;
  }
  final lat = double.tryParse(parts[0]);
  final lng = double.tryParse(parts[1]);
  if (lat == null || lng == null) {
    return null;
  }
  return LatLng(lat, lng);
}

String concatenateClaudeResponse(List<dynamic> content) {
  String fullResponse = '';
  for (var item in content) {
    if (item['type'] == 'text') {
      fullResponse += item['text'];
    }
  }
  return fullResponse;
}

String cleanText(String input) {
  List<String> startPhrases = [
    "I understand.",
    "I'll respond helpfully",
    "I'm happy to assist you",
    "Certainly, I'd be glad to help."
  ];

  // List of potential ending phrases
  List<String> endPhrases = [
    "Let me know if you have any questions or topics you'd like to discuss!",
    "How can I assist you today?",
    "What would you like to know?"
  ];

  // Find the start of the actual content
  int startIndex = input.length;
  for (String phrase in startPhrases) {
    int index = input.indexOf(phrase);
    if (index != -1 && index < startIndex) {
      startIndex = index;
    }
  }

  // Find the end of the disclaimer
  int endIndex = -1;
  for (String phrase in endPhrases) {
    int index = input.indexOf(phrase);
    if (index != -1 && (endIndex == -1 || index < endIndex)) {
      endIndex = index + phrase.length;
    }
  }

  // If we found both start and end, remove the disclaimer
  if (startIndex < input.length && endIndex != -1 && endIndex > startIndex) {
    return input.substring(endIndex).trim();
  }

  // If we couldn't find the disclaimer, return the original input
  return input;
}
