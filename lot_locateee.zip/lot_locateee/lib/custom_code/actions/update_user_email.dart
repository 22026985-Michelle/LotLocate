// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<String?> updateUserEmail(String email) async {
  final supabase = Supabase.instance.client;
  try {
    // Update auth email
    await supabase.auth.updateUser(UserAttributes(
      email: email,
    ));

    // Update user_info table
    await supabase.from('user_info').update({
      'email': email,
    }).eq('id', supabase.auth.currentUser!.id);

    return null;
  } catch (e) {
    return 'Error updating email: $e';
  }
}
