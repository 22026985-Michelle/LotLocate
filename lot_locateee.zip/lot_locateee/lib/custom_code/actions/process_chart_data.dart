// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<List<ChartDataStruct>> processChartData(
    List<dynamic> statsOutput) async {
  Map<String, int> favoriteCounts = {};
  for (var row in statsOutput) {
    if (row['favourites'] != null) {
      List<String> favorites = List<String>.from(row['favourites']);
      for (var place in favorites) {
        favoriteCounts[place] = (favoriteCounts[place] ?? 0) + 1;
      }
    }
  }
  List<ChartDataStruct> chartData = favoriteCounts.entries.map((entry) {
    return ChartDataStruct(
      xTitle: entry.key,
      yValue: entry.value,
    );
  }).toList();
  // Sort by number of favorites (descending)
  chartData.sort((a, b) => b.yValue.compareTo(a.yValue));
  // Limit to top 5 favorites
  return chartData.take(5).toList();
}
