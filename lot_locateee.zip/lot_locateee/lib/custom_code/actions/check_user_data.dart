// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<bool> checkUserData() async {
  final supabase = Supabase.instance.client;
  final user = supabase.auth.currentUser;
  if (user != null) {
    try {
      final userData =
          await supabase.from('users').select().eq('id', user.id).single();
      if (userData == null) {
        // Create user record if it doesn't exist
        await supabase.from('users').insert({
          'id': user.id,
          'phone': user.phone,
          // Add any other initial user data here
        });
        return false; // Return false to indicate new user
      }
      return userData['name'] != null && userData['email'] != null;
    } catch (error) {
      print('Error fetching user data: $error');
      return false;
    }
  }
  return false;
}
