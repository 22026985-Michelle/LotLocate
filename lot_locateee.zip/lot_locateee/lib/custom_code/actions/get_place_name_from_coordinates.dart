// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;
import '/flutter_flow/lat_lng.dart';

Future<String> getPlaceNameFromCoordinates(
    LatLng coordinates, String accessToken) async {
  /// MODIFY CODE ONLY BELOW THIS LINE
  final url =
      'https://api.mapbox.com/geocoding/v5/mapbox.places/${coordinates.longitude},${coordinates.latitude}.json?access_token=$accessToken';

  try {
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['features'] != null && data['features'].isNotEmpty) {
        // Return the place name (you can modify this to return more specific information if needed)
        return data['features'][0]['place_name'] ?? 'Unknown location';
      }
    }
    return 'Unable to get location name';
  } catch (e) {
    print('Error getting place name: $e');
    return 'Error occurred';
  }

  /// MODIFY CODE ONLY ABOVE THIS LINE
}
