// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<String?> getUserEmailFromUserInfo() async {
  final supabase = Supabase.instance.client;
  try {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      return null;
    }

    final response = await supabase
        .from('user_info')
        .select('email')
        .eq('id', userId)
        .single();

    return response['email'] as String?;
  } catch (e) {
    print('Error getting user email: $e');
    return null;
  }
}
