// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:math' as math;

Future<void> refreshToken() async {
  int attempts = 0;
  final maxAttempts = 5;

  while (attempts < maxAttempts) {
    try {
      final supabase = Supabase.instance.client;
      await supabase.auth.refreshSession();
      break; // Success, exit the loop
    } catch (e) {
      attempts++;
      if (attempts >= maxAttempts) {
        // Max attempts reached, handle the error (e.g., log out the user)
        await Supabase.instance.client.auth.signOut();
        // Navigate to login screen or show an error message
        break;
      }
      // Wait before next attempt using exponential backoff
      final waitTime = math.pow(2, attempts).toInt();
      await Future.delayed(Duration(seconds: waitTime));
    }
  }
}
