// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<void> getMostFavoritedPlaces() async {
  final supabase = Supabase.instance.client;

  try {
    final response = await supabase.rpc('get_most_favorited_places');

    if (response != null && response is List) {
      List<String> placeNames = [];
      List<int> favoriteCounts = [];

      for (var item in response) {
        if (item is Map<String, dynamic>) {
          placeNames.add(item['place'] as String);
          favoriteCounts.add(item['count'] as int);
        }
      }

      FFAppState().placeNames = placeNames;
      FFAppState().favoriteCounts = favoriteCounts;
    }
  } catch (e) {
    print('Error fetching most favorited places: $e');
  }
}
