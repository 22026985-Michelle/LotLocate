// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;

Future<List<dynamic>> forwardGeocode(
  String searchQuery,
  String accessToken,
) async {
  String encodedQuery = Uri.encodeFull(searchQuery);
  final response = await http.get(
      Uri.parse(
          'https://api.mapbox.com/geocoding/v5/mapbox.places/$encodedQuery.json?&access_token=$accessToken'),
      headers: {
        'Authorization': 'Bearer $accessToken',
        'Content-Type': 'application/json',
      });

  if (response.statusCode == 200) {
    print('Directions successfully calculated');
    final Map<String, dynamic> jsonResponse = json.decode(response.body);
    final List<dynamic> features = jsonResponse['features'];
    if (features.isEmpty) {
      return [
        {'place_name': 'No places found'}
      ];
    } else {
      return features;
    }
  } else {
    print('Error calculating directions: ${response.statusCode}');
    print('Response body: ${response.body}');
    return [
      {'place_name': 'No places found'}
    ];
  }
}
