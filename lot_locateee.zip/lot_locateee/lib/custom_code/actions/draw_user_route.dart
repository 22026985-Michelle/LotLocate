// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:geolocator/geolocator.dart';

Future<List<LatLng>> drawUserRoute(
  List<LatLng> userRoute,
  bool shouldClearRoute,
) async {
  // Initialize the route list
  List<LatLng> route = shouldClearRoute ? [] : List.from(userRoute);

  // Check for location permissions
  bool permissionGranted = await _checkLocationPermission();
  if (!permissionGranted) {
    return route; // Return the current route if permissions are not granted
  }

  try {
    // Get the current position
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    // Convert the position to LatLng and add it to the route
    LatLng newPosition = LatLng(position.latitude, position.longitude);
    route.add(newPosition);

    return route;
  } catch (e) {
    print('Error getting location: $e');
    return route; // Return the current route if there's an error
  }
}

Future<bool> _checkLocationPermission() async {
  bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    print('Location services are disabled');
    return false;
  }

  LocationPermission permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      print('Location permissions are denied');
      return false;
    }
  }

  if (permission == LocationPermission.deniedForever) {
    print('Location permissions are permanently denied');
    return false;
  }

  return true;
}
