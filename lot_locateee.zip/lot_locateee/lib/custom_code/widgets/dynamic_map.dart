// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'dart:async';

class DynamicMap extends StatefulWidget {
  const DynamicMap({
    Key? key,
    this.width,
    this.height,
    required this.accessToken,
    required this.startingPoint,
    required this.startingZoom,
    required this.reverseGeocodeAction,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String accessToken;
  final LatLng startingPoint;
  final double startingZoom;
  final Future Function(String accessToken, LatLng position)
      reverseGeocodeAction;

  @override
  State<DynamicMap> createState() => _DynamicMapState();
}

class _DynamicMapState extends State<DynamicMap> {
  final _mapController = MapController();
  late ll.LatLng tappedCoordinates;
  List<LatLng> userRoute = [];
  bool clearRoute = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    tappedCoordinates = ll.LatLng(
        widget.startingPoint.latitude, widget.startingPoint.longitude);
    _startRouteDrawing();
  }

  void _startRouteDrawing() {
    _timer = Timer.periodic(Duration(seconds: 5), (timer) async {
      final updatedRoute = await drawUserRoute(userRoute, clearRoute);
      setState(() {
        userRoute = updatedRoute;
        clearRoute = false;
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  List<Polyline> setRoute(List<LatLng> routeCoordinates) {
    return [
      Polyline(
        points: routeCoordinates
            .map((point) => ll.LatLng(point.latitude, point.longitude))
            .toList(),
        strokeWidth: 4,
        color: Colors.blue,
      ),
    ];
  }

  List<Marker> addMarkersToMap() {
    List<Marker> allMarkers = [];

    if (FFAppState().STARTMARKER != null) {
      allMarkers.add(
        Marker(
          point: ll.LatLng(FFAppState().STARTMARKER!.latitude,
              FFAppState().STARTMARKER!.longitude),
          height: 24,
          width: 24,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Icon(Icons.play_arrow, color: Colors.white, size: 16),
          ),
        ),
      );
    }

    if (FFAppState().ENDMARKER != null) {
      allMarkers.add(
        Marker(
          point: ll.LatLng(FFAppState().ENDMARKER!.latitude,
              FFAppState().ENDMARKER!.longitude),
          height: 24,
          width: 24,
          child: Icon(
            Icons.local_parking,
            color: Colors.red,
            size: 24,
          ),
        ),
      );
    }

    return allMarkers;
  }

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      mapController: _mapController,
      options: MapOptions(
        initialCenter: ll.LatLng(
            widget.startingPoint.latitude, widget.startingPoint.longitude),
        initialZoom: widget.startingZoom,
        onTap: (_, latLng) {
          final accessToken = widget.accessToken;
          setState(() {
            tappedCoordinates = latLng;
            if (!FFAppState().pointClicked) {
              _mapController.move(
                  ll.LatLng(latLng.latitude, latLng.longitude), 5);
              widget.reverseGeocodeAction(
                  accessToken, LatLng(latLng.latitude, latLng.longitude));
            }
            FFAppState().update(
                () => FFAppState().pointClicked = !FFAppState().pointClicked);
          });
        },
        onPositionChanged: (_, changed) {
          if (FFAppState().pointClicked) {
            FFAppState().update(() => FFAppState().pointClicked = false);
          }
        },
      ),
      children: [
        TileLayer(
          urlTemplate:
              'https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/{z}/{x}/{y}?access_token=${widget.accessToken}',
          additionalOptions: {
            'accessToken': widget.accessToken,
            'id': 'mapbox.mapbox-streets-v8',
          },
        ),
        MarkerLayer(
          markers: addMarkersToMap(),
        ),
        if (FFAppState().routeCoordinates.isNotEmpty)
          PolylineLayer(polylines: setRoute(FFAppState().routeCoordinates)),
        PolylineLayer(polylines: setRoute(userRoute)),
        MarkerLayer(
          markers: FFAppState().pointClicked
              ? [
                  Marker(
                    point: ll.LatLng(tappedCoordinates.latitude,
                        tappedCoordinates.longitude),
                    height: 24,
                    width: 24,
                    child: Center(
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey,
                          border: Border.all(
                            color: Colors.white,
                            width: 2,
                          ),
                        ),
                        child: Center(
                          child: Icon(
                            Icons.location_on,
                            size: 16,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ]
              : [],
        )
      ],
    );
  }
}
