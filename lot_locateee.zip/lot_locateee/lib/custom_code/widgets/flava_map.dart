// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';

import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'package:geolocator/geolocator.dart';

class FlavaMap extends StatefulWidget {
  const FlavaMap({
    super.key,
    this.width,
    this.height,
    required this.accessToken,
    required this.startMarker,
    required this.endMarker,
    required this.routeCoordinates,
  });

  final double? width;
  final double? height;
  final String accessToken;
  final LatLng? startMarker;
  final LatLng? endMarker;
  final List<LatLng> routeCoordinates;

  @override
  State<FlavaMap> createState() => _FlavaMapState();
}

class _FlavaMapState extends State<FlavaMap> {
  ll.LatLng? currentLocation;
  final List<ll.LatLng> route = [];
  bool clearRoute = false;
  final MapController _mapController = MapController();
  Timer? timer;

  Future<bool> checkPermissions() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Show a dialog or message to the user instead of throwing an exception
      print('Location services are disabled');
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Show a message to the user about the importance of location permissions
        print('Location permissions are denied');
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Guide the user to the app settings to enable location permissions
      print('Location permissions are permanently denied');
      return false;
    }

    // If we've made it this far, permissions are granted
    return true;
  }

  void getCurrentLocation() async {
    Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 3,
      ),
    ).listen((Position position) {
      ll.LatLng newPosition = ll.LatLng(position.latitude, position.longitude);
      if (mounted) {
        setState(() => currentLocation = newPosition);
        if (FFAppState().activityStarted) {
          if (clearRoute) {
            setState(() {
              route.clear();
              clearRoute = false;
            });
          }
          setState(() {
            route.add(newPosition);
          });
          _mapController.move(newPosition, 13);
        } else {
          if (!clearRoute) {
            setState(() {
              clearRoute = true;
            });
          }
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    checkPermissions().then((permissionAccepted) {
      if (permissionAccepted) {
        timer = Timer.periodic(Duration(seconds: 2), (Timer t) {
          // Get the user position
          getCurrentLocation();
        });
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    timer?.cancel();
  }

  List<Marker> addMarkersToMap() {
    List<Marker> markers = [];

    if (widget.startMarker != null) {
      markers.add(
        Marker(
          point: ll.LatLng(
              widget.startMarker!.latitude, widget.startMarker!.longitude),
          height: 24,
          width: 24,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Icon(Icons.play_arrow, color: Colors.white, size: 16),
          ),
        ),
      );
    }

    if (widget.endMarker != null) {
      markers.add(
        Marker(
          point: ll.LatLng(
              widget.endMarker!.latitude, widget.endMarker!.longitude),
          height: 24,
          width: 24,
          child: Icon(
            Icons.local_parking,
            color: Colors.red,
            size: 24,
          ),
        ),
      );
    }

    return markers;
  }

  @override
  Widget build(BuildContext context) {
    return currentLocation == null
        ? Center(child: CircularProgressIndicator())
        : FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: currentLocation!,
              initialZoom: 13,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
              ),
              PolylineLayer(
                polylines: [
                  Polyline(
                    points: widget.routeCoordinates
                        .map((point) =>
                            ll.LatLng(point.latitude, point.longitude))
                        .toList(),
                    strokeWidth: 4,
                    color: Colors.blue,
                  ),
                  Polyline(
                    points: route,
                    strokeWidth: 8,
                    color: Colors.red,
                  ),
                ],
              ),
              MarkerLayer(markers: [
                ...addMarkersToMap(),
                Marker(
                  width: 80,
                  height: 80,
                  point: currentLocation!,
                  child:
                      Icon(Icons.circle_rounded, size: 30, color: Colors.blue),
                ),
              ]),
            ],
          );
  }
}
