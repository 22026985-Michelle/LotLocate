// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:intl_phone_field/intl_phone_field.dart';

class PhoneNumberPicker extends StatefulWidget {
  const PhoneNumberPicker({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<PhoneNumberPicker> createState() => _PhoneNumberPickerState();
}

class _PhoneNumberPickerState extends State<PhoneNumberPicker> {
  String _countryCode = '+1'; // Default country code

  @override
  Widget build(BuildContext context) {
    return Container(
      child: IntlPhoneField(
        decoration: InputDecoration(
          labelText: 'Phone Number',
          border: OutlineInputBorder(
            borderSide: BorderSide(),
          ),
        ),
        initialCountryCode: 'US',
        onChanged: (phone) {
          String fullNumber = _countryCode + phone.number;
          FFAppState().update(() {
            FFAppState().phone = fullNumber;
          });
          print('Full number: $fullNumber');
        },
        onCountryChanged: (country) {
          setState(() {
            _countryCode = '+' + country.dialCode;
          });
          print('Country changed to: ${country.name}, Code: $_countryCode');
        },
      ),
    );
  }
}

// Function to return the phone number as a String
String getPhoneNumber() {
  return FFAppState().phone;
}
