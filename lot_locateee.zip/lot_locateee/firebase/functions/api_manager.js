const axios = require("axios").default;
const qs = require("qs");

/// Start OpenAI ChatGPT Group Code

function createOpenAIChatGPTGroup(token) {
  return {
    baseUrl: `https://api.openai.com/v1`,
    headers: {
      Authorization: `Bearer [token]`,
      "OpenAI-Beta": `assistants=v1`,
    },
  };
}

async function _threadsCall(context, ffVariables) {
  var token = ffVariables["token"];
  const openAIChatGPTGroup = createOpenAIChatGPTGroup(token);

  var url = `${openAIChatGPTGroup.baseUrl}/threads`;
  var headers = {
    Authorization: `Bearer ${token}`,
    "OpenAI-Beta": `assistants=v1`,
  };
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}

async function _messageCall(context, ffVariables) {
  var threadId = ffVariables["threadId"];
  var content = ffVariables["content"];
  var token = ffVariables["token"];
  const openAIChatGPTGroup = createOpenAIChatGPTGroup(token);

  var url = `${openAIChatGPTGroup.baseUrl}/threads/${threadId}/messages`;
  var headers = {
    Authorization: `Bearer ${token}`,
    "OpenAI-Beta": `assistants=v1`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "role": "user",
  "content": "${content}"
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}

async function _runCall(context, ffVariables) {
  var threadId = ffVariables["threadId"];
  var assistantId = ffVariables["assistantId"];
  var token = ffVariables["token"];
  const openAIChatGPTGroup = createOpenAIChatGPTGroup(token);

  var url = `${openAIChatGPTGroup.baseUrl}/threads/${threadId}/runs`;
  var headers = {
    Authorization: `Bearer ${token}`,
    "OpenAI-Beta": `assistants=v1`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "assistant_id": "${assistantId}"
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}

async function _retrieverunCall(context, ffVariables) {
  var threadId = ffVariables["threadId"];
  var runId = ffVariables["runId"];
  var token = ffVariables["token"];
  const openAIChatGPTGroup = createOpenAIChatGPTGroup(token);

  var url = `${openAIChatGPTGroup.baseUrl}/threads/${threadId}/runs/${runId}`;
  var headers = {
    Authorization: `Bearer ${token}`,
    "OpenAI-Beta": `assistants=v1`,
  };
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}

async function _messagesCall(context, ffVariables) {
  var threadId = ffVariables["threadId"];
  var token = ffVariables["token"];
  const openAIChatGPTGroup = createOpenAIChatGPTGroup(token);

  var url = `${openAIChatGPTGroup.baseUrl}/threads/${threadId}/messages`;
  var headers = {
    Authorization: `Bearer ${token}`,
    "OpenAI-Beta": `assistants=v1`,
  };
  var params = { limit: 1 };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}

/// End OpenAI ChatGPT Group Code

async function _nearbyPlacesCall(context, ffVariables) {
  var latlng = ffVariables["latlng"];

  var url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json`;
  var headers = {};
  var params = {
    key: `AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE`,
    radius: `2000`,
    type: `parking`,
    location: latlng,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _uRACarParkDetailsCall(context, ffVariables) {
  var url = `https://www.ura.gov.sg/uraDataService/invokeUraDS?service=Car_Park_Details`;
  var headers = {
    AccessKey: `ac8e4dc7-4f0f-412d-bbb5-92ef81d51e5e`,
    Token: `ff7-t5p855YDfducen1DdmP-Acb511esS5D19RhK88U-0J0f5eGbfCbgddf60bFjeet23XGa8eyc1b58T3D-34r5wGbf@K9ESq24`,
  };
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _dataMallCall(context, ffVariables) {
  var url = `http://datamall2.mytransport.sg/ltaodataservice/CarParkAvailabilityv2`;
  var headers = {
    AccountKey: `IGOTjyM0Rmq67G3o7MTrzg==`,
    accept: `application/json`,
  };
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _dataGovSGCarParkRatesCall(context, ffVariables) {
  var url = `https://data.gov.sg/api/action/datastore_search?resource_id=d_9f6056bdb6b1dfba57f063593e4f34ae`;
  var headers = {};
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _getPlacePhotoCall(context, ffVariables) {
  var photoReference = ffVariables["photoReference"];

  var url = `https://maps.googleapis.com/maps/api/place/photo`;
  var headers = {};
  var params = {
    maxwidth: `400`,
    photoreference: photoReference,
    key: `AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE`,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _distanceMatrixCall(context, ffVariables) {
  var destinations = ffVariables["destinations"];
  var origins = ffVariables["origins"];

  var url = `https://maps.googleapis.com/maps/api/distancematrix/json`;
  var headers = {};
  var params = {
    destinations: destinations,
    origins: origins,
    key: `AIzaSyCJbx_w3eE5_0OXGKwF4As1Tq2LFBd8Dyw`,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _getResponseCall(context, ffVariables) {
  var apiKeyAuth = ffVariables["apiKeyAuth"];
  var prompt = ffVariables["prompt"];
  var language = ffVariables["language"];

  var url = `https://api.openai.com/v1/chat/completions`;
  var headers = { Authorization: `Bearer ${apiKeyAuth}` };
  var params = {};
  var ffApiRequestBody = `
{
  "messages": [
    {
      "role": "user",
      "content": "${prompt}. Return a response that could be read allowed in a total of about 13-15 seconds in ${language} (language code)"
    }
  ],
  "model": "gpt-4-1106-preview",
  "max_tokens": 100
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _chatGPTCall(context, ffVariables) {
  var messages = ffVariables["messages"];

  var url = `https://api.openai.com/v1/chat/completions`;
  var headers = {
    "Content-Type": `application/json`,
    Authorization: `Bearer sk-proj-QuL1CrehAQoH6dhFkZK8T3BlbkFJqKYd3SRnbcJ2gPuHbW25`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Hello, What's the capital of Brazil?"
    }
  ]
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _getTokenURACarParkDetailsCall(context, ffVariables) {
  var url = `https://www.ura.gov.sg/uraDataService/insertNewToken.action`;
  var headers = { AccessKey: `17b16644-827e-4328-846d-b46f65a8e35b` };
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _getDirectionsCall(context, ffVariables) {
  var destination = ffVariables["destination"];
  var origin = ffVariables["origin"];
  var key = ffVariables["key"];
  var alternatives = ffVariables["alternatives"];
  var arrivalTime = ffVariables["arrivalTime"];
  var mode = ffVariables["mode"];
  var avoid = ffVariables["avoid"];
  var departureTime = ffVariables["departureTime"];
  var transitMode = ffVariables["transitMode"];
  var transitRoutingPreference = ffVariables["transitRoutingPreference"];

  var url = `https://maps.googleapis.com/maps/api/directions/json`;
  var headers = {};
  var params = {
    destination: destination,
    origin: origin,
    key: key,
    alternatives: alternatives,
    arrival_time: arrivalTime,
    mode: mode,
    avoid: avoid,
    departure_time: departureTime,
    transit_mode: transitMode,
    transit_routing_preference: transitRoutingPreference,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _getAddressCall(context, ffVariables) {
  var input = ffVariables["input"];

  var url = `https://maps.googleapis.com/maps/api/place/autocomplete/json`;
  var headers = {};
  var params = {
    language: `en_US`,
    key: `AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE`,
    input: input,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _getReferenceCall(context, ffVariables) {
  var input = ffVariables["input"];

  var url = `https://maps.googleapis.com/maps/api/place/details/json`;
  var headers = {};
  var params = {
    key: `AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE`,
    placeid: input,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _claudeAPICall(context, ffVariables) {
  var messages = ffVariables["messages"];
  var system = ffVariables["system"];

  var url = `https://api.anthropic.com/v1/messages`;
  var headers = {
    "x-api-key": `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`,
    "anthropic-version": `2023-06-01`,
    "content-type": `application/json`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "model": "claude-3-5-sonnet-20240620",
  "max_tokens": 1000,
  "messages": ${messages},
  "system" : "${system}"
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _rowenaCallCall(context, ffVariables) {
  var url = `https://lotlocate1.onrender.com/latest_message`;
  var headers = {};
  var params = {};
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _chatGPTforVoiceAssistantCall(context, ffVariables) {
  var messages = ffVariables["messages"];

  var url = `https://api.openai.com/v1/chat/completions`;
  var headers = {
    Authorization: `Bearer sk-proj-QuL1CrehAQoH6dhFkZK8T3BlbkFJqKYd3SRnbcJ2gPuHbW25`,
    "Content-Type": `application/json`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "model": "gpt-3.5-turbo",
  "messages": ${messages}
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _claudeAPIVoiceAssistantCall(context, ffVariables) {
  var messages = ffVariables["messages"];

  var url = `https://api.anthropic.com/v1/messages`;
  var headers = {
    "x-api-key": `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`,
    "anthropic-version": `2023-06-01`,
    "content-type": `application/json`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "model": "claude-3-5-sonnet-20240620",
  "max_tokens": 1000,
  "messages": [
    {
      "role": "user",
      "content": "${messages}"
    }
  ]
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}
async function _googleReviewsCall(context, ffVariables) {
  var placeId = ffVariables["placeId"];

  var url = `https://maps.googleapis.com/maps/api/place/details/json`;
  var headers = {};
  var params = {
    place_id: placeId,
    key: `AIzaSyD9x_13WLhSgk9BJSmg0-rP5Sk5TAS5PwE`,
  };
  var ffApiRequestBody = undefined;

  return makeApiRequest({
    method: "get",
    url,
    headers,
    params,
    returnBody: true,
    isStreamingApi: false,
  });
}

/// Helper functions to route to the appropriate API Call.

async function makeApiCall(context, data) {
  var callName = data["callName"] || "";
  var variables = data["variables"] || {};

  const callMap = {
    NearbyPlacesCall: _nearbyPlacesCall,
    URACarParkDetailsCall: _uRACarParkDetailsCall,
    DataMallCall: _dataMallCall,
    DataGovSGCarParkRatesCall: _dataGovSGCarParkRatesCall,
    GetPlacePhotoCall: _getPlacePhotoCall,
    DistanceMatrixCall: _distanceMatrixCall,
    GetResponseCall: _getResponseCall,
    ChatGPTCall: _chatGPTCall,
    GetTokenURACarParkDetailsCall: _getTokenURACarParkDetailsCall,
    GetDirectionsCall: _getDirectionsCall,
    GetAddressCall: _getAddressCall,
    GetReferenceCall: _getReferenceCall,
    ClaudeAPICall: _claudeAPICall,
    RowenaCallCall: _rowenaCallCall,
    ChatGPTforVoiceAssistantCall: _chatGPTforVoiceAssistantCall,
    ClaudeAPIVoiceAssistantCall: _claudeAPIVoiceAssistantCall,
    GoogleReviewsCall: _googleReviewsCall,
    ThreadsCall: _threadsCall,
    MessageCall: _messageCall,
    RunCall: _runCall,
    RetrieverunCall: _retrieverunCall,
    MessagesCall: _messagesCall,
  };

  if (!(callName in callMap)) {
    return {
      statusCode: 400,
      error: `API Call "${callName}" not defined as private API.`,
    };
  }

  var apiCall = callMap[callName];
  var response = await apiCall(context, variables);
  return response;
}

async function makeApiRequest({
  method,
  url,
  headers,
  params,
  body,
  returnBody,
  isStreamingApi,
}) {
  return axios
    .request({
      method: method,
      url: url,
      headers: headers,
      params: params,
      responseType: isStreamingApi ? "stream" : "json",
      ...(body && { data: body }),
    })
    .then((response) => {
      return {
        statusCode: response.status,
        headers: response.headers,
        ...(returnBody && { body: response.data }),
        isStreamingApi: isStreamingApi,
      };
    })
    .catch(function (error) {
      return {
        statusCode: error.response.status,
        headers: error.response.headers,
        ...(returnBody && { body: error.response.data }),
        error: error.message,
      };
    });
}

const _unauthenticatedResponse = {
  statusCode: 401,
  headers: {},
  error: "API call requires authentication",
};

function createBody({ headers, params, body, bodyType }) {
  switch (bodyType) {
    case "JSON":
      headers["Content-Type"] = "application/json";
      return body;
    case "TEXT":
      headers["Content-Type"] = "text/plain";
      return body;
    case "X_WWW_FORM_URL_ENCODED":
      headers["Content-Type"] = "application/x-www-form-urlencoded";
      return qs.stringify(params);
  }
}

module.exports = { makeApiCall };
